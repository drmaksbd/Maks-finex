package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.data.model.UserCloudData
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object LocalSnapshotManager {
    private const val SNAPSHOT_FILE_NAME = "restore_snapshot.enc"
    private const val KEY_PREF_NAME = "local_snapshot_prefs"
    private const val KEY_NAME = "snapshot_key"
    private const val ENCRYPTED_KEY_NAME = "encrypted_snapshot_key"
    private const val KEY_ALIAS = "hiseb_nikesh_local_snapshot_key"

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter<Map<String, UserCloudData>>(Types.newParameterizedType(Map::class.java, String::class.java, UserCloudData::class.java))

    private fun getKeystoreKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore")
        keyStore.load(null)
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
        return keyStore.getKey(KEY_ALIAS, null) as SecretKey
    }

    private fun encryptPassphrase(passphrase: String): String {
        val key = getKeystoreKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(passphrase.toByteArray(Charsets.UTF_8))
        val combined = iv + encrypted
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decryptPassphrase(encryptedPassphrase: String): String {
        val key = getKeystoreKey()
        val combined = Base64.decode(encryptedPassphrase, Base64.NO_WRAP)
        val iv = combined.sliceArray(0 until 12)
        val encrypted = combined.sliceArray(12 until combined.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun getLocalKey(context: Context): String {
        val prefs = context.getSharedPreferences(KEY_PREF_NAME, Context.MODE_PRIVATE)

        val encryptedKey = prefs.getString(ENCRYPTED_KEY_NAME, null)
        if (encryptedKey != null) {
            return decryptPassphrase(encryptedKey)
        }

        val oldKey = prefs.getString(KEY_NAME, null)
        if (oldKey != null) {
            val newEncryptedKey = encryptPassphrase(oldKey)
            prefs.edit()
                .putString(ENCRYPTED_KEY_NAME, newEncryptedKey)
                .remove(KEY_NAME)
                .apply()
            return oldKey
        }

        val newKey = UUID.randomUUID().toString() + UUID.randomUUID().toString()
        val encryptedNewKey = encryptPassphrase(newKey)
        prefs.edit().putString(ENCRYPTED_KEY_NAME, encryptedNewKey).apply()
        return newKey
    }

    fun saveSnapshot(context: Context, data: Map<String, UserCloudData>): Boolean {
        return try {
            val json = adapter.toJson(data)
            val encrypted = CryptoManager.encrypt(json, getLocalKey(context))
            val file = File(context.filesDir, SNAPSHOT_FILE_NAME)
            file.writeText(encrypted)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun loadSnapshot(context: Context): Map<String, UserCloudData>? {
        return try {
            val file = File(context.filesDir, SNAPSHOT_FILE_NAME)
            if (!file.exists()) return null
            val encrypted = file.readText()
            val decrypted = CryptoManager.decrypt(encrypted, getLocalKey(context))
            adapter.fromJson(decrypted)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteSnapshot(context: Context) {
        val file = File(context.filesDir, SNAPSHOT_FILE_NAME)
        if (file.exists()) file.delete()
    }
}
