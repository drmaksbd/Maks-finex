package com.example.security

object BillingConfig {
    // These are the product IDs that should match Google Play Console configuration.
    // They are fully configurable.
    const val PRODUCT_MONTHLY = "maks_finex_premium_monthly"
    const val PRODUCT_YEARLY = "maks_finex_premium_yearly"
    const val PRODUCT_LIFETIME = "maks_finex_premium_lifetime"

    val ALL_SUBSCRIPTION_PRODUCTS = listOf(PRODUCT_MONTHLY, PRODUCT_YEARLY)
    val ALL_ONE_TIME_PRODUCTS = listOf(PRODUCT_LIFETIME)
}

enum class PurchaseStatus {
    NOT_PURCHASED,
    PURCHASED,
    PENDING,
    ERROR
}

data class ProductUIModel(
    val id: String,
    val title: String,
    val price: String,
    val description: String,
    val isSubscription: Boolean
)
