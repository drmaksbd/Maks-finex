package com.example.security

object AdMobConfig {
    // Official Google demo banner ad unit ID for Android
    const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"

    // Production configuration holder - can be overridden at runtime or from BuildConfig
    var currentBannerAdUnitId: String = TEST_BANNER_AD_UNIT_ID
}
