package com.example.security

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class EntitlementState {
    FREE,
    PREMIUM
}

enum class EntitlementType {
    NO_ADS,
    PREMIUM_ACCOUNT,
    ADVANCED_REPORTS,
    ADVANCED_EXPORT,
    MULTIPLE_LEDGER,
    AUTOMATIC_BACKUP,
    SMART_ALERTS
}

class EntitlementManager private constructor(context: Context) {

    private val sharedPrefs = context.applicationContext.getSharedPreferences(
        "MaksFinexEntitlementPrefs",
        Context.MODE_PRIVATE
    )

    private val _entitlementState = MutableStateFlow(EntitlementState.FREE)
    val entitlementState: StateFlow<EntitlementState> = _entitlementState.asStateFlow()

    init {
        // Read stored state. Default is FREE.
        val storedStateStr = sharedPrefs.getString(PREF_KEY_ENTITLEMENT, EntitlementState.FREE.name)
            ?: EntitlementState.FREE.name
        val storedState = try {
            EntitlementState.valueOf(storedStateStr)
        } catch (e: Exception) {
            EntitlementState.FREE
        }
        _entitlementState.value = storedState
        Log.d(TAG, "Initialized EntitlementManager with state: $storedState")
    }

    fun isPremium(): Boolean {
        return _entitlementState.value == EntitlementState.PREMIUM
    }

    fun shouldShowAds(): Boolean {
        // No AdMob in current project, but future-proof.
        return _entitlementState.value == EntitlementState.FREE
    }

    fun hasEntitlement(type: EntitlementType): Boolean {
        return when (type) {
            EntitlementType.NO_ADS -> isPremium()
            EntitlementType.PREMIUM_ACCOUNT -> isPremium()
            EntitlementType.ADVANCED_REPORTS -> isPremium()
            EntitlementType.ADVANCED_EXPORT -> isPremium()
            EntitlementType.MULTIPLE_LEDGER -> isPremium()
            EntitlementType.AUTOMATIC_BACKUP -> isPremium()
            EntitlementType.SMART_ALERTS -> isPremium()
        }
    }

    /**
     * Update the entitlement state. This will be the direct interface called by 
     * the future Google Play Billing client or verification repository.
     */
    fun updateEntitlement(state: EntitlementState) {
        _entitlementState.value = state
        sharedPrefs.edit()
            .putString(PREF_KEY_ENTITLEMENT, state.name)
            .apply()
        Log.d(TAG, "Entitlement updated and persisted to: $state")
    }

    companion object {
        private const val TAG = "EntitlementManager"
        private const val PREF_KEY_ENTITLEMENT = "premium_entitlement_state"

        @Volatile
        private var INSTANCE: EntitlementManager? = null

        fun getInstance(context: Context): EntitlementManager {
            return INSTANCE ?: synchronized(this) {
                val instance = EntitlementManager(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
