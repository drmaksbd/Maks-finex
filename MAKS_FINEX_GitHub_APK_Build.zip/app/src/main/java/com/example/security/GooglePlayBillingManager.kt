package com.example.security

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GooglePlayBillingManager private constructor(private val context: Context) : PurchasesUpdatedListener {

    private val entitlementManager = EntitlementManager.getInstance(context)
    private val scope = CoroutineScope(Dispatchers.Main)

    private val _productsForSale = MutableStateFlow<List<ProductUIModel>>(emptyList())
    val productsForSale: StateFlow<List<ProductUIModel>> = _productsForSale.asStateFlow()

    private val _billingError = MutableStateFlow<String?>(null)
    val billingError: StateFlow<String?> = _billingError.asStateFlow()

    private val _isBillingReady = MutableStateFlow(false)
    val isBillingReady: StateFlow<Boolean> = _isBillingReady.asStateFlow()

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases()
        .build()

    init {
        startBillingConnection()
    }

    fun startBillingConnection() {
        Log.d(TAG, "Starting Google Play Billing connection...")
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    Log.d(TAG, "BillingClient connection established successfully.")
                    _isBillingReady.value = true
                    _billingError.value = null
                    // Query existing purchases to restore/update entitlements
                    queryPurchases()
                    // Query products for sale to show in the UI
                    queryProducts()
                } else {
                    Log.e(TAG, "Billing Setup failed: ${billingResult.debugMessage} (Code: ${billingResult.responseCode})")
                    _isBillingReady.value = false
                    _billingError.value = if (billingResult.responseCode == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE) {
                        "Google Play Billing is unavailable (Play Store is missing, outdated, or offline)."
                    } else {
                        "Setup failed: ${billingResult.debugMessage}"
                    }
                    entitlementManager.updateEntitlement(EntitlementState.FREE) // Safe fallback
                }
            }

            override fun onBillingServiceDisconnected() {
                Log.w(TAG, "Billing service disconnected. Will retry connection on demand.")
                _isBillingReady.value = false
                _billingError.value = "Billing service disconnected."
            }
        })
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                processPurchase(purchase)
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.d(TAG, "User canceled the purchase flow.")
            _billingError.value = "Purchase canceled by user."
        } else {
            Log.e(TAG, "Purchase update failed: ${billingResult.debugMessage}")
            _billingError.value = "Purchase failed: ${billingResult.debugMessage}"
        }
    }

    /**
     * Process a purchase safely. Check purchase states, verify entitlement, and acknowledge if needed.
     */
    private fun processPurchase(purchase: Purchase) {
        // Purchase token security: DO NOT log the purchase token in plaintext or expose it.
        Log.d(TAG, "Processing purchase: OrderId=${purchase.orderId}, PurchaseState=${purchase.purchaseState}")

        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            // Check if the purchase contains any of our valid premium products
            val containsPremiumProduct = purchase.products.any {
                it == BillingConfig.PRODUCT_MONTHLY ||
                it == BillingConfig.PRODUCT_YEARLY ||
                it == BillingConfig.PRODUCT_LIFETIME
            }

            if (containsPremiumProduct) {
                // Handle entitlement activation
                scope.launch {
                    entitlementManager.updateEntitlement(EntitlementState.PREMIUM)
                    // Acknowledge if required
                    if (!purchase.isAcknowledged) {
                        acknowledgePurchase(purchase.purchaseToken)
                    }
                }
            }
        } else if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
            // Pending purchases do NOT grant premium until completed
            Log.d(TAG, "Purchase is pending. Waiting for completion.")
            entitlementManager.updateEntitlement(EntitlementState.FREE)
        } else {
            entitlementManager.updateEntitlement(EntitlementState.FREE)
        }
    }

    private fun acknowledgePurchase(purchaseToken: String) {
        val acknowledgeParams = AcknowledgePurchaseParams.newBuilder()
            .setPurchaseToken(purchaseToken)
            .build()

        billingClient.acknowledgePurchase(acknowledgeParams) { billingResult ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                Log.d(TAG, "Purchase successfully acknowledged.")
            } else {
                Log.e(TAG, "Failed to acknowledge purchase: ${billingResult.debugMessage}")
            }
        }
    }

    /**
     * Query existing subscriptions and one-time purchases to set correct authoritative state.
     */
    fun queryPurchases() {
        if (!billingClient.isReady) {
            Log.w(TAG, "Cannot query purchases: BillingClient is not ready.")
            return
        }

        // 1. Query Subscriptions
        val subParams = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(subParams) { billingResult, purchases ->
            var premiumFound = false
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                for (purchase in purchases) {
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        val hasProduct = purchase.products.any {
                            it == BillingConfig.PRODUCT_MONTHLY || it == BillingConfig.PRODUCT_YEARLY
                        }
                        if (hasProduct) {
                            premiumFound = true
                            processPurchase(purchase)
                        }
                    }
                }
            }

            if (premiumFound) return@queryPurchasesAsync

            // 2. Query One-time purchases (Lifetime) if no subscription premium was found
            val inAppParams = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build()

            billingClient.queryPurchasesAsync(inAppParams) { inAppResult, inAppPurchases ->
                var lifetimeFound = false
                if (inAppResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    for (purchase in inAppPurchases) {
                        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                            val hasProduct = purchase.products.any {
                                it == BillingConfig.PRODUCT_LIFETIME
                            }
                            if (hasProduct) {
                                lifetimeFound = true
                                processPurchase(purchase)
                            }
                        }
                    }
                }

                if (!lifetimeFound) {
                    // No active subscriptions or lifetime purchases found
                    Log.d(TAG, "No valid purchases found on Google Play. Setting entitlement to FREE.")
                    entitlementManager.updateEntitlement(EntitlementState.FREE)
                }
            }
        }
    }

    /**
     * Query available products from Google Play Console to dynamically display details in UI.
     */
    fun queryProducts() {
        if (!billingClient.isReady) return

        val productList = mutableListOf<QueryProductDetailsParams.Product>()

        // Monthly & Yearly
        BillingConfig.ALL_SUBSCRIPTION_PRODUCTS.forEach { id ->
            productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            )
        }

        // Lifetime
        BillingConfig.ALL_ONE_TIME_PRODUCTS.forEach { id ->
            productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build()
            )
        }

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val uiList = productDetailsList.map { details ->
                    val isSub = details.productType == BillingClient.ProductType.SUBS
                    val price = if (isSub) {
                        details.subscriptionOfferDetails?.firstOrNull()?.pricingPhases?.pricingPhaseList?.firstOrNull()?.formattedPrice
                            ?: "N/A"
                    } else {
                        details.oneTimePurchaseOfferDetails?.formattedPrice ?: "N/A"
                    }

                    ProductUIModel(
                        id = details.productId,
                        title = details.name,
                        price = price,
                        description = details.description,
                        isSubscription = isSub
                    )
                }
                _productsForSale.value = uiList
                Log.d(TAG, "Queried and populated ${uiList.size} product details successfully.")
            } else {
                Log.e(TAG, "Failed to query product details: ${billingResult.debugMessage}")
            }
        }
    }

    /**
     * Initiate purchase flow for a specific product ID.
     */
    fun launchPurchaseFlow(activity: Activity, productId: String, onLaunchResult: (BillingResult) -> Unit) {
        if (!billingClient.isReady) {
            _billingError.value = "Billing client is not ready."
            return
        }

        val isSubscription = BillingConfig.ALL_SUBSCRIPTION_PRODUCTS.contains(productId)
        val productType = if (isSubscription) BillingClient.ProductType.SUBS else BillingClient.ProductType.INAPP

        val productQueryList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(productType)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productQueryList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && productDetailsList.isNotEmpty()) {
                val productDetails = productDetailsList.first()
                val productDetailsParamsList = mutableListOf<BillingFlowParams.ProductDetailsParams>()

                val builder = BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(productDetails)

                if (isSubscription) {
                    val offerToken = productDetails.subscriptionOfferDetails?.firstOrNull()?.offerToken
                    if (offerToken != null) {
                        builder.setOfferToken(offerToken)
                    }
                }

                productDetailsParamsList.add(builder.build())

                val flowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .build()

                val result = billingClient.launchBillingFlow(activity, flowParams)
                onLaunchResult(result)
            } else {
                Log.e(TAG, "ProductDetails query failed or was empty for launch: ${billingResult.debugMessage}")
                _billingError.value = "Product unavailable in Play Store."
            }
        }
    }

    companion object {
        private const val TAG = "MaksFinexBilling"

        @Volatile
        private var INSTANCE: GooglePlayBillingManager? = null

        fun getInstance(context: Context): GooglePlayBillingManager {
            return INSTANCE ?: synchronized(this) {
                val instance = GooglePlayBillingManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
