package com.example.security

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(tableName = "identity_mapping")
data class IdentityMapping(
    @PrimaryKey val firebaseUid: String,
    val localUsername: String
)

@Dao
interface IdentityDao {
    @Query("SELECT * FROM identity_mapping WHERE firebaseUid = :uid")
    suspend fun getMapping(uid: String): IdentityMapping?

    @Insert
    suspend fun insertMapping(mapping: IdentityMapping)
}

@Database(entities = [IdentityMapping::class], version = 1)
abstract class IdentityDatabase : RoomDatabase() {
    abstract fun identityDao(): IdentityDao

    companion object {
        @Volatile
        private var INSTANCE: IdentityDatabase? = null

        fun getDatabase(context: Context): IdentityDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IdentityDatabase::class.java,
                    "identity_mapping.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
