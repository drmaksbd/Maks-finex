package com.example.security

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object CryptoManager {
    private const val PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val AES_ALGORITHM = "AES/GCM/NoPadding"
    private const val LEGACY_ITERATIONS = 10000
    private const val NEW_ITERATIONS = 100000
    private const val KEY_LENGTH = 256
    private const val IV_LENGTH = 12
    private const val SALT_LENGTH = 16
    private const val TAG_LENGTH = 128
    private const val FORMAT_VERSION = 2

    private fun deriveKey(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM)
        return factory.generateSecret(spec).encoded
    }

    fun encrypt(data: String, password: String): String {
        val salt = ByteArray(SALT_LENGTH).apply { SecureRandom().nextBytes(this) }
        val iv = ByteArray(IV_LENGTH).apply { SecureRandom().nextBytes(this) }
        val key = deriveKey(password, salt, NEW_ITERATIONS)
        
        val cipher = Cipher.getInstance(AES_ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_LENGTH, iv))
        
        val encrypted = cipher.doFinal(data.toByteArray(Charsets.UTF_8))
        
        val json = org.json.JSONObject().apply {
            put("v", FORMAT_VERSION)
            put("i", NEW_ITERATIONS)
            put("s", Base64.encodeToString(salt, Base64.NO_WRAP))
            put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            put("ct", Base64.encodeToString(encrypted, Base64.NO_WRAP))
        }
        return Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.DEFAULT)
    }
    
    fun decrypt(encryptedData: String, password: String): String {
        val decoded = try { Base64.decode(encryptedData, Base64.DEFAULT) } catch (e: Exception) { return "" }
        val content = String(decoded, Charsets.UTF_8)
        
        if (content.startsWith("{")) {
            // New Format
            val json = org.json.JSONObject(content)
            val salt = Base64.decode(json.getString("s"), Base64.NO_WRAP)
            val iv = Base64.decode(json.getString("iv"), Base64.NO_WRAP)
            val encrypted = Base64.decode(json.getString("ct"), Base64.NO_WRAP)
            val iterations = json.getInt("i")
            
            val key = deriveKey(password, salt, iterations)
            val cipher = Cipher.getInstance(AES_ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_LENGTH, iv))
            return String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } else {
            // Legacy Format
            val combined = decoded
            val salt = combined.sliceArray(0 until SALT_LENGTH)
            val iv = combined.sliceArray(SALT_LENGTH until SALT_LENGTH + IV_LENGTH)
            val encrypted = combined.sliceArray(SALT_LENGTH + IV_LENGTH until combined.size)
            
            val key = deriveKey(password, salt, LEGACY_ITERATIONS)
            val cipher = Cipher.getInstance(AES_ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_LENGTH, iv))
            return String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }
    }
}
