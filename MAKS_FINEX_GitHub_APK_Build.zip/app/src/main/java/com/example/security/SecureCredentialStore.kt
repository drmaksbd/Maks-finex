package com.example.security

import android.content.SharedPreferences
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object SecureCredentialStore {

    private const val ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16

    fun hashPin(pin: String, salt: String): String {
        val spec = PBEKeySpec(pin.toCharArray(), Base64.decode(salt, Base64.DEFAULT), ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance(ALGORITHM)
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.DEFAULT)
    }

    fun verifyPin(pin: String, storedHash: String, storedSalt: String): Boolean {
        val newHash = hashPin(pin, storedSalt)
        return newHash == storedHash
    }

    fun generateSalt(): String {
        val random = SecureRandom()
        val salt = ByteArray(SALT_LENGTH)
        random.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.DEFAULT)
    }

    fun migrateCredentials(sharedPrefs: SharedPreferences) {
        if (sharedPrefs.getBoolean("migration_completed", false)) return

        val edit = sharedPrefs.edit()
        val allPrefs = sharedPrefs.all
        
        // Migrate Master user
        val masterPin = sharedPrefs.getString("user_pin", null)
        if (masterPin != null) {
            val salt = generateSalt()
            val hash = hashPin(masterPin, salt)
            edit.putString("user_pin_hash", hash)
            edit.putString("user_pin_salt", salt)
            edit.remove("user_pin")
        }

        // Migrate Sub-users
        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }
        
        subUserNames.forEach { name ->
            val pin = sharedPrefs.getString("user_pin_$name", null)
            if (pin != null) {
                val salt = generateSalt()
                val hash = hashPin(pin, salt)
                edit.putString("user_pin_hash_$name", hash)
                edit.putString("user_pin_salt_$name", salt)
                edit.remove("user_pin_$name")
            }
        }

        edit.putBoolean("migration_completed", true)
        edit.apply()
    }
}
