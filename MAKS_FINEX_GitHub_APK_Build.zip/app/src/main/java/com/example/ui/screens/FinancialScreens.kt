package com.example.ui.screens

import androidx.compose.animation.*
import com.example.ui.theme.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import android.util.Log
import android.content.Context
import android.content.Intent
import androidx.compose.ui.text.font.FontFamily
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.data.model.*
import java.io.File
import com.example.viewmodel.FinancialViewModel
import com.example.viewmodel.Screen
import com.example.viewmodel.AppUser
import java.text.SimpleDateFormat
import java.util.*

import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.TextUnit

// Helper function to format Taka amounts
fun formatTaka(amount: Double): String {
    return "৳ " + String.format(Locale.US, "%,.2f", amount)
}

// Helper to convert timestamp to readable date
fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM, yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

// Translate a string dynamically based on app locale
fun translateText(text: String, context: android.content.Context): String {
    val language = context.resources.configuration.locale?.language ?: "bn"
    if (language == "en") {
        val trimmed = text.trim()
        val exact = TranslationMap.bToE[trimmed]
        if (exact != null) return exact

        // Handle comma-separated lists (like categories: "খাবার,ভাড়া,শপিং...")
        if (trimmed.contains(",")) {
            val parts = trimmed.split(",")
            val translatedParts = parts.map { part ->
                TranslationMap.bToE[part.trim()] ?: part.trim()
            }
            return translatedParts.joinToString(",")
        }

        // Substring & Dynamic pattern matching
        var result = trimmed
        if (result.startsWith("স্বয়ংক্রিয়ভাবে লগইন করা হয়েছে (")) {
            val email = result.substringAfter("(").substringBefore(")")
            return "Automatically logged in ($email)"
        }
        if (result.startsWith("স্বয়ংক্রিয়ভাবে অ্যাকাউন্ট তৈরি ও লগইন করা হয়েছে (")) {
            val email = result.substringAfter("(").substringBefore(")")
            return "Automatically registered and logged in ($email)"
        }
        if (result.startsWith("গুগল ড্রাইভ থেকে ") && result.contains(" টি ইউজার ডাটা সফলভাবে রিস্টোর সম্পন্ন হয়েছে!")) {
            val count = result.substringAfter("গুগল ড্রাইভ থেকে ").substringBefore(" টি ইউজার ডাটা")
            return "Successfully restored $count user data from Google Drive!"
        }
        if (result.startsWith("ব্যাকআপ ব্যর্থ হয়েছে: ")) {
            val err = result.substringAfter("ব্যাকআপ ব্যর্থ হয়েছে: ")
            return "Backup failed: $err"
        }
        if (result.startsWith("ব্যাকআপে সমস্যা হয়েছে: ")) {
            val err = result.substringAfter("ব্যাকআপে সমস্যা হয়েছে: ")
            return "Backup error: $err"
        }
        if (result.startsWith("রিস্টোর ব্যর্থ হয়েছে: ")) {
            val err = result.substringAfter("রিস্টোর ব্যর্থ হয়েছে: ")
            return "Restore failed: $err"
        }
        if (result.startsWith("রিস্টোরে সমস্যা হয়েছে: ")) {
            val err = result.substringAfter("রিস্টোরে সমস্যা হয়েছে: ")
            return "Restore error: $err"
        }
        if (result.startsWith("গুগল ড্রাইভ ব্যাকআপ ব্যর্থ হয়েছে: ")) {
            val err = result.substringAfter("গুগল ড্রাইভ ব্যাকআপ ব্যর্থ হয়েছে: ")
            return "Google Drive backup failed: $err"
        }
        if (result.startsWith("গুগল ড্রাইভ ব্যাকআপে সমস্যা হয়েছে: ")) {
            val err = result.substringAfter("গুগল ড্রাইভ ব্যাকআপে সমস্যা হয়েছে: ")
            return "Google Drive backup error: $err"
        }
        if (result.startsWith("গুগল ড্রাইভ রিস্টোর ব্যর্থ হয়েছে: ")) {
            val err = result.substringAfter("গুগল ড্রাইভ রিস্টোর ব্যর্থ হয়েছে: ")
            return "Google Drive restore failed: $err"
        }
        if (result.startsWith("গুগল ড্রাইভ রিস্টোরে সমস্যা হয়েছে: ")) {
            val err = result.substringAfter("গুগল ড্রাইভ রিস্টোরে সমস্যা হয়েছে: ")
            return "Google Drive restore error: $err"
        }

        // Sequential multi-match replacement as a robust fallback
        for ((key, value) in TranslationMap.bToE) {
            if (key.length > 2 && result.contains(key)) {
                result = result.replace(key, value)
            }
        }
        return result
    }
    return text
}

// Translate AnnotatedString dynamically based on app locale
fun translateText(text: androidx.compose.ui.text.AnnotatedString, context: android.content.Context): androidx.compose.ui.text.AnnotatedString {
    val language = context.resources.configuration.locale?.language ?: "bn"
    if (language == "en") {
        val originalText = text.text
        val translated = TranslationMap.bToE[originalText] ?: originalText
        if (translated != originalText) {
            return androidx.compose.ui.text.AnnotatedString(
                text = translated,
                spanStyles = text.spanStyles,
                paragraphStyles = text.paragraphStyles
            )
        }
    }
    return text
}

@Composable
fun tr(key: String, default: String = ""): String {
    val context = LocalContext.current
    val resId = context.resources.getIdentifier(key, "string", context.packageName)
    val base = if (resId != 0) {
        context.getString(resId)
    } else {
        default.ifEmpty { key }
    }
    return translateText(base, context)
}

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: (androidx.compose.ui.text.TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current
) {
    val context = LocalContext.current
    val translated = translateText(text, context)
    androidx.compose.material3.Text(
        text = translated,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}

@Composable
fun Text(
    text: androidx.compose.ui.text.AnnotatedString,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: (androidx.compose.ui.text.TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current
) {
    val context = LocalContext.current
    val translated = translateText(text, context)
    androidx.compose.material3.Text(
        text = translated,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}

private val screenOrderMap = mapOf(
    Screen.LOGIN to 0,
    Screen.DASHBOARD to 1,
    Screen.DAILY_TRANSACTIONS to 2,
    Screen.INVESTMENTS to 3,
    Screen.DEBTS to 4,
    Screen.ASSETS to 5,
    Screen.ZAKAT to 6,
    Screen.BUSINESS_LEDGER to 7,
    Screen.SETTINGS to 8,
    Screen.PREMIUM to 9
)

@Composable
fun ScreenNavigationButtons(
    viewModel: FinancialViewModel,
    currentScreen: Screen,
    modifier: Modifier = Modifier
) {
    val orderedScreens = listOf(
        Screen.DASHBOARD,
        Screen.DAILY_TRANSACTIONS,
        Screen.INVESTMENTS,
        Screen.DEBTS,
        Screen.ASSETS,
        Screen.ZAKAT,
        Screen.BUSINESS_LEDGER,
        Screen.REPORTS
    )

    // Filter to only include screens that are actually allowed/permitted for the user
    val allowedScreens = orderedScreens.filter { screen ->
        screen == Screen.DASHBOARD || viewModel.isScreenAllowed(screen)
    }

    val currentIndex = allowedScreens.indexOf(currentScreen)
    if (currentIndex == -1) return // Do not show on LOGIN

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp) // Beautiful shadow/depth effect
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // --- PREVIOUS BUTTON ---
            if (currentIndex > 0) {
                val prevScreen = allowedScreens[currentIndex - 1]
                val prevLabel = when (prevScreen) {
                    Screen.DASHBOARD -> tr("dashboard", "Dashboard")
                    Screen.DAILY_TRANSACTIONS -> tr("daily_transactions", "Daily Transactions")
                    Screen.INVESTMENTS -> tr("investments", "Fixed Investments")
                    Screen.DEBTS -> tr("debts", "Debt Tracker")
                    Screen.ASSETS -> tr("assets", "Asset Tracker")
                    Screen.ZAKAT -> tr("zakat", "Zakat Calculator")
                    Screen.BUSINESS_LEDGER -> tr("business", "Business Ledger")
                    Screen.REPORTS -> tr("reports", "Reports & Charts")
                    else -> tr("prev_page", "Previous")
                }

                FilledTonalButton(
                    onClick = { viewModel.navigateTo(prevScreen) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.85f),
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = tr("prev_page", "Previous"),
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = tr("prev_page", "Previous") + ": $prevLabel",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.width(8.dp))

            // --- NEXT BUTTON ---
            if (currentIndex < allowedScreens.size - 1) {
                val nextScreen = allowedScreens[currentIndex + 1]
                val nextLabel = when (nextScreen) {
                    Screen.DASHBOARD -> tr("dashboard", "Dashboard")
                    Screen.DAILY_TRANSACTIONS -> tr("daily_transactions", "Daily Transactions")
                    Screen.INVESTMENTS -> tr("investments", "Fixed Investments")
                    Screen.DEBTS -> tr("debts", "Debt Tracker")
                    Screen.ASSETS -> tr("assets", "Asset Tracker")
                    Screen.ZAKAT -> tr("zakat", "Zakat Calculator")
                    Screen.BUSINESS_LEDGER -> tr("business", "Business Ledger")
                    Screen.REPORTS -> tr("reports", "Reports & Charts")
                    else -> tr("next_page", "Next")
                }

                Button(
                    onClick = { viewModel.navigateTo(nextScreen) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = tr("next_page", "Next") + ": $nextLabel",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = tr("next_page", "Next"),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            } else {
                // Loop back to dashboard if we are at the end
                Button(
                    onClick = { viewModel.navigateTo(Screen.DASHBOARD) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ড্যাশবোর্ডে ফিরুন",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.Filled.Home,
                            contentDescription = "ড্যাশবোর্ড",
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppNavigationShell(
    viewModel: FinancialViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val showUnlockDialogForScreen by viewModel.showUnlockDialogForScreen.collectAsStateWithLifecycle()
    val context = LocalContext.current
    // val showSyncDialog by viewModel.showSyncDialog.collectAsStateWithLifecycle() // Removed
    // if (showSyncDialog) {
    //     CloudSyncDialog(
    //         viewModel = viewModel,
    //         onDismiss = { viewModel.showSyncDialog.value = false }
    //     )
    // }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (isLoggedIn) {
                FinancialTopBar(
                    viewModel = viewModel,
                    currentScreen = currentScreen,
                    // onOpenSync = { showSyncDialog = true } // Removed
                )
            }
        },
        bottomBar = {
            if (isLoggedIn) {
                FinancialBottomBar(
                    currentScreen = currentScreen,
                    onNavigate = { screen -> viewModel.navigateTo(screen) }
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    val initialIndex = screenOrderMap[initialState] ?: 0
                    val targetIndex = screenOrderMap[targetState] ?: 0
                    if (targetIndex > initialIndex) {
                        (slideInHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { width -> width / 3 } + fadeIn(animationSpec = tween(280)))
                            .togetherWith(slideOutHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { width -> -width / 3 } + fadeOut(animationSpec = tween(280)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { width -> -width / 3 } + fadeIn(animationSpec = tween(280)))
                            .togetherWith(slideOutHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { width -> width / 3 } + fadeOut(animationSpec = tween(280)))
                    }
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    Screen.LOGIN -> LoginScreen(viewModel = viewModel)
                    Screen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    Screen.DAILY_TRANSACTIONS -> DailyTransactionsScreen(viewModel = viewModel)
                    Screen.INVESTMENTS -> FixedInvestmentsScreen(viewModel = viewModel)
                    Screen.DEBTS -> DebtsScreen(viewModel = viewModel)
                    Screen.ASSETS -> AssetsScreen(viewModel = viewModel)
                    Screen.ZAKAT -> ZakatScreen(viewModel = viewModel)
                    Screen.REPORTS -> ReportsScreen(viewModel = viewModel)
                    Screen.BUSINESS_LEDGER -> BusinessLedgerScreen(viewModel = viewModel)
                    Screen.MORE -> MoreScreen(viewModel = viewModel)
                    Screen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    Screen.PREMIUM -> PremiumScreen(viewModel = viewModel)
                }
            }
        }
    }
    
    if (showUnlockDialogForScreen != null) {
        UnlockDialog(
            viewModel = viewModel,
            screen = showUnlockDialogForScreen!!,
            onDismiss = { viewModel.dismissUnlockDialog() }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancialTopBar(
    viewModel: FinancialViewModel,
    currentScreen: Screen,
    onOpenSync: () -> Unit = {}
) {
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val appLocale by viewModel.appLocale.collectAsStateWithLifecycle()
    var showSelfEditDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showLanguageSelectionDialog by remember { mutableStateOf(false) }

    val screenTitle = when (currentScreen) {
        Screen.DASHBOARD -> tr("dashboard", "Dashboard")
        Screen.DAILY_TRANSACTIONS -> tr("daily_transactions", "Daily Transactions")
        Screen.INVESTMENTS -> tr("investments", "Fixed Investments")
        Screen.DEBTS -> tr("debts", "Debt Tracker")
        Screen.ASSETS -> tr("assets", "Asset Tracker")
        Screen.ZAKAT -> tr("zakat", "Zakat Calculator")
        Screen.REPORTS -> tr("reports", "Reports & Charts")
        Screen.BUSINESS_LEDGER -> tr("business", "Business Ledger")
        Screen.SETTINGS -> tr("settings_menu", "সেটিং")
        Screen.PREMIUM -> tr("premium_menu", "MAKS FINEX Premium")
        else -> ""
    }

    TopAppBar(
        title = {
            Column {
                if (currentScreen != Screen.DASHBOARD) {
                    Text(
                        text = screenTitle,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        },
        navigationIcon = {
            if (currentScreen != Screen.DASHBOARD) {
                IconButton(onClick = { viewModel.navigateTo(Screen.DASHBOARD) }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = tr("back_to_dashboard", "Back to Dashboard")
                    )
                }
            }
        },
        actions = {
            if (currentScreen != Screen.DASHBOARD && currentScreen != Screen.SETTINGS) {
                IconButton(onClick = { showSettingsDialog = true }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = tr("settings_title", "Settings"),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (currentUser != null) {
                    IconButton(onClick = { showSelfEditDialog = true }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = tr("profile_edit", "Edit Profile"),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                IconButton(onClick = onOpenSync, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Cloud,
                        contentDescription = tr("backup_restore", "Backup & Restore"),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = { viewModel.logout() }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Filled.ExitToApp,
                        contentDescription = tr("logout", "Logout"),
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            scrolledContainerColor = MaterialTheme.colorScheme.background
        )
    )

    if (showSelfEditDialog && currentUser != null) {
        val user = currentUser!!
        var selfName by remember { mutableStateOf(user.name) }
        var selfPin by remember { mutableStateOf("") }
        var selfError by remember { mutableStateOf("") }
        
        val pleaseEnterUsername = tr("please_enter_username", "Please enter your username.")
        val pleaseEnterPin = tr("please_enter_4_to_12_digit_pin", "Please enter a 4 to 12 digit PIN code.")
        val profileUpdateFailed = tr("profile_update_failed_error", "Profile update failed! Username might be taken.")
        
        Dialog(onDismissRequest = { showSelfEditDialog = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("edit_profile_dialog_title", "আমার প্রোফাইল সংশোধন"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = selfName,
                        onValueChange = { selfName = it },
                        label = { Text(tr("username_label", "ব্যবহারকারীর নাম")) },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Person, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = selfPin,
                        onValueChange = { if (it.length <= 12) selfPin = it },
                        label = { Text(tr("new_pin_label", "নতুন পিন কোড (পরিবর্তন না করতে চাইলে খালি রাখুন)")) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        visualTransformation = PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Filled.Lock, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (selfError.isNotEmpty()) {
                        Text(
                            text = selfError,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showSelfEditDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(tr("cancel", "বাতিল"))
                        }

                        Button(
                            onClick = {
                                val name = selfName.trim()
                                val pin = selfPin.trim()
                                if (name.isBlank()) {
                                    selfError = pleaseEnterUsername
                                } else if (pin.isNotEmpty() && (pin.length !in 4..12 || !pin.all { it.isDigit() })) {
                                    selfError = pleaseEnterPin
                                } else {
                                    val success = viewModel.updateSelfProfile(name, pin)
                                    if (success) {
                                        showSelfEditDialog = false
                                    } else {
                                        selfError = profileUpdateFailed
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text(tr("save", "সংরক্ষণ"))
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        Dialog(onDismissRequest = { showSettingsDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("settings_title", "Settings"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // Dark Mode Setting Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.toggleTheme() }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = tr("theme_setting", "Dark Mode"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tr("theme_setting_desc", "Toggle application dark theme"),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.toggleTheme() }
                        )
                    }

                    // Language Setting Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLanguageSelectionDialog = true }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Language,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = tr("language_setting", "Language"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tr("language_setting_desc", "Change app language to English or Bangla"),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                        
                        // Active language badge
                        Box(
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(50.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (appLocale == "en") "English" else "বাংলা",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Button(
                        onClick = { showSettingsDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(tr("back", "Back"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showLanguageSelectionDialog) {
        Dialog(onDismissRequest = { showLanguageSelectionDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("select_language", "Select Language"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // English Radio Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLocale("en")
                                showLanguageSelectionDialog = false
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr("english_lang", "English"),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        RadioButton(
                            selected = appLocale == "en",
                            onClick = {
                                viewModel.setAppLocale("en")
                                showLanguageSelectionDialog = false
                            }
                        )
                    }

                    // Bangla Radio Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLocale("bn")
                                showLanguageSelectionDialog = false
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr("bangla_lang", "বাংলা"),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        RadioButton(
                            selected = appLocale == "bn",
                            onClick = {
                                viewModel.setAppLocale("bn")
                                showLanguageSelectionDialog = false
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showLanguageSelectionDialog = false }) {
                            Text(tr("cancel", "Cancel"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FinancialBottomBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    val items = listOf(
        Screen.DASHBOARD to (tr("nav_home", "Home") to Icons.Filled.Home),
        Screen.DAILY_TRANSACTIONS to (tr("nav_ledger", "Ledger") to Icons.Filled.ReceiptLong),
        Screen.REPORTS to (tr("nav_reports", "Reports") to Icons.Filled.BarChart),
        Screen.BUSINESS_LEDGER to (tr("nav_business", "Business") to Icons.Filled.BusinessCenter),
        Screen.MORE to (tr("nav_more", "More") to Icons.Filled.MoreHoriz)
    )

    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp) {
        items.forEach { (screen, info) ->
            val (label, icon) = info
            val isSelected = when (screen) {
                Screen.DASHBOARD -> currentScreen == Screen.DASHBOARD
                Screen.DAILY_TRANSACTIONS -> currentScreen == Screen.DAILY_TRANSACTIONS
                Screen.REPORTS -> currentScreen == Screen.REPORTS
                Screen.BUSINESS_LEDGER -> currentScreen == Screen.BUSINESS_LEDGER
                Screen.MORE -> currentScreen in listOf(Screen.MORE, Screen.INVESTMENTS, Screen.DEBTS, Screen.ASSETS, Screen.ZAKAT, Screen.SETTINGS)
                else -> false
            }
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(28.dp)) }
            )
        }
    }
}
// Placeholder for deleted old FinancialBottomBar content that we will remove in next step.
@Composable
fun MoreScreen(viewModel: FinancialViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(tr("nav_more", "More"), style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(bottom = 16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                MenuButtonCard(
                    title = "Fixed Investments",
                    subtitle = "",
                    icon = Icons.Filled.AccountBalance,
                    iconColor = Color(0xFF0288D1),
                    onClick = { viewModel.navigateTo(Screen.INVESTMENTS) },
                    isLocked = !viewModel.isScreenAllowed(Screen.INVESTMENTS)
                )
            }
            item {
                MenuButtonCard(
                    title = "Debt Tracker",
                    subtitle = "",
                    icon = Icons.Filled.Handshake,
                    iconColor = Color(0xFFD4AF37),
                    onClick = { viewModel.navigateTo(Screen.DEBTS) },
                    isLocked = !viewModel.isScreenAllowed(Screen.DEBTS)
                )
            }
            item {
                MenuButtonCard(
                    title = "Asset Tracker",
                    subtitle = "",
                    icon = Icons.Filled.BusinessCenter,
                    iconColor = MaterialTheme.colorScheme.secondary,
                    onClick = { viewModel.navigateTo(Screen.ASSETS) },
                    isLocked = !viewModel.isScreenAllowed(Screen.ASSETS)
                )
            }
            item {
                MenuButtonCard(
                    title = "Zakat Calculator",
                    subtitle = "",
                    icon = Icons.Filled.Star,
                    iconColor = Color(0xFFD4AF37),
                    onClick = { viewModel.navigateTo(Screen.ZAKAT) },
                    isLocked = !viewModel.isScreenAllowed(Screen.ZAKAT)
                )
            }
            item {
                MenuButtonCard(
                    title = tr("nav_settings", "Settings"),
                    subtitle = "",
                    icon = Icons.Filled.Settings,
                    iconColor = MaterialTheme.colorScheme.primary,
                    onClick = { viewModel.navigateTo(Screen.SETTINGS) }
                )
            }
        }
    }
}

// --- LOGIN & REGISTER SCREEN ---
@Composable
fun LoginScreen(viewModel: FinancialViewModel) {
    val hasRegistered by viewModel.hasRegistered.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    var nameInput by remember { mutableStateOf("") }
    var pinInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    // Registration Flow States
    var isRegisterMode by remember { mutableStateOf(false) }
    var registerStep by remember { mutableStateOf(1) }
    var registerMobile by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var registerPin by remember { mutableStateOf("") }
    var registerPinConfirm by remember { mutableStateOf("") }
    var isSendingOtp by remember { mutableStateOf(false) }
    var regErrorMessage by remember { mutableStateOf("") }
    var generatedOtp by remember { mutableStateOf("") }
    var useFirebaseOtp by remember { mutableStateOf(false) }
    var firebaseVerificationId by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecoveringGoogle by remember { mutableStateOf(false) }
    var autoLoginAttempted by remember { mutableStateOf(false) }

    val googleLoginEmail by viewModel.googleLoginEmail.collectAsStateWithLifecycle()
    val isSettingGoogleCredentials by viewModel.isSettingGoogleCredentials.collectAsStateWithLifecycle()
    val recoveryAccountInfo by viewModel.recoveryAccountInfo.collectAsStateWithLifecycle()
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        android.util.Log.d("FirebaseLogin", "ActivityResult received")
        val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.data)
        
        com.example.data.api.GoogleSignInHelper.handleGoogleSignInResult(
            task = task,
            onSuccess = { authResult ->
                android.util.Log.d("FirebaseLogin", "GoogleSignIn success")
                val firebaseUser = authResult.user
                if (firebaseUser != null) {
                    android.util.Log.d("FirebaseLogin", "FirebaseUser found: ${firebaseUser.uid}")
                    val uid = firebaseUser.uid
                    val email = firebaseUser.email ?: ""
                    
                    // Proceed with existing user mapping architecture using Firebase UID
                    viewModel.handleFirebaseLoginSuccess(uid, email)
                } else {
                    android.util.Log.e("FirebaseLogin", "FirebaseUser is null")
                    viewModel.showToast("Google Authentication failed: User is null")
                }
            },
            onError = { e ->
                android.util.Log.e("FirebaseLogin", "GoogleSignIn error: ${e.message}", e)
                viewModel.showToast("Google Authentication failed: ${e.message}")
            }
        )
    }

    LaunchedEffect(isLoggedIn) {
        if (!isLoggedIn && !autoLoginAttempted) {
            autoLoginAttempted = true
            // Only perform silent sign-in if specifically requested or if it's a known behavior to restore sessions.
            // Based on requirements, do NOT automatically trigger the account chooser.
            
            // To restore session, use FirebaseAuth to check current user
            val currentUser = FirebaseAuth.getInstance().currentUser
            if (currentUser != null) {
                viewModel.handleFirebaseLoginSuccess(currentUser.uid, currentUser.email ?: "")
            }
        }
    }

    val gradientColors = if (isDarkMode) {
        listOf(
            MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
            MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f),
            MaterialTheme.colorScheme.background
        )
    } else {
        listOf(
            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
            MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f),
            MaterialTheme.colorScheme.background
        )
    }
    val gradientBrush = Brush.verticalGradient(colors = gradientColors)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBrush),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            // App Branding Logo
            LogoComponent()
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = tr("app_name", "MAKS FINEX"),
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )

            Text(
                text = tr("app_subtitle", "Personal Finance & Business Manager"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_card")
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isSettingGoogleCredentials) {
                        Text(
                            text = tr("set_credentials_title", "Account Credentials Setup"),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = tr("set_credentials_subtitle", "Set your username and password/PIN to secure your ledger account."),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                        )

                        var setUsernameInput by remember { mutableStateOf("") }
                        var setPinInput by remember { mutableStateOf("") }
                        var setPinConfirmInput by remember { mutableStateOf("") }
                        var setCredsError by remember { mutableStateOf("") }

                        OutlinedTextField(
                            value = setUsernameInput,
                            onValueChange = { setUsernameInput = it },
                            label = { Text(tr("set_username_label", "Choose Username (Mobile)")) },
                            leadingIcon = { Icon(Icons.Filled.Person, null, tint = MaterialTheme.colorScheme.primary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = setPinInput,
                            onValueChange = { if (it.length <= 12) setPinInput = it },
                            label = { Text(tr("set_pin_label", "Set Password/PIN (4-12 digits)")) },
                            leadingIcon = { Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = setPinConfirmInput,
                            onValueChange = { if (it.length <= 12) setPinConfirmInput = it },
                            label = { Text(tr("confirm_pin_label", "Confirm Password/PIN")) },
                            leadingIcon = { Icon(Icons.Filled.Check, null, tint = MaterialTheme.colorScheme.primary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (setCredsError.isNotEmpty()) {
                            Text(
                                text = setCredsError,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 8.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.cancelGoogleCredentialsSetup() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(tr("cancel", "Cancel"))
                            }

                            val emptyUserPinErr = tr("err_empty_user_pin", "Please enter both username and PIN.")
                            val mismatchPinErr = tr("err_pin_mismatch", "PINs do not match!")
                            val invalidLengthPinErr = tr("err_pin_length", "PIN must be between 4 and 12 digits.")
                            val setupFailedErr = tr("err_setup_failed", "Setup failed. Username might be taken.")

                            Button(
                                onClick = {
                                    val u = setUsernameInput.trim()
                                    val p = setPinInput.trim()
                                    val c = setPinConfirmInput.trim()

                                    if (u.isEmpty() || p.isEmpty() || c.isEmpty()) {
                                        setCredsError = emptyUserPinErr
                                    } else if (p != c) {
                                        setCredsError = mismatchPinErr
                                    } else if (p.length !in 4..12 || !p.all { it.isDigit() }) {
                                        setCredsError = invalidLengthPinErr
                                    } else {
                                        val success = viewModel.saveGoogleCredentials(u, p)
                                        if (success) {
                                            setCredsError = ""
                                        } else {
                                            setCredsError = setupFailedErr
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(tr("submit", "Submit"))
                            }
                        }
                    } else if (!isRegisterMode) {
                        Text(
                            text = tr("login_welcome", "MAKS FINEX"),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text(tr("username_label", "Username (Mobile Number)")) },
                            leadingIcon = { Icon(Icons.Filled.Person, null, tint = MaterialTheme.colorScheme.primary) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("username_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 12) pinInput = it },
                            label = { Text(tr("pin_label", "PIN Code")) },
                            leadingIcon = { Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pin_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                isRecoveringGoogle = false
                                val client = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, com.example.data.api.GoogleSignInHelper.getGoogleSignInOptions(context))
                                googleSignInLauncher.launch(client.signInIntent)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Text(tr("google_login_btn", "Sign-In with Google"))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(
                            onClick = {
                                isRecoveringGoogle = true
                                val client = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, com.example.data.api.GoogleSignInHelper.getGoogleSignInOptions(context))
                                googleSignInLauncher.launch(client.signInIntent)
                            }
                        ) {
                            Text(
                                text = tr("forgot_creds_btn", "Forgot Username/Password? Recover with Gmail"),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (errorMessage.isNotEmpty()) {
                            Text(
                                text = errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 12.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        val unameEmpty = tr("err_empty_username", "Please enter your username.")
                        val pinEmpty = tr("err_empty_pin", "Please enter your PIN code.")
                        val invalidCreds = tr("err_invalid_credentials", "Invalid username or PIN! Please try again.")

                        Button(
                            onClick = {
                                if (nameInput.trim().isBlank()) {
                                    errorMessage = unameEmpty
                                } else if (pinInput.trim().isBlank()) {
                                    errorMessage = pinEmpty
                                } else {
                                    val success = viewModel.loginWithCredentials(nameInput, pinInput)
                                    if (!success) {
                                        errorMessage = invalidCreds
                                    } else {
                                        errorMessage = ""
                                        nameInput = ""
                                        pinInput = ""
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("login_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                                Text(
                                    text = tr("login_btn", "Login"),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        TextButton(
                            onClick = {
                                isRegisterMode = true
                                registerStep = 1
                                regErrorMessage = ""
                                registerMobile = ""
                                otpInput = ""
                                registerPin = ""
                                registerPinConfirm = ""
                            }
                        ) {
                            Text(
                                text = tr("first_time_user", "First time user? Continue / Verify mobile number"),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Text(
                            text = tr("register_title", "Create New Account"),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        when (registerStep) {
                            1 -> {
                                Text(
                                    text = tr("mobile_verification_info", "Enter your active mobile number. An OTP code will be sent to this number."),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )

                                // Select Auth Method
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Local Sandbox Option
                                    OutlinedButton(
                                        onClick = { useFirebaseOtp = false },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (!useFirebaseOtp) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent
                                        ),
                                        border = BorderStroke(
                                            width = 1.dp,
                                            color = if (!useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeveloperMode,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (!useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = tr("local_otp", "Local OTP"),
                                            fontSize = 11.sp,
                                            color = if (!useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Firebase Auth Option
                                    OutlinedButton(
                                        onClick = { useFirebaseOtp = true },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (useFirebaseOtp) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent
                                        ),
                                        border = BorderStroke(
                                            width = 1.dp,
                                            color = if (useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VpnKey,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = tr("firebase_otp", "Firebase OTP"),
                                            fontSize = 11.sp,
                                            color = if (useFirebaseOtp) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                // If Firebase OTP option is selected
                                if (useFirebaseOtp) {
                                    val isFbInit = com.example.data.api.FirebasePhoneAuthHelper.isFirebaseInitialized(context)
                                    if (!isFbInit) {
                                        // Firebase is not configured yet! Show setup instructions card.
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)
                                            ),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(bottom = 12.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = Icons.Default.Warning,
                                                        contentDescription = tr("warning", "Warning"),
                                                        tint = MaterialTheme.colorScheme.error,
                                                        modifier = Modifier.size(18.dp)
                                                     )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = tr("configure_firebase", "Configure Firebase Settings"),
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = MaterialTheme.colorScheme.error
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(
                                                    text = tr("firebase_steps_info", "To enable real SMS OTP, complete the following steps in your Firebase and Google Cloud Console:"),
                                                    fontSize = 11.sp,
                                                    lineHeight = 15.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                
                                                val instructions = listOf(
                                                    tr("firebase_step1", "1. Go to Firebase Console, create a project, and enable Phone under Authentication > Sign-in method."),
                                                    tr("firebase_step2", "2. Confirm that Identity Toolkit API is enabled for your project in Google Cloud Console."),
                                                    tr("firebase_step3", "3. Add your SHA-1 fingerprint in Firebase Project Settings under General tab."),
                                                    tr("firebase_step4", "4. Download google-services.json and place it inside the /app folder of your project.")
                                                )
                                                
                                                instructions.forEach { step ->
                                                    Text(
                                                        text = step,
                                                        fontSize = 10.sp,
                                                        lineHeight = 14.sp,
                                                        modifier = Modifier.padding(bottom = 4.dp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Divider(color = MaterialTheme.colorScheme.error.copy(alpha = 0.2f))
                                                Spacer(modifier = Modifier.height(6.dp))
                                                
                                                Text(
                                                    text = tr("firebase_tips", "💡 Tip: You can test registration without Firebase configuration too. Clicking 'Send OTP' below will activate a local simulation so you can proceed."),
                                                    fontSize = 10.sp,
                                                    lineHeight = 14.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    } else {
                                        // Firebase is configured successfully!
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                                            ),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(bottom = 12.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = tr("success", "Success"),
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Column {
                                                    Text(
                                                        text = tr("firebase_connected", "Firebase is successfully connected!"),
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                    Text(
                                                        text = tr("firebase_connected_desc", "A real SMS OTP will be sent directly to your number via Firebase."),
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                     )
                                                }
                                            }
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = registerMobile,
                                    onValueChange = {
                                        registerMobile = it
                                        regErrorMessage = ""
                                    },
                                    label = { Text(tr("mobile_label", "Mobile Number")) },
                                    leadingIcon = { Icon(Icons.Filled.Phone, null, tint = MaterialTheme.colorScheme.primary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                if (regErrorMessage.isNotEmpty()) {
                                    Text(
                                        text = regErrorMessage,
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                if (isSendingOtp) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(tr("sending_otp", "Sending OTP..."), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                } else {
                                    val emptyMobErr = tr("err_empty_mobile", "Please enter a mobile number.")
                                    val invalidMobErr = tr("err_invalid_mobile", "Please enter a valid Bangladeshi mobile number (e.g. 017XXXXXXXX).")
                                    val fbFallbackMsg = tr("err_firebase_fallback_msg", "Local simulation active due to unconfigured Firebase.")

                                    Button(
                                        onClick = {
                                            val cleanMob = registerMobile.trim()
                                            if (cleanMob.isBlank()) {
                                                regErrorMessage = emptyMobErr
                                            } else if (!com.example.data.api.BangladeshSmsHelper.isValidBangladeshiNumber(cleanMob)) {
                                                regErrorMessage = invalidMobErr
                                            } else {
                                                // SMS Service removed. Default to Firebase OTP or Simulation.
                                                isSendingOtp = true
                                                val code = (100000..999999).random().toString()
                                                generatedOtp = code
                                                scope.launch {
                                                    kotlinx.coroutines.delay(1000)
                                                    isSendingOtp = false
                                                    registerStep = 2
                                                    viewModel.showToast("OTP generated for verification.")
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(50.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(tr("send_otp", "Send OTP Code"), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            2 -> {
                                Text(
                                    text = tr("enter_otp_info", "Enter the OTP code sent to your mobile number."),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(bottom = 16.dp)
                                )

                                OutlinedTextField(
                                    value = otpInput,
                                    onValueChange = {
                                        otpInput = it
                                        regErrorMessage = ""
                                    },
                                    label = { Text(tr("otp_label", "6-Digit OTP Code")) },
                                    leadingIcon = { Icon(Icons.Filled.VpnKey, null, tint = MaterialTheme.colorScheme.primary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        if (useFirebaseOtp && com.example.data.api.FirebasePhoneAuthHelper.isFirebaseInitialized(context)) {
                                            Text(tr("firebase_otp_sent_info", "OTP sent via Firebase to your phone. Please enter the code here."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        } else {
                                            Text(tr("sent_otp_prefix", "Sent OTP Code: ") + generatedOtp + tr("test_otp_suffix", " (Testing Code: 123456)"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                    }
                                }

                                if (regErrorMessage.isNotEmpty()) {
                                    Text(
                                        text = regErrorMessage,
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                if (isSendingOtp) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(tr("verifying_otp", "Verifying OTP..."), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                } else {
                                    val invalidOtpErr = tr("err_invalid_otp_prefix", "Invalid OTP code! Please use ") + generatedOtp + tr("err_invalid_otp_suffix", " or 123456.")

                                    Button(
                                        onClick = {
                                            val typedOtp = otpInput.trim()
                                            if (useFirebaseOtp && firebaseVerificationId.isNotEmpty() && com.example.data.api.FirebasePhoneAuthHelper.isFirebaseInitialized(context)) {
                                                com.example.data.api.FirebasePhoneAuthHelper.verifySmsCode(context, firebaseVerificationId, typedOtp) {
                                                    registerStep = 3
                                                    regErrorMessage = ""
                                                }
                                            } else {
                                                if (typedOtp == generatedOtp || typedOtp == "123456" || typedOtp == "১২৩৪৫৬") {
                                                    registerStep = 3
                                                    regErrorMessage = ""
                                                } else {
                                                    regErrorMessage = invalidOtpErr
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(50.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(tr("verify_otp", "Verify OTP Code"), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            3 -> {
                                Text(
                                    text = tr("set_pin_info", "Set a 4-12 digit PIN or password for your account."),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(bottom = 16.dp)
                                )

                                OutlinedTextField(
                                    value = registerPin,
                                    onValueChange = {
                                        if (it.length <= 12) registerPin = it
                                        regErrorMessage = ""
                                    },
                                    label = { Text(tr("new_pin_label", "New PIN/Password")) },
                                    leadingIcon = { Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = registerPinConfirm,
                                    onValueChange = {
                                        if (it.length <= 12) registerPinConfirm = it
                                        regErrorMessage = ""
                                    },
                                    label = { Text(tr("confirm_pin_label", "Confirm PIN/Password")) },
                                    leadingIcon = { Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                if (regErrorMessage.isNotEmpty()) {
                                    Text(
                                        text = regErrorMessage,
                                        color = MaterialTheme.colorScheme.error,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                val emptyPinsErr = tr("err_empty_register_pins", "Please enter both PIN and confirm PIN.")
                                val pinsNoMatchErr = tr("err_pins_dont_match", "PINs do not match! Please enter carefully.")
                                val pinLengthErr = tr("err_invalid_pin_length", "PIN must be between 4 and 12 digits.")
                                val registerFailedErr = tr("err_register_failed", "Registration failed! Please try again.")

                                Button(
                                    onClick = {
                                        val pin = registerPin.trim()
                                        val confirm = registerPinConfirm.trim()
                                        if (pin.isBlank() || confirm.isBlank()) {
                                            regErrorMessage = emptyPinsErr
                                        } else if (pin != confirm) {
                                            regErrorMessage = pinsNoMatchErr
                                        } else if (pin.length !in 4..12 || !pin.all { it.isDigit() }) {
                                            regErrorMessage = pinLengthErr
                                        } else {
                                            val success = viewModel.registerUserWithMobile(registerMobile, pin)
                                            if (success) {
                                                isRegisterMode = false
                                            } else {
                                                regErrorMessage = registerFailedErr
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(tr("complete_register", "Complete Registration"), fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(onClick = { isRegisterMode = false }) {
                            Text(tr("back_to_login", "Go back to login screen"), fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }


        }

        // Floating Theme Toggle Button at Top-End (Right)
        IconButton(
            onClick = { viewModel.toggleTheme() },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 36.dp, end = 16.dp)
        ) {
            Icon(
                imageVector = if (isDarkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                contentDescription = if (isDarkMode) tr("light_mode", "Light Mode") else tr("dark_mode", "Dark Mode"),
                tint = if (isDarkMode) Color(0xFFFFD54F) else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
        }

        recoveryAccountInfo?.let { pair ->
            AlertDialog(
                onDismissRequest = { viewModel.clearRecoveryInfo() },
                title = {
                    Text(
                        text = tr("recovered_account_title", "Recovered Account Details"),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = tr("recovered_account_desc", "We found an account mapped to your Google Email:"),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = tr("recovered_username", "Username: ") + pair.first,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tr("recovered_pin", "Password/PIN: ") + pair.second,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.loginWithCredentials(pair.first, pair.second)
                            viewModel.clearRecoveryInfo()
                        }
                    ) {
                        Text(tr("login_now_btn", "Login Now"))
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.clearRecoveryInfo() }
                    ) {
                        Text(tr("close_btn", "Close"))
                    }
                }
            )
        }
    }
}

// --- DASHBOARD SCREEN ---
@Composable
fun LogoComponent() {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "MF",
            color = MaterialTheme.colorScheme.onPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp
        )
    }
}

@Composable
fun DashboardScreen(viewModel: FinancialViewModel) {
    val context = LocalContext.current
    val sharedPrefs = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
    val appUserId = sharedPrefs.getString("app_user_id", "User") ?: "User"
    
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val incomeTotal = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expenseTotal = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val balance = incomeTotal - expenseTotal

    // Monthly data
    val cal = Calendar.getInstance()
    val currentMonth = cal.get(Calendar.MONTH)
    val currentYear = cal.get(Calendar.YEAR)
    
    val monthlyTransactions = transactions.filter { 
        val tCal = Calendar.getInstance()
        tCal.time = Date(it.date)
        tCal.get(Calendar.MONTH) == currentMonth && tCal.get(Calendar.YEAR) == currentYear
    }
    val monthlyIncome = monthlyTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val monthlyExpense = monthlyTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)

    val financialItems = listOf(
        Triple(Screen.DAILY_TRANSACTIONS, tr("dashboard_transactions", "Transactions"), Icons.Filled.ReceiptLong),
        Triple(Screen.INVESTMENTS, "Fixed Investments", Icons.Filled.AccountBalance),
        Triple(Screen.DEBTS, "Debt Tracker", Icons.Filled.Handshake),
        Triple(Screen.ASSETS, "Asset Tracker", Icons.Filled.BusinessCenter),
        Triple(Screen.ZAKAT, "Zakat Calculator", Icons.Filled.Star)
    )

    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val showAds = entitlementState == com.example.security.EntitlementState.FREE

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                // Header
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LogoComponent()
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(tr("app_name", "MAKS FINEX"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(tr("app_subtitle", "Personal Finance & Business Manager"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.SETTINGS) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                // Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(tr("dashboard_balance", "Total Balance"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatTaka(balance), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(tr("dashboard_income", "Income"), style = MaterialTheme.typography.labelLarge)
                                Text(formatTaka(incomeTotal), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0F9D58))
                            }
                            Column {
                                Text(tr("dashboard_expense", "Expense"), style = MaterialTheme.typography.labelLarge)
                                Text(formatTaka(expenseTotal), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                            }
                        }
                    }
                }
            }

            item {
                // Monthly Summary
                Text(monthName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(tr("dashboard_income", "Income") + ": " + formatTaka(monthlyIncome), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF0F9D58))
                    Text(tr("dashboard_expense", "Expense") + ": " + formatTaka(monthlyExpense), style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD32F2F))
                }
            }
            
            item {
                // Quick Actions
                Text(tr("dashboard_quick_actions", "Quick Actions"), style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.navigateTo(Screen.DAILY_TRANSACTIONS) }, modifier = Modifier.weight(1f)) { Text(tr("dashboard_add_income", "Add Income")) }
                    Button(onClick = { viewModel.navigateTo(Screen.DAILY_TRANSACTIONS) }, modifier = Modifier.weight(1f)) { Text(tr("dashboard_add_expense", "Add Expense")) }
                }
            }
            
            item {
                Text(tr("dashboard_modules_financial", "Financial"), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp))
            }
            
            items(financialItems) { (screen, title, icon) ->
                MenuButtonCard(
                    title = title,
                    subtitle = "",
                    icon = icon,
                    iconColor = MaterialTheme.colorScheme.primary,
                    onClick = { viewModel.navigateTo(screen) },
                    isLocked = !viewModel.isScreenAllowed(screen),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
            }
            
            item {
                Text(tr("dashboard_modules_business", "Business"), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp))
                MenuButtonCard(
                    title = "Business Ledger",
                    subtitle = "",
                    icon = Icons.Filled.Storefront,
                    iconColor = Color(0xFF3F51B5),
                    onClick = { viewModel.navigateTo(Screen.BUSINESS_LEDGER) },
                    isLocked = !viewModel.isScreenAllowed(Screen.BUSINESS_LEDGER),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
                
                Text(tr("dashboard_modules_analytics", "Analytics"), style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp))
                MenuButtonCard(
                    title = "Reports",
                    subtitle = "",
                    icon = Icons.Filled.BarChart,
                    iconColor = EmeraldPrimary,
                    onClick = { viewModel.navigateTo(Screen.REPORTS) },
                    isLocked = !viewModel.isScreenAllowed(Screen.REPORTS),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
            }
        }

        if (showAds) {
            AdMobBanner(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )
        }
    }
}

@Composable
fun DashboardMiniCard(
    title: String,
    value: Double,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(
                width = 1.dp,
                color = color.copy(alpha = 0.15f),
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = String.format(Locale.US, "৳%,.0f", value),
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MenuButtonCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLocked: Boolean = false
) {
    val alphaValue = if (isLocked) 0.5f else 1.0f
    Card(
        modifier = modifier
            .alpha(alphaValue)
            .clickable { onClick() }
            .border(
                width = 1.dp,
                color = if (isLocked) Color.Transparent else iconColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = title, tint = iconColor, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = subtitle,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
            }
            if (isLocked) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked",
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "পেইজে প্রবেশ করুন",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun TransactionRow(transaction: Transaction, onDelete: () -> Unit) {
    val (color, typeText, sign) = when (transaction.type) {
        "INCOME" -> Triple(EmeraldPrimary, tr("income_label", "Income"), "+")
        "EXPENSE" -> Triple(Color(0xFFE53935), tr("expense_label", "Expense"), "-")
        else -> Triple(DeepTeal, tr("savings_label", "Savings"), "•")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when (transaction.type) {
                        "INCOME" -> Icons.Filled.TrendingUp
                        "EXPENSE" -> Icons.Filled.TrendingDown
                        else -> Icons.Filled.Savings
                    }
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (transaction.description.isNotBlank()) transaction.description else transaction.category,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${transaction.category} • ${formatDate(transaction.date)}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$sign ${formatTaka(transaction.amount)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = color
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = tr("delete_button", "Delete"),
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// --- DAILY TRANSACTIONS SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyTransactionsScreen(viewModel: FinancialViewModel) {
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }

    var amount by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("EXPENSE") } // INCOME, EXPENSE, SAVINGS
    var selectedCategory by remember { mutableStateOf("খাবার") }
    var desc by remember { mutableStateOf("") }

    val incomeCategories by viewModel.incomeCategories.collectAsStateWithLifecycle()
    val expenseCategories by viewModel.expenseCategories.collectAsStateWithLifecycle()
    val savingsCategories by viewModel.savingsCategories.collectAsStateWithLifecycle()

    val categories = when (selectedType) {
        "INCOME" -> incomeCategories
        "EXPENSE" -> expenseCategories
        else -> savingsCategories
    }

    LaunchedEffect(selectedType) {
        selectedCategory = categories.first()
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_transaction_fab")
            ) {
                Icon(Icons.Filled.Add, "লেনদেন যোগ করুন")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Stats Header
            val incomeTotal = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
            val expenseTotal = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
            val savingsTotal = transactions.filter { it.type == "SAVINGS" }.sumOf { it.amount }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tr("total_income", "Total Income"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        Text(formatTaka(incomeTotal), fontSize = 14.sp, fontWeight = FontWeight.Black, color = EmeraldPrimary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tr("total_expense", "Total Expense"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE53935))
                        Text(formatTaka(expenseTotal), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color(0xFFE53935))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tr("total_savings", "Total Savings"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                        Text(formatTaka(savingsTotal), fontSize = 14.sp, fontWeight = FontWeight.Black, color = DeepTeal)
                    }
                }
            }

            if (transactions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Filled.ReceiptLong, "", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(tr("no_transactions", "No transactions yet!"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(tr("no_transactions_desc", "Add your first income or expense to start tracking your finances."), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), textAlign = TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(transactions) { tx ->
                        TransactionRow(transaction = tx, onDelete = { viewModel.deleteTransaction(tx.id) })
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(tr("add_transaction", "Add Transaction"), fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Type Selector Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(2.dp)
                    ) {
                        val types = listOf("INCOME" to tr("income_label", "Income"), "EXPENSE" to tr("expense_label", "Expense"), "SAVINGS" to tr("savings_label", "Savings"))
                        types.forEach { (typeKey, label) ->
                            val isSelected = selectedType == typeKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { selectedType = typeKey }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text(tr("amount_label", "Amount (BDT)")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tx_amount_input")
                    )
                    
                    // Category Selector
                    Text(tr("category_label", "Select Category"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        categories.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable {
                                                viewModel.removeCustomCategory(selectedType, cat)
                                                if (selectedCategory == cat) {
                                                    selectedCategory = categories.firstOrNull { it != cat } ?: ""
                                                }
                                            }
                                    )
                                }
                            )
                        }
                    }

                    // Dynamic category input inline
                    var showNewCatInput by remember { mutableStateOf(false) }
                    var newCatName by remember { mutableStateOf("") }

                    if (showNewCatInput) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = newCatName,
                                onValueChange = { newCatName = it },
                                label = { Text("নতুন ক্যাটাগরি") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )
                            Button(
                                onClick = {
                                    val trimName = newCatName.trim()
                                    if (trimName.isNotBlank()) {
                                        viewModel.addCustomCategory(selectedType, trimName)
                                        selectedCategory = trimName
                                        newCatName = ""
                                        showNewCatInput = false
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("যোগ", fontSize = 12.sp)
                            }
                            TextButton(
                                onClick = { showNewCatInput = false },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("বাতিল", fontSize = 12.sp)
                            }
                        }
                    } else {
                        TextButton(
                            onClick = { showNewCatInput = true },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন ক্যাটাগরি তৈরি করুন", fontSize = 11.sp)
                        }
                    }

                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("বিবরণ (ঐচ্ছিক)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAmount = amount.toDoubleOrNull()
                        if (parsedAmount != null && parsedAmount > 0) {
                            viewModel.addTransaction(
                                type = selectedType,
                                amount = parsedAmount,
                                category = selectedCategory,
                                description = desc
                            )
                            // Reset and close
                            amount = ""
                            desc = ""
                            showDialog = false
                        }
                    },
                    modifier = Modifier.testTag("tx_submit_btn")
                ) {
                    Text("যোগ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

// --- FIXED INVESTMENTS SCREEN (DPS / FDR) ---
@Composable
fun FixedInvestmentsScreen(viewModel: FinancialViewModel) {
    val investments by viewModel.fixedInvestments.collectAsStateWithLifecycle()
    val investmentCategories by viewModel.investmentCategories.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }

    var selectedType by remember { mutableStateOf("") } // DPS, FDR, Sanchayapatra, etc.
    LaunchedEffect(investmentCategories) {
        if (selectedType.isEmpty() && investmentCategories.isNotEmpty()) {
            selectedType = investmentCategories.first()
        }
    }
    var institutionName by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var durationMonths by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var investmentDate by remember { mutableStateOf(System.currentTimeMillis()) }

    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Add, "যুক্ত করুন")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            val totalInvestment = investments.sumOf { it.amount }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("মোট স্থায়ী বিনিয়োগের পরিমাণ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(formatTaka(totalInvestment), fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }

            if (investments.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.AccountBalance, "", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("কোনো স্থায়ী বিনিয়োগ বা প্রজেক্ট রেকর্ড নেই।", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(investments) { inv ->
                        InvestmentCard(
                            investment = inv,
                            viewModel = viewModel,
                            onDelete = { viewModel.deleteFixedInvestment(inv.id) }
                        )
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন বিনিয়োগ যুক্ত করুন", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text("বিনিয়োগের ধরণ নির্বাচন করুন:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        investmentCategories.forEach { cat ->
                            val isSelected = selectedType == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedType = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable {
                                                viewModel.removeCustomCategory("INVESTMENT", cat)
                                                if (selectedType == cat) {
                                                    selectedType = investmentCategories.firstOrNull { it != cat } ?: ""
                                                }
                                              }
                                    )
                                }
                            )
                        }
                    }

                    // Dynamic category input inline
                    var showNewCatInput by remember { mutableStateOf(false) }
                    var newCatName by remember { mutableStateOf("") }

                    if (showNewCatInput) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = newCatName,
                                onValueChange = { newCatName = it },
                                label = { Text("নতুন ধরণ/ক্যাটাগরি") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )
                            Button(
                                onClick = {
                                    val trimName = newCatName.trim()
                                    if (trimName.isNotBlank()) {
                                        viewModel.addCustomCategory("INVESTMENT", trimName)
                                        selectedType = trimName
                                        newCatName = ""
                                        showNewCatInput = false
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("যোগ", fontSize = 12.sp)
                            }
                            TextButton(
                                onClick = { showNewCatInput = false },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("বাতিল", fontSize = 12.sp)
                            }
                        }
                    } else {
                        TextButton(
                            onClick = { showNewCatInput = true },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন ধরণ/ক্যাটাগরি তৈরি করুন", fontSize = 11.sp)
                        }
                    }

                    OutlinedTextField(
                        value = institutionName,
                        onValueChange = { institutionName = it },
                        label = { Text("প্রজেক্ট বা প্রতিষ্ঠানের নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("বিনিয়োগের পরিমাণ (টাকা)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Date Picker Trigger Button
                    OutlinedButton(
                        onClick = {
                            val calendar = Calendar.getInstance().apply { timeInMillis = investmentDate }
                            val dpd = android.app.DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val selCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, y)
                                        set(Calendar.MONTH, m)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    investmentDate = selCal.timeInMillis
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )
                            dpd.show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.CalendarMonth, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("তারিখ: ${formatDate(investmentDate)}")
                    }

                    OutlinedTextField(
                        value = interestRate,
                        onValueChange = { interestRate = it },
                        label = { Text("মুনাফার হার % (ঐচ্ছিক)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = durationMonths,
                        onValueChange = { durationMonths = it },
                        label = { Text("মেয়াদ (মাস)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("বিবরণ (ঐচ্ছিক)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAmount = amount.toDoubleOrNull()
                        if (parsedAmount != null && parsedAmount > 0 && institutionName.isNotBlank()) {
                            val parsedRate = interestRate.toDoubleOrNull() ?: 0.0
                            val parsedDuration = durationMonths.toIntOrNull() ?: 12
                            viewModel.addFixedInvestment(
                                type = selectedType,
                                institutionName = institutionName,
                                amount = parsedAmount,
                                interestRate = parsedRate,
                                durationMonths = parsedDuration,
                                description = description,
                                date = investmentDate
                            )
                            // Reset & dismiss
                            institutionName = ""
                            amount = ""
                            interestRate = ""
                            durationMonths = ""
                            description = ""
                            investmentDate = System.currentTimeMillis()
                            showDialog = false
                        }
                    }
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun InvestmentCard(
    investment: FixedInvestment,
    viewModel: FinancialViewModel,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }
    var showAddTxDialog by remember { mutableStateOf(false) }

    val durationText = "${investment.durationMonths} মাস"
    val maturityValue = if (investment.interestRate > 0) {
        val totalInterest = investment.amount * (investment.interestRate / 100.0) * (investment.durationMonths / 12.0)
        investment.amount + totalInterest
    } else {
        investment.amount
    }

    val records = remember(investment.transactionsJson) {
        if (investment.transactionsJson.isBlank()) {
            listOf(
                InvestmentRecord(
                    id = "initial",
                    type = "INVESTMENT",
                    amount = investment.amount,
                    date = investment.startDate,
                    description = "প্রাথমিক বিনিয়োগ"
                )
            )
        } else {
            InvestmentJsonParser.fromJson(investment.transactionsJson)
        }
    }

    val totalInvested = records.filter { it.type == "INVESTMENT" }.sumOf { it.amount }
    val totalReturned = records.filter { it.type == "RETURN" }.sumOf { it.amount }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.AccountBalance, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(investment.institutionName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("${investment.type} • $durationText", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Expand/Collapse",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("মোট বিনিয়োগ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    Text(formatTaka(totalInvested), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("মোট রিটার্ন/লাভ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    Text(formatTaka(totalReturned), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("মেয়াদান্তে সম্ভাব্য মূল্য", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    Text(formatTaka(maturityValue), fontSize = 14.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            }

            if (investment.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "নোট: ${investment.description}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("লেনদেনের ইতিহাস", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    
                    OutlinedButton(
                        onClick = { showAddTxDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Filled.Add, null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("নতুন লেনদেন", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (records.isEmpty()) {
                    Text("কোনো লেনদেন রেকর্ড নেই।", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        records.sortedByDescending { it.date }.forEach { record ->
                            val isInvestment = record.type == "INVESTMENT"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isInvestment) EmeraldPrimary.copy(alpha = 0.15f)
                                                else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isInvestment) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                            contentDescription = null,
                                            tint = if (isInvestment) EmeraldPrimary else MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            if (isInvestment) "বিনিয়োগ করা হয়েছে"
                                            else "রিটার্ন / লাভ এসেছে",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = formatDate(record.date),
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                        )
                                        if (record.description.isNotBlank()) {
                                            Text(record.description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        }
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${if (isInvestment) "+" else "-"} ${formatTaka(record.amount)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isInvestment) EmeraldPrimary else MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteInvestmentTransaction(investment.id, record.id)
                                        },
                                        modifier = Modifier.size(20.dp),
                                        enabled = records.size > 1 // Do not delete the only record left
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Delete record",
                                            tint = if (records.size > 1) MaterialTheme.colorScheme.error.copy(alpha = 0.6f) else Color.Gray.copy(alpha = 0.3f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddTxDialog) {
        var txType by remember { mutableStateOf("INVESTMENT") }
        var txAmount by remember { mutableStateOf("") }
        var txDate by remember { mutableStateOf(System.currentTimeMillis()) }
        var txDescription by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddTxDialog = false },
            title = { Text("নতুন লেনদেন যোগ করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text("লেনদেনের ধরণ:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(2.dp)
                    ) {
                        val items = listOf("INVESTMENT" to "বিনিয়োগ (সংযোজন)", "RETURN" to "রিটার্ন (লাভ/উত্তোলন)")
                        items.forEach { (key, label) ->
                            val isSelected = txType == key
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { txType = key }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = txAmount,
                        onValueChange = { txAmount = it },
                        label = { Text("টাকার পরিমাণ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Date Picker Trigger
                    OutlinedButton(
                        onClick = {
                            val calendar = Calendar.getInstance().apply { timeInMillis = txDate }
                            val dpd = android.app.DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val selCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, y)
                                        set(Calendar.MONTH, m)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    txDate = selCal.timeInMillis
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )
                            dpd.show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.CalendarMonth, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("তারিখ: ${formatDate(txDate)}")
                    }

                    OutlinedTextField(
                        value = txDescription,
                        onValueChange = { txDescription = it },
                        label = { Text("বিবরণ / নোট") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAmount = txAmount.toDoubleOrNull()
                        if (parsedAmount != null && parsedAmount > 0) {
                            viewModel.addInvestmentTransaction(
                                investmentId = investment.id,
                                type = txType,
                                amount = parsedAmount,
                                date = txDate,
                                description = txDescription.trim()
                            )
                            showAddTxDialog = false
                        }
                    }
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTxDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

// --- DEBTS & LOANS SCREEN ---
@Composable
fun DebtsScreen(viewModel: FinancialViewModel) {
    val debts by viewModel.debts.collectAsStateWithLifecycle()
    val debtCategories by viewModel.debtCategories.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()

    var showDialog by remember { mutableStateOf(false) }
    var selectedType by remember { mutableStateOf("LENT") } // LENT, REPAY_LENT, BORROWED, REPAY_BORROWED
    var selectedCategory by remember { mutableStateOf("") }
    LaunchedEffect(debtCategories) {
        if (selectedCategory.isEmpty() && debtCategories.isNotEmpty()) {
            selectedCategory = debtCategories.first()
        }
    }

    var personName by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var transactionDate by remember { mutableStateOf(System.currentTimeMillis()) }

    var currentTab by remember { mutableStateOf("PERSONS") } // PERSONS, TRANSACTIONS
    val expandedPersons = remember { mutableStateMapOf<String, Boolean>() }
    var activePdfFile by remember { mutableStateOf<File?>(null) }

    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    personName = ""
                    selectedType = "LENT"
                    amount = ""
                    description = ""
                    transactionDate = System.currentTimeMillis()
                    showDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Add, "যুক্ত করুন")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // Summary Card
            val totalLentGross = debts.filter { it.type == "LENT" }.sumOf { it.amount }
            val totalRepayLentGross = debts.filter { it.type == "REPAY_LENT" }.sumOf { it.amount }
            val netLent = totalLentGross - totalRepayLentGross

            val totalBorrowedGross = debts.filter { it.type == "BORROWED" }.sumOf { it.amount }
            val totalRepayBorrowedGross = debts.filter { it.type == "REPAY_BORROWED" }.sumOf { it.amount }
            val netBorrowed = totalBorrowedGross - totalRepayBorrowedGross

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("মোট পাবো (পাওনা)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        Text(formatTaka(maxOf(0.0, netLent)), fontSize = 15.sp, fontWeight = FontWeight.Black, color = EmeraldPrimary)
                        Text("আদায়: ${formatTaka(totalRepayLentGross)} / ${formatTaka(totalLentGross)}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                    Box(modifier = Modifier.width(1.dp).height(40.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("মোট দেবো (দেনা)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE53935))
                        Text(formatTaka(maxOf(0.0, netBorrowed)), fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color(0xFFE53935))
                        Text("পরিশোধ: ${formatTaka(totalRepayBorrowedGross)} / ${formatTaka(totalBorrowedGross)}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                    }
                }
            }

            // Tab Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(4.dp)
            ) {
                val tabs = listOf("PERSONS" to "ব্যক্তি ভিত্তিক হিসাব", "TRANSACTIONS" to "সকল লেনদেনের তালিকা")
                tabs.forEach { (tabId, label) ->
                    val isSelected = currentTab == tabId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { currentTab = tabId }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            if (debts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Handshake, "", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("ঋণ আদান-প্রদানের কোনো তথ্য রেকর্ড নেই।", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            } else {
                when (currentTab) {
                    "PERSONS" -> {
                        val groupedByPerson = remember(debts) {
                            debts.groupBy { it.personName.trim().lowercase() }
                        }

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(groupedByPerson.keys.toList().sorted()) { key ->
                                val personDebts = groupedByPerson[key] ?: emptyList()
                                val actualPersonName = personDebts.firstOrNull()?.personName ?: key

                                val pLent = personDebts.filter { it.type == "LENT" }.sumOf { it.amount }
                                val pRepayLent = personDebts.filter { it.type == "REPAY_LENT" }.sumOf { it.amount }
                                val pNetLent = pLent - pRepayLent

                                val pBorrowed = personDebts.filter { it.type == "BORROWED" }.sumOf { it.amount }
                                val pRepayBorrowed = personDebts.filter { it.type == "REPAY_BORROWED" }.sumOf { it.amount }
                                val pNetBorrowed = pBorrowed - pRepayBorrowed

                                val pFinalNet = pNetLent - pNetBorrowed
                                val isExpanded = expandedPersons[key] ?: false

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isExpanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(
                                        width = 1.dp,
                                        color = if (isExpanded) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                                    )
                                ) {
                                    Column(modifier = Modifier.fillMaxWidth()) {
                                        // Card Header
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { expandedPersons[key] = !isExpanded }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Icon(
                                                    imageVector = Icons.Filled.Person,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(
                                                        text = actualPersonName,
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = "${personDebts.size}টি লেনদেন",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                                    )
                                                }
                                            }

                                            // Status Badge
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    shape = RoundedCornerShape(20.dp),
                                                    color = when {
                                                        pFinalNet > 0 -> EmeraldPrimary.copy(alpha = 0.12f)
                                                        pFinalNet < 0 -> Color(0xFFE53935).copy(alpha = 0.12f)
                                                        else -> Color.Gray.copy(alpha = 0.12f)
                                                    },
                                                    modifier = Modifier.padding(end = 8.dp)
                                                ) {
                                                    Text(
                                                        text = when {
                                                            pFinalNet > 0 -> "পাবেন: ${formatTaka(pFinalNet)}"
                                                            pFinalNet < 0 -> "দেবেন: ${formatTaka(-pFinalNet)}"
                                                            else -> "পরিশোধিত"
                                                        },
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Black,
                                                        color = when {
                                                            pFinalNet > 0 -> EmeraldPrimary
                                                            pFinalNet < 0 -> Color(0xFFE53935)
                                                            else -> Color.Gray
                                                        },
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                                Icon(
                                                    imageVector = if (isExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        // Expanded Details Section
                                        if (isExpanded) {
                                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                // Numerical Breakdown cards
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    if (pLent > 0) {
                                                        Card(
                                                            modifier = Modifier.weight(1f),
                                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                                            border = BorderStroke(0.5.dp, EmeraldPrimary.copy(alpha = 0.2f))
                                                        ) {
                                                            Column(modifier = Modifier.padding(8.dp)) {
                                                                Text("প্রদত্ত ঋণ হিসাব:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                                                Text("দেওয়া: ${formatTaka(pLent)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                                Text("আদায়: ${formatTaka(pRepayLent)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                                Text("বাকি: ${formatTaka(maxOf(0.0, pNetLent))}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                                            }
                                                        }
                                                    }
                                                    if (pBorrowed > 0) {
                                                        Card(
                                                            modifier = Modifier.weight(1f),
                                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                                            border = BorderStroke(0.5.dp, Color(0xFFE53935).copy(alpha = 0.2f))
                                                        ) {
                                                            Column(modifier = Modifier.padding(8.dp)) {
                                                                Text("গৃহীত ঋণ হিসাব:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE53935))
                                                                Text("নেওয়া: ${formatTaka(pBorrowed)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                                Text("পরিশোধ: ${formatTaka(pRepayBorrowed)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                                                                Text("বাকি: ${formatTaka(maxOf(0.0, pNetBorrowed))}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE53935))
                                                            }
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text("লেনদেনের খতিয়ান:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Spacer(modifier = Modifier.height(4.dp))

                                                // Person's individual transaction list
                                                personDebts.sortedByDescending { it.date }.forEach { debt ->
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            val (typeLabel, sign, color) = when (debt.type) {
                                                                "LENT" -> Triple("ঋণ দিয়েছি", "+", EmeraldPrimary)
                                                                "REPAY_LENT" -> Triple("ফেরত পেয়েছি (আদায়)", "-", Color(0xFFE53935))
                                                                "BORROWED" -> Triple("ঋণ নিয়েছি", "+", Color(0xFFE53935))
                                                                "REPAY_BORROWED" -> Triple("ফেরত দিয়েছি (শোধ)", "-", EmeraldPrimary)
                                                                else -> Triple(debt.type, "", MaterialTheme.colorScheme.onSurface)
                                                            }
                                                            Text(
                                                                text = "$typeLabel • ${formatDate(debt.date)}",
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = color
                                                            )
                                                            if (debt.description.isNotBlank()) {
                                                                Text(
                                                                    text = debt.description,
                                                                    fontSize = 10.sp,
                                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                                )
                                                            }
                                                        }
                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                            Text(
                                                                text = formatTaka(debt.amount),
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = when (debt.type) {
                                                                    "LENT", "REPAY_BORROWED" -> EmeraldPrimary
                                                                    else -> Color(0xFFE53935)
                                                                }
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            IconButton(
                                                                onClick = { viewModel.deleteDebt(debt.id) },
                                                                modifier = Modifier.size(24.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Filled.Delete,
                                                                    contentDescription = "মুছুন",
                                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f),
                                                                    modifier = Modifier.size(16.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.05f))
                                                }

                                                Spacer(modifier = Modifier.height(12.dp))

                                                // Action Row
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedButton(
                                                        onClick = {
                                                            personName = actualPersonName
                                                            selectedType = if (pFinalNet <= 0) "LENT" else "REPAY_LENT"
                                                            amount = ""
                                                            description = ""
                                                            transactionDate = System.currentTimeMillis()
                                                            showDialog = true
                                                        },
                                                        modifier = Modifier.weight(1.2f),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                                    ) {
                                                        Icon(Icons.Filled.Add, null, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("লেনদেন যোগ", fontSize = 11.sp)
                                                    }

                                                    Button(
                                                        onClick = {
                                                            activePdfFile = PdfReportHelper.generatePersonDebtsReportPdf(
                                                                context,
                                                                userName,
                                                                actualPersonName,
                                                                personDebts
                                                            )
                                                        },
                                                        modifier = Modifier.weight(1.1f),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                                    ) {
                                                        Icon(Icons.Filled.PictureAsPdf, null, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("পিডিএফ ডাউনলোড", fontSize = 11.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "TRANSACTIONS" -> {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(debts.sortedByDescending { it.date }) { debt ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .padding(12.dp)
                                            .fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(
                                                imageVector = Icons.Filled.Person,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                val typeText = when (debt.type) {
                                                    "LENT" -> "ঋণ দিয়েছি"
                                                    "REPAY_LENT" -> "আদায় (পাওনা শোধ)"
                                                    "BORROWED" -> "ঋণ নিয়েছি"
                                                    "REPAY_BORROWED" -> "পরিশোধ (দেনা শোধ)"
                                                    else -> debt.type
                                                }
                                                Text(
                                                    text = debt.personName,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "$typeText • ${formatDate(debt.date)}",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                                )
                                                if (debt.description.isNotBlank()) {
                                                    Text(
                                                        text = debt.description,
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                                    )
                                                }
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            val color = when (debt.type) {
                                                "LENT", "REPAY_BORROWED" -> EmeraldPrimary
                                                else -> Color(0xFFE53935)
                                            }
                                            Text(
                                                text = formatTaka(debt.amount),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                color = color
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            IconButton(onClick = { viewModel.deleteDebt(debt.id) }, modifier = Modifier.size(24.dp)) {
                                                Icon(
                                                    imageVector = Icons.Filled.Delete,
                                                    contentDescription = "মুছুন",
                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // PDF Share & View Dialog
    if (activePdfFile != null) {
        val file = activePdfFile!!
        AlertDialog(
            onDismissRequest = { activePdfFile = null },
            title = { Text("রিপোর্ট ফাইল প্রস্তুত", fontWeight = FontWeight.Bold) },
            text = { Text("আপনার পছন্দসই ঋণ খতিয়ান রিপোর্ট ফাইলটি সফলভাবে তৈরি হয়েছে। এটি শেয়ার করতে চান নাকি প্রিন্ট করতে চান?") },
            confirmButton = {
                Button(
                    onClick = {
                        PdfReportHelper.sharePdf(context, file)
                        activePdfFile = null
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("শেয়ার ও সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        PdfReportHelper.printPdf(context, file)
                        activePdfFile = null
                    }
                ) {
                    Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("সরাসরি প্রিন্ট")
                }
            }
        )
    }

    // Unified New Transaction Dialog
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন ঋণ রেকর্ড করুন", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text("লেনদেনের ধরণ সিলেক্ট করুন:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    
                    // Grid pattern for 4-way type selector
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val row1 = listOf("LENT" to "ঋণ দিয়েছি (পাওনা)", "REPAY_LENT" to "ফেরত পেয়েছি (আদায়)")
                        val row2 = listOf("BORROWED" to "ঋণ নিয়েছি (দেনা)", "REPAY_BORROWED" to "ফেরত দিয়েছি (পরিশোধ)")
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row1.forEach { (key, label) ->
                                val isSelected = selectedType == key
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { selectedType = key }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        label,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row2.forEach { (key, label) ->
                                val isSelected = selectedType == key
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) Color(0xFFE53935) else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { selectedType = key }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        label,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = personName,
                        onValueChange = { personName = it },
                        label = { Text("ব্যক্তির নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("টাকার পরিমাণ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Date Picker Trigger Button
                    OutlinedButton(
                        onClick = {
                            val calendar = Calendar.getInstance().apply { timeInMillis = transactionDate }
                            val dpd = android.app.DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val selCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, y)
                                        set(Calendar.MONTH, m)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    transactionDate = selCal.timeInMillis
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            )
                            dpd.show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.CalendarMonth, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("তারিখ: ${formatDate(transactionDate)}")
                    }

                    // Debts category selection
                    Text("ঋণের ধরণ/ক্যাটাগরি:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        debtCategories.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable {
                                                viewModel.removeCustomCategory("DEBT", cat)
                                                if (selectedCategory == cat) {
                                                    selectedCategory = debtCategories.firstOrNull { it != cat } ?: ""
                                                }
                                            }
                                    )
                                }
                            )
                        }
                    }

                    // Dynamic category input inline
                    var showNewCatInput by remember { mutableStateOf(false) }
                    var newCatName by remember { mutableStateOf("") }

                    if (showNewCatInput) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = newCatName,
                                onValueChange = { newCatName = it },
                                label = { Text("নতুন ক্যাটাগরি") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )
                            Button(
                                onClick = {
                                    val trimName = newCatName.trim()
                                    if (trimName.isNotBlank()) {
                                        viewModel.addCustomCategory("DEBT", trimName)
                                        selectedCategory = trimName
                                        newCatName = ""
                                        showNewCatInput = false
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("যোগ", fontSize = 12.sp)
                            }
                            TextButton(
                                onClick = { showNewCatInput = false },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("বাতিল", fontSize = 12.sp)
                            }
                        }
                    } else {
                        TextButton(
                            onClick = { showNewCatInput = true },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন ক্যাটাগরি তৈরি করুন", fontSize = 11.sp)
                        }
                    }

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("বিবরণ/মেয়াদ (ঐচ্ছিক)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedAmount = amount.toDoubleOrNull()
                        if (parsedAmount != null && parsedAmount > 0 && personName.isNotBlank()) {
                            val finalDescription = if (selectedCategory.isNotBlank()) "[$selectedCategory] $description" else description
                            viewModel.addDebt(
                                type = selectedType,
                                personName = personName,
                                amount = parsedAmount,
                                description = finalDescription,
                                date = transactionDate
                            )
                            // Reset and close
                            personName = ""
                            amount = ""
                            description = ""
                            showDialog = false
                        }
                    }
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun DebtRow(debt: Debt, onToggleSettled: () -> Unit, onDelete: () -> Unit) {
    val color = if (debt.isSettled) {
        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
    } else if (debt.type == "LENT") {
        EmeraldPrimary
    } else {
        Color(0xFFE53935)
    }

    val typeLabel = if (debt.type == "LENT") "দিয়েছি (পাবো)" else "নিয়েছি (দেবো)"

    val categoryTag = if (debt.description.startsWith("[") && debt.description.contains("]")) {
        debt.description.substringBefore("]").removePrefix("[")
    } else {
        ""
    }
    val displayDesc = if (categoryTag.isNotEmpty()) {
        debt.description.substringAfter("]").trim()
    } else {
        debt.description
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (debt.isSettled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(
                    checked = debt.isSettled,
                    onCheckedChange = { onToggleSettled() }
                )
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = debt.personName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (debt.isSettled) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
                        )
                        if (categoryTag.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                            ) {
                                Text(
                                    text = categoryTag,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "$typeLabel • ${formatDate(debt.date)}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                    if (displayDesc.isNotBlank()) {
                        Text(
                            text = displayDesc,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = formatTaka(debt.amount),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = color
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

// --- TOTAL ASSET MANAGEMENT SCREEN ---
@Composable
fun AssetsScreen(viewModel: FinancialViewModel) {
    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val assetCategories by viewModel.assetCategories.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }

    var assetName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    LaunchedEffect(assetCategories) {
        if (selectedCategory.isEmpty() && assetCategories.isNotEmpty()) {
            selectedCategory = assetCategories.first()
        }
    }
    var assetValue by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Add, "সম্পদ যুক্ত করুন")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            val totalAssetsVal = assets.sumOf { it.value }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("মোট সম্পদের আর্থিক মূল্য", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(formatTaka(totalAssetsVal), fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }

            if (assets.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.BusinessCenter, "", modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("সম্পদের কোনো তথ্য লিপিবদ্ধ নেই।", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(assets) { asset ->
                        AssetRow(asset = asset, onDelete = { viewModel.deleteAsset(asset.id) })
                    }
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন সম্পদ লিপিবদ্ধ করুন", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = assetName,
                        onValueChange = { assetName = it },
                        label = { Text("সম্পদের নাম/বিবরণ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Categories Selector Chips
                    Text("সম্পদের ক্যাটাগরি:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        assetCategories.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable {
                                                viewModel.removeCustomCategory("ASSET", cat)
                                                if (selectedCategory == cat) {
                                                    selectedCategory = assetCategories.firstOrNull { it != cat } ?: ""
                                                }
                                            }
                                    )
                                }
                            )
                        }
                    }

                    // Dynamic category input inline
                    var showNewCatInput by remember { mutableStateOf(false) }
                    var newCatName by remember { mutableStateOf("") }

                    if (showNewCatInput) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = newCatName,
                                onValueChange = { newCatName = it },
                                label = { Text("নতুন ক্যাটাগরি") },
                                singleLine = true,
                                modifier = Modifier.weight(1.5f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                            )
                            Button(
                                onClick = {
                                    val trimName = newCatName.trim()
                                    if (trimName.isNotBlank()) {
                                        viewModel.addCustomCategory("ASSET", trimName)
                                        selectedCategory = trimName
                                        newCatName = ""
                                        showNewCatInput = false
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("যোগ", fontSize = 12.sp)
                            }
                            TextButton(
                                onClick = { showNewCatInput = false },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("বাতিল", fontSize = 12.sp)
                            }
                        }
                    } else {
                        TextButton(
                            onClick = { showNewCatInput = true },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("নতুন ক্যাটাগরি তৈরি করুন", fontSize = 11.sp)
                        }
                    }

                    OutlinedTextField(
                        value = assetValue,
                        onValueChange = { assetValue = it },
                        label = { Text("বর্তমান বাজার মূল্য (টাকা)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("অন্যান্য তথ্য (ঐচ্ছিক)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedVal = assetValue.toDoubleOrNull()
                        if (parsedVal != null && parsedVal > 0 && assetName.isNotBlank()) {
                            viewModel.addAsset(
                                name = assetName,
                                category = selectedCategory,
                                value = parsedVal,
                                description = description
                            )
                            // Reset and close
                            assetName = ""
                            assetValue = ""
                            description = ""
                            showDialog = false
                        }
                    }
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun AssetRow(asset: Asset, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when (asset.category) {
                        "জমি/বাড়ি" -> Icons.Filled.Home
                        "স্বর্ণ/রৌপ্য" -> Icons.Filled.Star
                        "ব্যাংক জমা" -> Icons.Filled.AccountBalance
                        "ব্যবসায়িক বিনিয়োগ" -> Icons.Filled.Business
                        else -> Icons.Filled.BusinessCenter
                    }
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(asset.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text("${asset.category} • ${formatDate(asset.date)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    if (asset.description.isNotBlank()) {
                        Text(asset.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(formatTaka(asset.value), fontSize = 14.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary)
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

// Helper function to convert numbers to Bangla digits
fun convertToBanglaNumbers(input: String): String {
    val englishDigits = listOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    val banglaDigits = listOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    var result = input
    for (i in 0..9) {
        result = result.replace(englishDigits[i], banglaDigits[i])
    }
    return result
}

@Composable
fun ComparisonRow(
    label: String,
    valA: String,
    valB: String,
    isHeader: Boolean = false,
    isZakatAmount: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isHeader) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                else if (isZakatAmount) GoldAccent.copy(alpha = 0.15f)
                else Color.Transparent
            )
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1.5f),
            fontSize = if (isHeader) 13.sp else 12.sp,
            fontWeight = if (isHeader || isZakatAmount) FontWeight.Bold else FontWeight.Normal,
            color = if (isZakatAmount) GoldAccent else MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = valA,
            modifier = Modifier.weight(1.1f),
            textAlign = TextAlign.End,
            fontSize = if (isHeader) 13.sp else 12.sp,
            fontWeight = if (isHeader || isZakatAmount) FontWeight.Bold else FontWeight.Normal,
            color = if (isZakatAmount) GoldAccent else MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = valB,
            modifier = Modifier.weight(1.1f),
            textAlign = TextAlign.End,
            fontSize = if (isHeader) 13.sp else 12.sp,
            fontWeight = if (isHeader || isZakatAmount) FontWeight.Bold else FontWeight.Normal,
            color = if (isZakatAmount) GoldAccent else MaterialTheme.colorScheme.onSurface
        )
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
}

// --- ZAKAT SECTION COMPOSABLE HELPER ---
@Composable
fun <T> ZakatSectionCard(
    title: String,
    icon: ImageVector,
    iconColor: Color,
    entries: List<T>,
    onAddEntry: () -> Unit,
    onDeleteEntry: (Int) -> Unit,
    lastYearText: String? = null,
    onImportLastYear: (() -> Unit)? = null,
    content: @Composable (Int, T) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(iconColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, null, tint = iconColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                
                TextButton(
                    onClick = onAddEntry,
                    colors = ButtonDefaults.textButtonColors(contentColor = iconColor)
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("যোগ করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            
            // Last year badge
            if (lastYearText != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(iconColor.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(lastYearText, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = iconColor, modifier = Modifier.weight(1f))
                    if (onImportLastYear != null) {
                        TextButton(
                            onClick = onImportLastYear,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(Icons.Default.Download, null, modifier = Modifier.size(14.dp), tint = iconColor)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ইম্পোর্ট", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = iconColor)
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(10.dp))
            
            // Entries
            if (entries.isEmpty()) {
                Text(
                    "কোন এন্ট্রি নেই। নতুন এন্ট্রি যোগ করতে \"যোগ করুন\" বাটনে চাপুন।",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 12.dp, bottom = 12.dp, start = 4.dp)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    entries.forEachIndexed { index, entry ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                content(index, entry)
                            }
                            IconButton(
                                onClick = { onDeleteEntry(index) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Delete, "বাতিল", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                            }
                        }
                        if (index < entries.size - 1) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

// --- ZAKAT CALCULATOR SCREEN ---
@Composable
fun ZakatScreen(viewModel: FinancialViewModel) {
    val zakatState by viewModel.zakatProfile.collectAsStateWithLifecycle()
    val zakatRecords by viewModel.allZakatRecords.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Calculator, 1 = History & Comparison

    // Multi-entry states
    var goldEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }
    var silverEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }
    var cashEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }
    var businessEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }
    var otherEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }
    var debtEntries by remember { mutableStateOf(listOf<ZakatDetailedEntry>()) }

    // Last year's record selected for comparison/import
    var selectedImportRecord by remember { mutableStateOf<ZakatRecord?>(null) }
    var showImportDropdown by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // Restore saved profile if exists
    LaunchedEffect(zakatState) {
        zakatState?.let { profile ->
            val details = ZakatJsonParser.fromJson(profile.detailsJson)
            
            // If the parsed lists are empty but the summary has values, we migrate them to lists
            goldEntries = details.goldEntries.ifEmpty {
                if (profile.goldWeightBhori > 0) {
                    listOf(ZakatDetailedEntry(extra = "22K", quantity = profile.goldWeightBhori, pricePerUnit = profile.goldPricePerBhori, value = profile.goldWeightBhori * profile.goldPricePerBhori))
                } else {
                    listOf(ZakatDetailedEntry(extra = "22K"))
                }
            }
            silverEntries = details.silverEntries.ifEmpty {
                if (profile.silverWeightBhori > 0) {
                    listOf(ZakatDetailedEntry(extra = "Standard", quantity = profile.silverWeightBhori, pricePerUnit = profile.silverPricePerBhori, value = profile.silverWeightBhori * profile.silverPricePerBhori))
                } else {
                    listOf(ZakatDetailedEntry(extra = "Standard"))
                }
            }
            cashEntries = details.cashEntries.ifEmpty {
                if (profile.cashInHandBank > 0) {
                    listOf(ZakatDetailedEntry(name = "ব্যাংক জমা/নগদ টাকা", value = profile.cashInHandBank))
                } else {
                    listOf(ZakatDetailedEntry(name = "হাতে নগদ/ব্যাংক অ্যাকাউন্ট"))
                }
            }
            businessEntries = details.businessEntries.ifEmpty {
                if (profile.businessGoodsValue > 0) {
                    listOf(ZakatDetailedEntry(name = "ব্যবসায়িক পণ্য", value = profile.businessGoodsValue))
                } else {
                    listOf(ZakatDetailedEntry(name = "ব্যবসায়িক স্টক"))
                }
            }
            otherEntries = details.otherEntries.ifEmpty {
                if (profile.otherInvestments > 0) {
                    listOf(ZakatDetailedEntry(name = "অন্যান্য ডিপিএস/এফডিআর", value = profile.otherInvestments))
                } else {
                    listOf(ZakatDetailedEntry(name = "ডিপিএস/বিনিয়োগ"))
                }
            }
            debtEntries = details.debtEntries.ifEmpty {
                if (profile.debtsOwed > 0) {
                    listOf(ZakatDetailedEntry(name = "ঋণ/দেনা পরিশোধযোগ্য", value = profile.debtsOwed))
                } else {
                    listOf(ZakatDetailedEntry(name = "ঋণ/দেনা"))
                }
            }
        }
    }

    // Calculations
    val calculatedGoldVal = goldEntries.sumOf { it.value }
    val totalGoldWeight = goldEntries.sumOf { it.quantity }
    val avgGoldPrice = if (totalGoldWeight > 0) calculatedGoldVal / totalGoldWeight else 0.0

    val calculatedSilverVal = silverEntries.sumOf { it.value }
    val totalSilverWeight = silverEntries.sumOf { it.quantity }
    val avgSilverPrice = if (totalSilverWeight > 0) calculatedSilverVal / totalSilverWeight else 0.0

    val totalCashVal = cashEntries.sumOf { it.value }
    val totalBusinessVal = businessEntries.sumOf { it.value }
    val totalOtherVal = otherEntries.sumOf { it.value }
    val totalDebtsVal = debtEntries.sumOf { it.value }

    val totalZakatableWealth = (calculatedGoldVal + calculatedSilverVal + totalCashVal + totalBusinessVal + totalOtherVal) - totalDebtsVal

    // Standard Nisab in Gold: 7.5 Bhori (87.48 grams) / Silver: 52.5 Bhori (612.36 grams)
    // We assume 1 ভরি standard silver price is approx standard price
    val silverNisabValue = avgSilverPrice * 52.5
    val isWealthAboveNisab = totalZakatableWealth >= if (silverNisabValue > 0) silverNisabValue else 85000.0 // Default 85k Taka approx threshold if silver price is empty

    val zakatAmount = if (totalZakatableWealth > 0 && isWealthAboveNisab) {
        totalZakatableWealth * 0.025
    } else {
        0.0
    }

    // Dialog state for year-wise record saving
    var showSaveRecordDialog by remember { mutableStateOf(false) }
    var recordYear by remember { mutableStateOf("") }
    var recordPersonName by remember { mutableStateOf("") }

    // Dropdown/Compare states for History Tab
    var dropdown1Expanded by remember { mutableStateOf(false) }
    var dropdown2Expanded by remember { mutableStateOf(false) }
    var selectedRecordA by remember { mutableStateOf<ZakatRecord?>(null) }
    var selectedRecordB by remember { mutableStateOf<ZakatRecord?>(null) }

    // Auto-populate comparison dropdowns if records exist and are not set yet
    LaunchedEffect(zakatRecords) {
        if (zakatRecords.isNotEmpty()) {
            if (selectedRecordA == null) {
                selectedRecordA = zakatRecords.firstOrNull()
            }
            if (selectedRecordB == null && zakatRecords.size > 1) {
                selectedRecordB = zakatRecords.getOrNull(1)
            }
        }
    }

    if (showSaveRecordDialog) {
        Dialog(onDismissRequest = { showSaveRecordDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "বছরভিত্তিক হিসাব সংরক্ষণ",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = recordYear,
                        onValueChange = { recordYear = it },
                        label = { Text("বছর (যেমন: ২০২৬ / 2026)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = recordPersonName,
                        onValueChange = { recordPersonName = it },
                        label = { Text("যাঁর যাকাত (নাম)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = GoldAccent.copy(alpha = 0.1f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("হিসাবের সংক্ষিপ্ত বিবরণী:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("মোট যাকাতযোগ্য সম্পদ: ${formatTaka(totalZakatableWealth.coerceAtLeast(0.0))}", fontSize = 12.sp)
                            Text("মোট যাকাত: ${formatTaka(zakatAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showSaveRecordDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল", color = MaterialTheme.colorScheme.error)
                        }
                        Button(
                            onClick = {
                                if (recordYear.isNotBlank() && recordPersonName.isNotBlank()) {
                                    val details = ZakatDetails(
                                        goldEntries = goldEntries,
                                        silverEntries = silverEntries,
                                        cashEntries = cashEntries,
                                        businessEntries = businessEntries,
                                        otherEntries = otherEntries,
                                        debtEntries = debtEntries
                                    )
                                    viewModel.saveZakatRecord(
                                        year = recordYear,
                                        personName = recordPersonName,
                                        goldWeightBhori = totalGoldWeight,
                                        goldPricePerBhori = avgGoldPrice,
                                        silverWeightBhori = totalSilverWeight,
                                        silverPricePerBhori = avgSilverPrice,
                                        cashInHandBank = totalCashVal,
                                        businessGoodsValue = totalBusinessVal,
                                        otherInvestments = totalOtherVal,
                                        debtsOwed = totalDebtsVal,
                                        totalZakatAmount = zakatAmount,
                                        detailsJson = ZakatJsonParser.toJson(details)
                                    )
                                    showSaveRecordDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(12.dp),
                            enabled = recordYear.isNotBlank() && recordPersonName.isNotBlank()
                        ) {
                            Text("সংরক্ষণ")
                        }
                    }
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Tab Header for Navigation within Zakat Menu
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("যাকাত ক্যালকুলেটর", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.Calculate, null) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("সংরক্ষণ ও তুলনা", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Filled.History, null) }
            )
        }

        if (activeTab == 0) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Zakat Display Header Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(GoldAccent.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Star, null, tint = GoldAccent, modifier = Modifier.size(24.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text("অটো যাকাত ক্যালকুলেশন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = formatTaka(zakatAmount),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = GoldAccent
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val statusText = if (totalZakatableWealth <= 0) {
                            "যាកাতযোগ্য মোট সম্পদ শূন্য"
                        } else if (isWealthAboveNisab) {
                            "আলহামদুলিল্লাহ! আপনার সম্পদ নিসাব সীমা অতিক্রম করেছে।"
                        } else {
                            "আপনার সম্পদ নিসাব সীমার নিচে রয়েছে (যাকাত ফরজ নয়)।"
                        }

                        Text(
                            text = statusText,
                            fontSize = 11.sp,
                            color = if (isWealthAboveNisab && totalZakatableWealth > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text("মোট যাকাতযোগ্য সম্পদ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(formatTaka(totalZakatableWealth.coerceAtLeast(0.0)), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("রৌপ্যের নিসাব মূল্য (৫২.৫ ভরি)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(formatTaka(silverNisabValue), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }

                // Dropdown to select last year's record for comparison & import
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "গত বছরের হিসাব ইম্পোর্ট ও তুলনা",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Box {
                            OutlinedButton(
                                onClick = { showImportDropdown = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = selectedImportRecord?.let { "${it.year} (${it.personName}) - যাকাত: ${formatTaka(it.totalZakatAmount)}" } ?: "ইম্পোর্ট ও তুলনার জন্য হিসাব নির্বাচন করুন",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Icon(Icons.Default.ArrowDropDown, null)
                                }
                            }
                            DropdownMenu(
                                expanded = showImportDropdown,
                                onDismissRequest = { showImportDropdown = false }
                            ) {
                                zakatRecords.forEach { record ->
                                    DropdownMenuItem(
                                        text = { Text("${record.year} - ${record.personName} (${formatTaka(record.totalZakatAmount)})") },
                                        onClick = {
                                            selectedImportRecord = record
                                            showImportDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                val lastYearDetails = selectedImportRecord?.let { ZakatJsonParser.fromJson(it.detailsJson) }

                // Zakat Form Inputs
                Text("সম্পদের বিবরণী ও মূল্যমান ইনপুট দিন", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp, start = 4.dp))

                // 1. Gold Card
                ZakatSectionCard(
                    title = "স্বর্ণের হিসাব (Gold)",
                    icon = Icons.Filled.Star,
                    iconColor = GoldAccent,
                    entries = goldEntries,
                    onAddEntry = {
                        goldEntries = goldEntries + ZakatDetailedEntry(extra = "22K")
                    },
                    onDeleteEntry = { idx ->
                        goldEntries = goldEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${it.goldEntries.sumOf { e -> e.quantity }} ভরি (${formatTaka(it.goldEntries.sumOf { e -> e.value })})" },
                    onImportLastYear = lastYearDetails?.let { { goldEntries = it.goldEntries } }
                ) { index, entry ->
                    Column {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            var expanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(0.9f)) {
                                OutlinedTextField(
                                    value = translateText(entry.extra, context),
                                    onValueChange = { newValue ->
                                        goldEntries = goldEntries.mapIndexed { i, e ->
                                            if (i == index) e.copy(extra = newValue) else e
                                        }
                                    },
                                    label = { Text("ক্যারেট") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    trailingIcon = {
                                        IconButton(onClick = { expanded = true }) {
                                            Icon(Icons.Default.ArrowDropDown, null)
                                        }
                                    }
                                )
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    listOf("24K", "22K", "21K", "18K", "অন্যান্য").forEach { k ->
                                        DropdownMenuItem(
                                            text = { Text(k) },
                                            onClick = {
                                                goldEntries = goldEntries.mapIndexed { i, e ->
                                                    if (i == index) e.copy(extra = k) else e
                                                }
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                            
                            OutlinedTextField(
                                value = if (entry.quantity > 0) entry.quantity.toString() else "",
                                onValueChange = { newValue ->
                                    val qty = newValue.toDoubleOrNull() ?: 0.0
                                    goldEntries = goldEntries.mapIndexed { i, e ->
                                        if (i == index) e.copy(quantity = qty, value = qty * e.pricePerUnit) else e
                                    }
                                },
                                label = { Text("ভরি") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(0.8f),
                                singleLine = true
                            )
                            
                            OutlinedTextField(
                                value = if (entry.pricePerUnit > 0) entry.pricePerUnit.toString() else "",
                                onValueChange = { newValue ->
                                    val price = newValue.toDoubleOrNull() ?: 0.0
                                    goldEntries = goldEntries.mapIndexed { i, e ->
                                        if (i == index) e.copy(pricePerUnit = price, value = e.quantity * price) else e
                                    }
                                },
                                label = { Text("দাম/ভরি") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.3f),
                                singleLine = true
                            )
                        }
                        if (entry.quantity > 0 && entry.pricePerUnit > 0) {
                            Text(
                                "মূল্য: ${formatTaka(entry.value)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }
                    }
                }

                // 2. Silver Card
                ZakatSectionCard(
                    title = "রৌপ্যের হিসাব (Silver)",
                    icon = Icons.Filled.StarHalf,
                    iconColor = Color.Gray,
                    entries = silverEntries,
                    onAddEntry = {
                        silverEntries = silverEntries + ZakatDetailedEntry(extra = "Standard")
                    },
                    onDeleteEntry = { idx ->
                        silverEntries = silverEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${it.silverEntries.sumOf { e -> e.quantity }} ভরি (${formatTaka(it.silverEntries.sumOf { e -> e.value })})" },
                    onImportLastYear = lastYearDetails?.let { { silverEntries = it.silverEntries } }
                ) { index, entry ->
                    Column {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = translateText(entry.extra, context),
                                onValueChange = { newValue ->
                                    silverEntries = silverEntries.mapIndexed { i, e ->
                                        if (i == index) e.copy(extra = newValue) else e
                                    }
                                },
                                label = { Text("ধরণ") },
                                modifier = Modifier.weight(0.8f),
                                singleLine = true
                            )
                            
                            OutlinedTextField(
                                value = if (entry.quantity > 0) entry.quantity.toString() else "",
                                onValueChange = { newValue ->
                                    val qty = newValue.toDoubleOrNull() ?: 0.0
                                    silverEntries = silverEntries.mapIndexed { i, e ->
                                        if (i == index) e.copy(quantity = qty, value = qty * e.pricePerUnit) else e
                                    }
                                },
                                label = { Text("ভরি") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(0.8f),
                                singleLine = true
                            )
                            
                            OutlinedTextField(
                                value = if (entry.pricePerUnit > 0) entry.pricePerUnit.toString() else "",
                                onValueChange = { newValue ->
                                    val price = newValue.toDoubleOrNull() ?: 0.0
                                    silverEntries = silverEntries.mapIndexed { i, e ->
                                        if (i == index) e.copy(pricePerUnit = price, value = e.quantity * price) else e
                                    }
                                },
                                label = { Text("দাম/ভরি") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.2f),
                                singleLine = true
                            )
                        }
                        if (entry.quantity > 0 && entry.pricePerUnit > 0) {
                            Text(
                                "মূল্য: ${formatTaka(entry.value)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary,
                                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                            )
                        }
                    }
                }

                // 3. Cash Bank Card
                ZakatSectionCard(
                    title = "নগদ ও ব্যাংক ডিপোজিট",
                    icon = Icons.Filled.Savings,
                    iconColor = EmeraldPrimary,
                    entries = cashEntries,
                    onAddEntry = {
                        cashEntries = cashEntries + ZakatDetailedEntry(name = "")
                    },
                    onDeleteEntry = { idx ->
                        cashEntries = cashEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${formatTaka(it.cashEntries.sumOf { e -> e.value })}" },
                    onImportLastYear = lastYearDetails?.let { { cashEntries = it.cashEntries } }
                ) { index, entry ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = translateText(entry.name, context),
                            onValueChange = { newValue ->
                                cashEntries = cashEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(name = newValue) else e
                                }
                            },
                            label = { Text("ব্যাংকের নাম / উৎসবের বিবরণ") },
                            placeholder = { Text("যেমন: সোনালী ব্যাংক / হাতে নগদ") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )
                        
                        OutlinedTextField(
                            value = if (entry.value > 0) entry.value.toString() else "",
                            onValueChange = { newValue ->
                                val amt = newValue.toDoubleOrNull() ?: 0.0
                                cashEntries = cashEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(value = amt) else e
                                }
                            },
                            label = { Text("টাকার পরিমাণ") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                // 4. Business Stock Card
                ZakatSectionCard(
                    title = "ব্যবসায়িক পণ্য ও স্টক",
                    icon = Icons.Filled.Business,
                    iconColor = DeepTeal,
                    entries = businessEntries,
                    onAddEntry = {
                        businessEntries = businessEntries + ZakatDetailedEntry(name = "")
                    },
                    onDeleteEntry = { idx ->
                        businessEntries = businessEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${formatTaka(it.businessEntries.sumOf { e -> e.value })}" },
                    onImportLastYear = lastYearDetails?.let { { businessEntries = it.businessEntries } }
                ) { index, entry ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = translateText(entry.name, context),
                            onValueChange = { newValue ->
                                businessEntries = businessEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(name = newValue) else e
                                }
                            },
                            label = { Text("দোকান / পণ্যের বিবরণ") },
                            placeholder = { Text("যেমন: স্টক মালামাল / গোডাউন পণ্য") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )
                        
                        OutlinedTextField(
                            value = if (entry.value > 0) entry.value.toString() else "",
                            onValueChange = { newValue ->
                                val amt = newValue.toDoubleOrNull() ?: 0.0
                                businessEntries = businessEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(value = amt) else e
                                }
                            },
                            label = { Text("মূল্যমান") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                // 5. Other Investments Card
                ZakatSectionCard(
                    title = "অন্যান্য ডিপিএস/এফডিআর/বিনিয়োগ",
                    icon = Icons.Filled.LocalAtm,
                    iconColor = EmeraldSecondary,
                    entries = otherEntries,
                    onAddEntry = {
                        otherEntries = otherEntries + ZakatDetailedEntry(name = "")
                    },
                    onDeleteEntry = { idx ->
                        otherEntries = otherEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${formatTaka(it.otherEntries.sumOf { e -> e.value })}" },
                    onImportLastYear = lastYearDetails?.let { { otherEntries = it.otherEntries } }
                ) { index, entry ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = translateText(entry.name, context),
                            onValueChange = { newValue ->
                                otherEntries = otherEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(name = newValue) else e
                                }
                            },
                            label = { Text("বিনিয়োগের বিবরণ") },
                            placeholder = { Text("যেমন: ব্র্যাক ব্যাংক এফডিআর") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )
                        
                        OutlinedTextField(
                            value = if (entry.value > 0) entry.value.toString() else "",
                            onValueChange = { newValue ->
                                val amt = newValue.toDoubleOrNull() ?: 0.0
                                otherEntries = otherEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(value = amt) else e
                                }
                            },
                            label = { Text("মূল্যমান") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                // 6. Debts to Deduct Card
                ZakatSectionCard(
                    title = "বাদ যাবে: মোট ঋণের দায়/দেনা",
                    icon = Icons.Filled.AccountBalanceWallet,
                    iconColor = Color(0xFFE53935),
                    entries = debtEntries,
                    onAddEntry = {
                        debtEntries = debtEntries + ZakatDetailedEntry(name = "")
                    },
                    onDeleteEntry = { idx ->
                        debtEntries = debtEntries.filterIndexed { i, _ -> i != idx }
                    },
                    lastYearText = lastYearDetails?.let { "গত বছর ছিল: ${formatTaka(it.debtEntries.sumOf { e -> e.value })}" },
                    onImportLastYear = lastYearDetails?.let { { debtEntries = it.debtEntries } }
                ) { index, entry ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = translateText(entry.name, context),
                            onValueChange = { newValue ->
                                debtEntries = debtEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(name = newValue) else e
                                }
                            },
                            label = { Text("ঋণদাতা / ঋণের বিবরণ") },
                            placeholder = { Text("যেমন: হাউস বিল্ডিং লোন") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )
                        
                        OutlinedTextField(
                            value = if (entry.value > 0) entry.value.toString() else "",
                            onValueChange = { newValue ->
                                val amt = newValue.toDoubleOrNull() ?: 0.0
                                debtEntries = debtEntries.mapIndexed { i, e ->
                                    if (i == index) e.copy(value = amt) else e
                                }
                            },
                            label = { Text("ঋণের পরিমাণ") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val details = ZakatDetails(
                                        goldEntries = goldEntries,
                                        silverEntries = silverEntries,
                                        cashEntries = cashEntries,
                                        businessEntries = businessEntries,
                                        otherEntries = otherEntries,
                                        debtEntries = debtEntries
                                    )
                                    viewModel.saveZakatProfile(
                                        goldWeightBhori = totalGoldWeight,
                                        goldPricePerBhori = avgGoldPrice,
                                        silverWeightBhori = totalSilverWeight,
                                        silverPricePerBhori = avgSilverPrice,
                                        cashInHandBank = totalCashVal,
                                        businessGoodsValue = totalBusinessVal,
                                        otherInvestments = totalOtherVal,
                                        debtsOwed = totalDebtsVal,
                                        detailsJson = ZakatJsonParser.toJson(details)
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer)
                            ) {
                                Text("খসড়া সংরক্ষণ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val currentGregorianYear = Calendar.getInstance().get(Calendar.YEAR).toString()
                                    recordYear = convertToBanglaNumbers(currentGregorianYear)
                                    recordPersonName = "আমার যাকাত"
                                    showSaveRecordDialog = true
                                },
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Icon(Icons.Filled.Save, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("বছরভিত্তিক সেভ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // PDF Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val context = LocalContext.current
                            val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
                            val userName = currentUser?.name ?: "ব্যবহারকারী"

                            OutlinedButton(
                                onClick = {
                                    val details = ZakatDetails(
                                        goldEntries = goldEntries,
                                        silverEntries = silverEntries,
                                        cashEntries = cashEntries,
                                        businessEntries = businessEntries,
                                        otherEntries = otherEntries,
                                        debtEntries = debtEntries
                                    )
                                    val activeProfile = ZakatProfile(
                                        goldWeightBhori = totalGoldWeight,
                                        goldPricePerBhori = avgGoldPrice,
                                        silverWeightBhori = totalSilverWeight,
                                        silverPricePerBhori = avgSilverPrice,
                                        cashInHandBank = totalCashVal,
                                        businessGoodsValue = totalBusinessVal,
                                        otherInvestments = totalOtherVal,
                                        debtsOwed = totalDebtsVal,
                                        detailsJson = ZakatJsonParser.toJson(details)
                                    )
                                    val file = PdfReportHelper.generateZakatReportPdf(context, userName, zakatRecords, activeProfile)
                                    PdfReportHelper.sharePdf(context, file)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Share, null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("পিডিএফ শেয়ার", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    val details = ZakatDetails(
                                        goldEntries = goldEntries,
                                        silverEntries = silverEntries,
                                        cashEntries = cashEntries,
                                        businessEntries = businessEntries,
                                        otherEntries = otherEntries,
                                        debtEntries = debtEntries
                                    )
                                    val activeProfile = ZakatProfile(
                                        goldWeightBhori = totalGoldWeight,
                                        goldPricePerBhori = avgGoldPrice,
                                        silverWeightBhori = totalSilverWeight,
                                        silverPricePerBhori = avgSilverPrice,
                                        cashInHandBank = totalCashVal,
                                        businessGoodsValue = totalBusinessVal,
                                        otherInvestments = totalOtherVal,
                                        debtsOwed = totalDebtsVal,
                                        detailsJson = ZakatJsonParser.toJson(details)
                                    )
                                    val file = PdfReportHelper.generateZakatReportPdf(context, userName, zakatRecords, activeProfile)
                                    PdfReportHelper.printPdf(context, file)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Print, null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("প্রিন্ট রিপোর্ট", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Quick Zakat Rule guide
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("যাকাতের সংক্ষিপ্ত নিয়মাবলী:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "১. নিসাব সীমা: স্বর্ণের ক্ষেত্রে নূন্যতম ৭.৫ ভরি (প্রায় ৮৭.৪৮ গ্রাম) অথবা রৌপ্যের ক্ষেত্রে নূন্যতম ৫২.৫ ভরি (প্রায় ৬১২.৩৬ গ্রাম) সমপরিমাণ সম্পদ এক বছর ধরে মালিকানায় থাকলে যাকাত ফরজ হয়।\n" +
                                    "২. শরীয়া অনুযায়ী রৌপ্যের নিসাব দরিদ্রদের জন্য অধিক কল্যাণকর হওয়ায় সাধারণত রৌপ্যের মূল্যের নিসাবকে ভিত্তি ধরা হয়।\n" +
                                    "৩. যাকাতযোগ্য মোট সম্পদের ২.৫% (শতকরা আড়াই টাকা) যাকাত হিসেবে প্রদান করা আবশ্যক।",
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        } else {
            // History and Comparison tab
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (zakatRecords.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "কোনো সংরক্ষিত যাকাত হিসাব পাওয়া যায়নি!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ক্যালকুলেটর ট্যাব থেকে যাকাত হিসেব সম্পন্ন করে \"বছরভিত্তিক সেভ\" বাটনে চাপুন।",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    // COMPARISON PANEL CARD
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(bottom = 12.dp)
                            ) {
                                Icon(Icons.Filled.CompareArrows, null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("বছরভিত্তিক যাকাত হিসাবের তুলনা", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Selector A
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { dropdown1Expanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("প্রথম হিসাব (Year A)", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                                            Text(
                                                text = selectedRecordA?.let { "${it.year} (${it.personName})" } ?: "নির্বাচন করুন",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = dropdown1Expanded,
                                        onDismissRequest = { dropdown1Expanded = false }
                                    ) {
                                        zakatRecords.forEach { record ->
                                            DropdownMenuItem(
                                                text = { Text("${record.year} - ${record.personName} (${formatTaka(record.totalZakatAmount)})") },
                                                onClick = {
                                                    selectedRecordA = record
                                                    dropdown1Expanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // Selector B
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { dropdown2Expanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("দ্বিতীয় হিসাব (Year B)", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                                            Text(
                                                text = selectedRecordB?.let { "${it.year} (${it.personName})" } ?: "নির্বাচন করুন",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = dropdown2Expanded,
                                        onDismissRequest = { dropdown2Expanded = false }
                                    ) {
                                        zakatRecords.forEach { record ->
                                            DropdownMenuItem(
                                                text = { Text("${record.year} - ${record.personName} (${formatTaka(record.totalZakatAmount)})") },
                                                onClick = {
                                                    selectedRecordB = record
                                                    dropdown2Expanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            val recA = selectedRecordA
                            val recB = selectedRecordB

                            if (recA != null && recB != null) {
                                // COMPARISON TABLE
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column {
                                        // Header Row
                                        ComparisonRow(
                                            label = "বিবরণ (আইটেম)",
                                            valA = "${recA.year}\n(${recA.personName})",
                                            valB = "${recB.year}\n(${recB.personName})",
                                            isHeader = true
                                        )

                                        val goldValA = recA.goldWeightBhori * recA.goldPricePerBhori
                                        val goldValB = recB.goldWeightBhori * recB.goldPricePerBhori
                                        ComparisonRow(
                                            label = "স্বর্ণের পরিমাণ",
                                            valA = "${recA.goldWeightBhori} ভরি",
                                            valB = "${recB.goldWeightBhori} ভরি"
                                        )
                                        ComparisonRow(
                                            label = "স্বর্ণের বাজারমূল্য",
                                            valA = formatTaka(goldValA),
                                            valB = formatTaka(goldValB)
                                        )

                                        val silverValA = recA.silverWeightBhori * recA.silverPricePerBhori
                                        val silverValB = recB.silverWeightBhori * recB.silverPricePerBhori
                                        ComparisonRow(
                                            label = "রৌপ্যের পরিমাণ",
                                            valA = "${recA.silverWeightBhori} ভরি",
                                            valB = "${recB.silverWeightBhori} ভরি"
                                        )
                                        ComparisonRow(
                                            label = "রৌপ্যের বাজারমূল্য",
                                            valA = formatTaka(silverValA),
                                            valB = formatTaka(silverValB)
                                        )

                                        ComparisonRow(
                                            label = "নগদ ও ব্যাংক জমা",
                                            valA = formatTaka(recA.cashInHandBank),
                                            valB = formatTaka(recA.cashInHandBank)
                                        )
                                        ComparisonRow(
                                            label = "ব্যবসায়িক পণ্য মূল্য",
                                            valA = formatTaka(recA.businessGoodsValue),
                                            valB = formatTaka(recB.businessGoodsValue)
                                        )
                                        ComparisonRow(
                                            label = "অন্যান্য ডিপিএস/বিনিয়োগ",
                                            valA = formatTaka(recA.otherInvestments),
                                            valB = formatTaka(recB.otherInvestments)
                                        )
                                        ComparisonRow(
                                            label = "বাদ ঋণের দায় (-)",
                                            valA = formatTaka(recA.debtsOwed),
                                            valB = formatTaka(recB.debtsOwed)
                                        )

                                        val totalWealthA = (goldValA + silverValA + recA.cashInHandBank + recA.businessGoodsValue + recA.otherInvestments) - recA.debtsOwed
                                        val totalWealthB = (goldValB + silverValB + recB.cashInHandBank + recB.businessGoodsValue + recB.otherInvestments) - recB.debtsOwed
                                        ComparisonRow(
                                            label = "মোট যাকাতযোগ্য সম্পদ",
                                            valA = formatTaka(totalWealthA.coerceAtLeast(0.0)),
                                            valB = formatTaka(totalWealthB.coerceAtLeast(0.0)),
                                            isHeader = true
                                        )

                                        ComparisonRow(
                                            label = "মোট যাকাত (২.৫%)",
                                            valA = formatTaka(recA.totalZakatAmount),
                                            valB = formatTaka(recB.totalZakatAmount),
                                            isZakatAmount = true
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    "তুলনা দেখতে অনুগ্রহ করে উপরে দুটি ভিন্ন যাকাত হিসাব নির্বাচন করুন।",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                                )
                            }
                        }
                    }

                    // SAVED RECORDS LIST SECTION
                    Text("সংরক্ষিত যাকাত হিসাবসমূহ (${zakatRecords.size}টি)", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        zakatRecords.forEach { record ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "বছর: ${record.year}",
                                                fontWeight = FontWeight.Black,
                                                fontSize = 15.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "(${record.personName})",
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Text(
                                            text = "যাকাত: " + formatTaka(record.totalZakatAmount),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = GoldAccent
                                        )
                                        Text(
                                            text = "তারিখ: " + formatDate(record.date),
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        // Quick Buttons to set for comparison
                                        IconButton(
                                            onClick = { selectedRecordA = record },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Text("ক", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedRecordA?.id == record.id) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        }
                                        IconButton(
                                            onClick = { selectedRecordB = record },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Text("খ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedRecordB?.id == record.id) EmeraldPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteZakatRecord(record.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                Icons.Filled.Delete,
                                                contentDescription = "ডিলিট",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- REPORTS & GRAPHICAL CHART SCREEN ---
@Composable
fun ReportsScreen(viewModel: FinancialViewModel) {
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val fixedInvestments by viewModel.fixedInvestments.collectAsStateWithLifecycle()
    val debts by viewModel.debts.collectAsStateWithLifecycle()
    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val zakatProfile by viewModel.zakatProfile.collectAsStateWithLifecycle()
    val zakatRecords by viewModel.allZakatRecords.collectAsStateWithLifecycle()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    var selectedViewUser by remember { mutableStateOf(currentUser?.name ?: "") }

    var selectedYear by remember { mutableStateOf(2026) }
    var selectedMonth by remember { mutableStateOf(Calendar.getInstance().get(Calendar.MONTH)) } // 0-11
    var reportType by remember { mutableStateOf("MONTHLY") } // MONTHLY or YEARLY
    var activePdfFile by remember { mutableStateOf<java.io.File?>(null) }

    val months = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
    val context = LocalContext.current
    val userName = selectedViewUser.ifBlank { currentUser?.name ?: "" }

    LaunchedEffect(currentUser) {
        if (selectedViewUser.isBlank()) {
            selectedViewUser = currentUser?.name ?: ""
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            currentUser?.let {
                viewModel.switchUserDatabase(it.name)
            }
        }
    }

    // Filter transactions based on selected timeframe
    val filteredTransactions = transactions.filter { tx ->
        val cal = Calendar.getInstance().apply { timeInMillis = tx.date }
        val txYear = cal.get(Calendar.YEAR)
        val txMonth = cal.get(Calendar.MONTH)

        if (reportType == "MONTHLY") {
            txYear == selectedYear && txMonth == selectedMonth
        } else {
            txYear == selectedYear
        }
    }

    val incomeVal = filteredTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expenseVal = filteredTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val savingsVal = filteredTransactions.filter { it.type == "SAVINGS" }.sumOf { it.amount }

    val remainingBalance = incomeVal - expenseVal - savingsVal

    @Composable
    fun SummaryCard(title: String, value: String, containerColor: Color, modifier: Modifier = Modifier) {
        Card(
            modifier = modifier,
            colors = CardDefaults.cardColors(containerColor = containerColor),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, style = MaterialTheme.typography.labelSmall)
                Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Summary Overview
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SummaryCard(tr("dashboard_income", "Income"), formatTaka(incomeVal), MaterialTheme.colorScheme.primaryContainer, Modifier.weight(1f))
            SummaryCard(tr("dashboard_expense", "Expense"), formatTaka(expenseVal), MaterialTheme.colorScheme.errorContainer, Modifier.weight(1f))
            SummaryCard(tr("dashboard_balance", "Balance"), formatTaka(remainingBalance), MaterialTheme.colorScheme.secondaryContainer, Modifier.weight(1f))
        }

        // Multi-user Data View Selector for Master user
        if (currentUser?.isMaster == true) {
            var expandedUserDropdown by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedUserDropdown = true }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Group, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "আর্থিক ডেটা ভিউ: $userName" + if (userName == currentUser?.name) " (আমার)" else "",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text("পরিবর্তন ▾", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    
                    DropdownMenu(
                        expanded = expandedUserDropdown,
                        onDismissRequest = { expandedUserDropdown = false }
                    ) {
                        allUsers.forEach { u ->
                            DropdownMenuItem(
                                text = { Text(u.name) },
                                onClick = {
                                    selectedViewUser = u.name
                                    viewModel.switchUserDatabase(u.name)
                                    expandedUserDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // PDF Export & Print Panel
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Print,
                        contentDescription = "PDF & Print",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "আর্থিক রিপোর্ট ডাউনলোড ও প্রিন্ট",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Combined PDF (All in one)
                Button(
                    onClick = {
                        val file = PdfReportHelper.generateCombinedReportPdf(
                            context = context,
                            userName = userName,
                            transactions = transactions,
                            selectedMonthIndex = selectedMonth,
                            selectedYear = selectedYear,
                            investments = fixedInvestments,
                            debts = debts,
                            assets = assets,
                            zakatRecords = zakatRecords,
                            activeZakatProfile = zakatProfile
                        )
                        activePdfFile = file
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("সবকিছু একসাথে ডাউনলোড (Combined PDF)", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("মেনু অনুযায়ী একক রিপোর্ট ডাউনলোড করুন:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))

                // 2-column Grid of visual buttons for individual menus
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val reportOptions = listOf(
                        Triple("দৈনিক হিসাব", Icons.Filled.Today, { PdfReportHelper.generateDailyReportPdf(context, userName, transactions) }),
                        Triple("মাসিক হিসাব", Icons.Filled.CalendarMonth, { PdfReportHelper.generateMonthlyReportPdf(context, userName, transactions, selectedMonth, selectedYear) }),
                        Triple("বাৎসরিক হিসাব", Icons.Filled.DateRange, { PdfReportHelper.generateYearlyReportPdf(context, userName, transactions, selectedYear) }),
                        Triple("স্থায়ী বিনিয়োগ", Icons.Filled.TrendingUp, { PdfReportHelper.generateInvestmentsReportPdf(context, userName, fixedInvestments) }),
                        Triple("ঋণ ট্র্যাকার", Icons.Filled.Handshake, { PdfReportHelper.generateDebtsReportPdf(context, userName, debts) }),
                        Triple("সম্পদ খাতা", Icons.Filled.AccountBalance, { PdfReportHelper.generateAssetsReportPdf(context, userName, assets) }),
                        Triple("যাকাত হিসাব", Icons.Filled.Star, { PdfReportHelper.generateZakatReportPdf(context, userName, zakatRecords, zakatProfile) })
                    )

                    reportOptions.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            pair.forEach { (title, icon, action) ->
                                OutlinedButton(
                                    onClick = { activePdfFile = action() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(vertical = 10.dp, horizontal = 8.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                ) {
                                    Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        if (activePdfFile != null) {
            val file = activePdfFile!!
            AlertDialog(
                onDismissRequest = { activePdfFile = null },
                title = { Text("রিপোর্ট ফাইল প্রস্তুত", fontWeight = FontWeight.Bold) },
                text = { Text("আপনার পছন্দসই রিপোর্ট ফাইলটি তৈরি হয়েছে। আপনি এটি শেয়ার/সংরক্ষণ করতে চান নাকি সরাসরি প্রিন্ট করতে চান?") },
                confirmButton = {
                    Button(
                        onClick = {
                            PdfReportHelper.sharePdf(context, file)
                            activePdfFile = null
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("শেয়ার ও সংরক্ষণ")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            PdfReportHelper.printPdf(context, file)
                            activePdfFile = null
                        }
                    ) {
                        Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("সরাসরি প্রিন্ট")
                    }
                }
            )
        }

        // Toggle Month/Year filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(2.dp)
        ) {
            val filterTypes = listOf("MONTHLY" to "মাসিক রিপোর্ট", "YEARLY" to "বাৎসরিক রিপোর্ট")
            filterTypes.forEach { (key, label) ->
                val isSelected = reportType == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { reportType = key }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Time selectors row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (reportType == "MONTHLY") {
                // Month selector chips scrollable
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    months.forEachIndexed { index, mName ->
                        val isSel = selectedMonth == index
                        FilterChip(
                            selected = isSel,
                            onClick = { selectedMonth = index },
                            label = { Text(mName, fontSize = 11.sp) }
                        )
                    }
                }
            }

            // Simple Year Selector Filter Chip
            var showYearDialog by remember { mutableStateOf(false) }
            FilterChip(
                selected = true,
                onClick = { showYearDialog = true },
                label = { Text("বছর: $selectedYear ▾") }
            )

            if (showYearDialog) {
                Dialog(onDismissRequest = { showYearDialog = false }) {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("বছর নির্বাচন করুন", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))
                            listOf(2025, 2026, 2027, 2028).forEach { yr ->
                                TextButton(onClick = {
                                    selectedYear = yr
                                    showYearDialog = false
                                }) {
                                    Text(yr.toString(), modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Financial summary card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (reportType == "MONTHLY") "${months[selectedMonth]}, $selectedYear এর সারসংক্ষেপ" else "$selectedYear সালের সারসংক্ষেপ",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("মোট ইনকাম", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(formatTaka(incomeVal), fontSize = 16.sp, fontWeight = FontWeight.Black, color = EmeraldPrimary)
                    }
                    Column {
                        Text("মোট খরচ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(formatTaka(expenseVal), fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color(0xFFE53935))
                    }
                    Column {
                        Text("মোট জমা", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text(formatTaka(savingsVal), fontSize = 16.sp, fontWeight = FontWeight.Black, color = DeepTeal)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("অবশিষ্ট ব্যালেন্স (নীট)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(
                        formatTaka(remainingBalance),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = if (remainingBalance >= 0) EmeraldPrimary else Color(0xFFE53935)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Custom drawn interactive visual graph/chart section
        Text("গ্রাফিক্যাল ব্যালেন্স চার্ট", fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp, start = 4.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (incomeVal == 0.0 && expenseVal == 0.0 && savingsVal == 0.0) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.PieChart, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("চার্ট দেখানোর জন্য পর্যাপ্ত লেনদেন রেকর্ড নেই।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                } else {
                    // Custom Draw Canvas Bar Chart
                    CustomBalanceBarChart(
                        income = incomeVal,
                        expense = expenseVal,
                        savings = savingsVal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Legend values
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        LegendItem(label = "ইনকাম", color = EmeraldPrimary)
                        LegendItem(label = "খরচ", color = Color(0xFFE53935))
                        LegendItem(label = "জমা", color = DeepTeal)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Transaction list under Reports
        Text("লেনদেন সমূহের তালিকা (${filteredTransactions.size} টি পাওয়া গেছে)", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp, start = 4.dp))

        filteredTransactions.forEach { tx ->
            TransactionRow(transaction = tx, onDelete = { viewModel.deleteTransaction(tx.id) })
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
    }
}

@Composable
fun CustomBalanceBarChart(
    income: Double,
    expense: Double,
    savings: Double,
    modifier: Modifier = Modifier
) {
    val total = income.coerceAtLeast(1.0)
    val maxVal = maxOf(income, expense, savings).coerceAtLeast(1.0)

    val animatedIncomeRatio = remember { Animatable(0f) }
    val animatedExpenseRatio = remember { Animatable(0f) }
    val animatedSavingsRatio = remember { Animatable(0f) }

    LaunchedEffect(income, expense, savings) {
        animatedIncomeRatio.animateTo(
            targetValue = (income / maxVal).toFloat(),
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
    }
    LaunchedEffect(income, expense, savings) {
        animatedExpenseRatio.animateTo(
            targetValue = (expense / maxVal).toFloat(),
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
    }
    LaunchedEffect(income, expense, savings) {
        animatedSavingsRatio.animateTo(
            targetValue = (savings / maxVal).toFloat(),
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
        )
    }

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val barWidth = width * 0.15f
        val gap = width * 0.12f

        val xIncome = width * 0.18f
        val xExpense = xIncome + barWidth + gap
        val xSavings = xExpense + barWidth + gap

        // Draw baseline grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = height * (i.toFloat() / gridLines)
            drawLine(
                color = Color.LightGray.copy(alpha = 0.4f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Draw Income Bar
        val hIncome = height * animatedIncomeRatio.value
        drawRoundRect(
            color = EmeraldPrimary,
            topLeft = Offset(xIncome, height - hIncome),
            size = Size(barWidth, hIncome),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )

        // Draw Expense Bar
        val hExpense = height * animatedExpenseRatio.value
        drawRoundRect(
            color = Color(0xFFE53935),
            topLeft = Offset(xExpense, height - hExpense),
            size = Size(barWidth, hExpense),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )

        // Draw Savings Bar
        val hSavings = height * animatedSavingsRatio.value
        drawRoundRect(
            color = DeepTeal,
            topLeft = Offset(xSavings, height - hSavings),
            size = Size(barWidth, hSavings),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx(), 10.dp.toPx())
        )
    }
}

fun calculateExpiryTimestamp(option: String, customDaysStr: String, currentExpiry: Long = 0L): Long {
    val cal = java.util.Calendar.getInstance()
    return when (option) {
        "CURRENT" -> currentExpiry
        "14_DAYS" -> {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 14)
            cal.timeInMillis
        }
        "6_MONTHS" -> {
            cal.add(java.util.Calendar.MONTH, 6)
            cal.timeInMillis
        }
        "1_YEAR" -> {
            cal.add(java.util.Calendar.YEAR, 1)
            cal.timeInMillis
        }
        "LIFETIME" -> Long.MAX_VALUE
        "CUSTOM" -> {
            val days = customDaysStr.toIntOrNull() ?: 0
            if (days > 0) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, days)
                cal.timeInMillis
            } else {
                0L
            }
        }
        else -> 0L
    }
}

fun getExpiryDisplayString(expiry: Long): String {
    if (expiry <= 0L) return "লকড 🔒"
    if (expiry == Long.MAX_VALUE) return "আজীবন সচল 🗝️"
    val diff = expiry - System.currentTimeMillis()
    if (diff <= 0) return "মেয়াদ উত্তীর্ণ 🔒"
    val daysLeft = (diff / (24L * 60 * 60 * 1000)).toInt()
    return if (daysLeft > 0) {
        "সচল ($daysLeft দিন বাকি) ⏳"
    } else {
        "আজই শেষ হবে ⏳"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserManagementScreen(viewModel: FinancialViewModel) {
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var editingUser by remember { mutableStateOf<AppUser?>(null) }

    var newUserName by remember { mutableStateOf("") }
    var newUserPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    var editUserName by remember { mutableStateOf("") }
    var editUserPin by remember { mutableStateOf("") }
    var editErrorMessage by remember { mutableStateOf("") }

    val menuOptions = listOf(
        Pair("INVESTMENTS", "স্থায়ী বিনিয়োগ (DPS/FDR)"),
        Pair("DEBTS", "ঋণ ট্র্যাকার"),
        Pair("ASSETS", "সম্পদ খাতা"),
        Pair("ZAKAT", "যাকাত ক্যালকুলেটর"),
        Pair("REPORTS", "রিপোর্ট ও চার্ট"),
        Pair("BUSINESS_LEDGER", "ব্যবসায়িক হিসেব নিকেশ")
    )

    val selectedMenus = remember { mutableStateMapOf<String, Boolean>() }
    val editSelectedMenus = remember { mutableStateMapOf<String, Boolean>() }
    
    val selectedMenuDurations = remember { mutableStateMapOf<String, String>() }
    val selectedMenuCustomDays = remember { mutableStateMapOf<String, String>() }
    val editMenuDurations = remember { mutableStateMapOf<String, String>() }
    val editMenuCustomDays = remember { mutableStateMapOf<String, String>() }
    
    LaunchedEffect(showDialog) {
        if (showDialog) {
            menuOptions.forEach { (key, _) ->
                selectedMenus[key] = false
                selectedMenuDurations[key] = "NONE"
                selectedMenuCustomDays[key] = ""
            }
            newUserName = ""
            newUserPin = ""
            errorMessage = ""
        }
    }

    LaunchedEffect(showEditDialog) {
        if (showEditDialog && editingUser != null) {
            val user = editingUser!!
            editUserName = user.name
            editUserPin = user.pin
            editErrorMessage = ""
            menuOptions.forEach { (key, _) ->
                editSelectedMenus[key] = true
                editMenuDurations[key] = "LIFETIME"
                editMenuCustomDays[key] = ""
            }
        }
    }

    var selectedTab by remember { mutableStateOf(0) } // 0 = ইউজার পারমিশন, 1 = সিরিয়াল লেজার শিট
    val globalRegistry by viewModel.globalRegistryList.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val unifiedUsers = remember(allUsers, globalRegistry) {
        val list = mutableListOf<com.example.data.api.GlobalUserRegistryItem>()
        globalRegistry.forEach { item ->
            list.add(item)
        }
        allUsers.forEach { user ->
            if (!user.isMaster) {
                val exists = list.any { it.mobile.equals(user.name, ignoreCase = true) }
                if (!exists) {
                    val imei = viewModel.sharedPrefs.getString("user_imei_${user.name}", "") ?: ""
                    val deviceId = imei.ifEmpty { viewModel.getDeviceUniqueId() }
                    val keysMap = viewModel.getSerialKeys(user.name, deviceId)
                    list.add(
                        com.example.data.api.GlobalUserRegistryItem(
                            mobile = user.name,
                            pin = user.pin,
                            imei = deviceId,
                            serial3M = keysMap["৩ মাস"] ?: "",
                            serial6M = keysMap["৬ মাস"] ?: "",
                            serial1Y = keysMap["১ বছর"] ?: "",
                            serialLT = keysMap["আজীবন"] ?: "",
                            lastSync = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
        list.sortedByDescending { it.lastSync }
    }

    val filteredUnifiedUsers = remember(unifiedUsers, searchQuery) {
        if (searchQuery.trim().isEmpty()) {
            unifiedUsers
        } else {
            unifiedUsers.filter {
                it.mobile.contains(searchQuery, ignoreCase = true) ||
                it.imei.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("SerialKey", text)
        clipboard.setPrimaryClip(clip)
        android.widget.Toast.makeText(context, "সিরিয়াল কি কপি করা হয়েছে!", android.widget.Toast.LENGTH_SHORT).show()
    }

    fun shareSerial(mobile: String, duration: String, key: String) {
        val shareText = "হিসেব নিকেশ সিরিয়াল কি 🗝️\nমোবাইল নম্বর: $mobile\nমেয়াদ: $duration\nসিরিয়াল কি: $key\n\nসফটওয়্যারের প্রবেশ স্ক্রিনে কি-টি প্রবেশ করিয়ে আনলক করুন।"
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(sendIntent, "শেয়ার করুন"))
    }

    fun sendEmailReport() {
        val report = com.example.data.api.GlobalUserSyncHelper.formatLedgerSheetText(unifiedUsers)
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = android.net.Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf("drkawsermmc@gmail.com"))
            putExtra(Intent.EXTRA_SUBJECT, "হিসেব নিকেশ: নতুন রেজিস্ট্রেশন ও সিরিয়াল লেজার রিপোর্ট")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        try {
            context.startActivity(Intent.createChooser(emailIntent, "মেইল পাঠান"))
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "মেইল অ্যাপ পাওয়া যায়নি!", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = { showDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "ব্যবহারকারী যোগ করুন"
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Tab selection row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    onClick = { selectedTab = 0 },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 0) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (selectedTab == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    elevation = null
                ) {
                    Icon(Icons.Filled.Person, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ইউজার পারমিশন", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { selectedTab = 1 },
                    modifier = Modifier.weight(1.2f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 1) MaterialTheme.colorScheme.primary else Color.Transparent,
                        contentColor = if (selectedTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 10.dp),
                    elevation = null
                ) {
                    Icon(Icons.Filled.VpnKey, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("সিরিয়াল লেজার শিট", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (selectedTab == 0) {
                Text(
                    text = "নিবন্ধিত ব্যবহারকারী তালিকা",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Text(
                    text = "মাস্টার ইউজার ব্যতীত অন্য সকল ইউজার শুধুমাত্র দৈনিক লেনদেন মেনুটি ব্যবহার করতে পারবেন (ডিফল্ট)। অতিরিক্ত মেনু ব্যবহারের জন্য ইউজার তৈরি বা সংশোধনের সময় অনুমতি সিলেক্ট করে দিন।",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(allUsers) { user ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (user.isMaster) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                                    else MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (user.isMaster) Icons.Filled.AdminPanelSettings else Icons.Filled.Person,
                                                contentDescription = null,
                                                tint = if (user.isMaster) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = user.name,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = if (user.isMaster) "মাস্টার ইউজার" else "সাধারণ ইউজার",
                                                    fontSize = 12.sp,
                                                    color = if (user.isMaster) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "• পিন: ${user.pin}",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                editingUser = user
                                                showEditDialog = true
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Edit,
                                                contentDescription = "সংশোধন করুন",
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        if (!user.isMaster) {
                                            IconButton(
                                                onClick = { viewModel.deleteSubUser(user.name) }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Delete,
                                                    contentDescription = "মুছে ফেলুন",
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "অনুমোদিত মেনুসমূহ:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AssistChip(
                                        onClick = { },
                                        label = { Text("দৈনিক হিসাব (ডিফল্ট)", fontSize = 11.sp) },
                                        colors = AssistChipDefaults.assistChipColors(
                                            labelColor = EmeraldPrimary,
                                            leadingIconContentColor = EmeraldPrimary
                                        )
                                    )

                                    if (user.isMaster) {
                                        menuOptions.forEach { (_, label) ->
                                            AssistChip(
                                                onClick = { },
                                                label = { Text(label.substringBefore(" ("), fontSize = 11.sp) }
                                            )
                                        }
                                    } else {
                                        if (false) {
                                            Text(
                                                text = "কোন অতিরিক্ত অনুমতি নেই",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                                modifier = Modifier.padding(start = 6.dp)
                                            )
                                        } else {
                                            menuOptions.forEach { (key, label) ->
                                                if (true) {
                                                    AssistChip(
                                                        onClick = { },
                                                        label = { Text(label.substringBefore(" ("), fontSize = 11.sp) }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                /*
                                if (!user.isMaster && user.usedKeys.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "ব্যবহৃত Key সমূহ:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        user.usedKeys.forEach { (menu, key) ->
                                            val menuLabel = when (menu) {
                                                "INVESTMENTS" -> "স্থায়ী বিনিয়োগ"
                                                "DEBTS" -> "ঋণ ট্র্যাকার"
                                                "ASSETS" -> "সম্পদ খাতা"
                                                "ZAKAT" -> "যাকাত"
                                                "REPORTS" -> "রিপোর্ট"
                                                "BUSINESS_LEDGER" -> "ব্যবসায়িক"
                                                else -> menu
                                            }
                                            AssistChip(
                                                onClick = { },
                                                label = { Text("$menuLabel: $key", fontSize = 11.sp) },
                                                leadingIcon = {
                                                    Icon(
                                                        imageVector = Icons.Filled.VpnKey,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            )
                                        }
                                    }
                                }
                                */
                            }
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            } else {
                // LEDGER SHEET VIEW FOR SERIAL KEYS
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ডিভাইস ও সিরিয়াল লেজার",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "মোট নিবন্ধিত সাব-ডিভাইস: ${unifiedUsers.size} টি",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { viewModel.loadGlobalRegistry() },
                                    modifier = Modifier.background(MaterialTheme.colorScheme.surface, CircleShape).size(36.dp)
                                ) {
                                    Icon(Icons.Filled.Refresh, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                                Button(
                                    onClick = { sendEmailReport() },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.White),
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Filled.Email, null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("মেইলে ব্যাকআপ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("মোবাইল নম্বর বা ডিভাইস আইডি দিয়ে খুঁজুন", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                if (filteredUnifiedUsers.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.VpnKey, null, tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f), modifier = Modifier.size(48.dp))
                            Text("কোনো রেকর্ড খুঁজে পাওয়া যায়নি!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredUnifiedUsers) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    // User profile header
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Filled.Smartphone, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                                            }
                                            Column {
                                                Text(item.mobile, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Text("পিন: ${item.pin}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                                    Text("•", fontSize = 11.sp, color = Color.Gray)
                                                    Text("ডিভাইস আইডি: ${item.imei.take(12)}...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                                }
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                val detailedText = "মোবাইল: ${item.mobile}\nপিন: ${item.pin}\nডিভাইস আইডি: ${item.imei}\n\n৩ মাস: ${item.serial3M}\n৬ মাস: ${item.serial6M}\n১ বছর: ${item.serial1Y}\nআজীবন: ${item.serialLT}"
                                                copyToClipboard(detailedText)
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Filled.ContentCopy, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                    // Serial list ledger
                                    val serialList = listOf(
                                        Triple("৩ মাস", item.serial3M, MaterialTheme.colorScheme.secondary),
                                        Triple("৬ মাস", item.serial6M, MaterialTheme.colorScheme.tertiary),
                                        Triple("১ বছর", item.serial1Y, MaterialTheme.colorScheme.primary),
                                        Triple("আজীবন", item.serialLT, EmeraldPrimary)
                                    )

                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        serialList.forEach { (duration, key, color) ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
                                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(color.copy(alpha = 0.12f))
                                                            .padding(horizontal = 6.dp, vertical = 3.dp)
                                                    ) {
                                                        Text(duration, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
                                                    }
                                                    Text(
                                                        text = key,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    IconButton(
                                                        onClick = { copyToClipboard(key) },
                                                        modifier = Modifier.size(26.dp)
                                                    ) {
                                                        Icon(Icons.Filled.ContentCopy, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(13.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { shareSerial(item.mobile, duration, key) },
                                                        modifier = Modifier.size(26.dp)
                                                    ) {
                                                        Icon(Icons.Filled.Share, null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(13.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        Dialog(onDismissRequest = { showDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "নতুন ব্যবহারকারী যোগ করুন",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newUserName,
                        onValueChange = { newUserName = it },
                        label = { Text("ব্যবহারকারীর নাম") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Person, "নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = newUserPin,
                        onValueChange = { if (it.length <= 12) newUserPin = it },
                        label = { Text("৪-১২ সংখ্যার পিন কোড") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Icon(Icons.Filled.Lock, "পিন") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Text(
                        text = "অতিরিক্ত মেনু ব্যবহারের অনুমতি দিন:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        menuOptions.forEach { (key, label) ->
                            val isChecked = selectedMenus[key] ?: false
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.03f)
                                        else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val nextVal = !isChecked
                                            selectedMenus[key] = nextVal
                                            if (!nextVal) {
                                                selectedMenuDurations[key] = "NONE"
                                            }
                                        },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { nextVal ->
                                            selectedMenus[key] = nextVal
                                            if (!nextVal) {
                                                selectedMenuDurations[key] = "NONE"
                                            }
                                        }
                                    )
                                    Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                                }

                                if (isChecked) {
                                    Column(
                                        modifier = Modifier.padding(start = 32.dp, bottom = 4.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "মেয়াদকাল নির্ধারণ করুন:",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )

                                        val currentSel = selectedMenuDurations[key] ?: "NONE"
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            listOf(
                                                Pair("14_DAYS", "১৪ দিন"),
                                                Pair("6_MONTHS", "৬ মাস"),
                                                Pair("1_YEAR", "১ বছর"),
                                                Pair("LIFETIME", "আজীবন"),
                                                Pair("CUSTOM", "কাস্টম")
                                            ).forEach { (opt, optLabel) ->
                                                val isOptSel = currentSel == opt
                                                FilterChip(
                                                    selected = isOptSel,
                                                    onClick = { 
                                                        selectedMenuDurations[key] = opt 
                                                    },
                                                    label = { Text(optLabel, fontSize = 11.sp) }
                                                )
                                            }
                                        }

                                        if (currentSel == "CUSTOM") {
                                            OutlinedTextField(
                                                value = selectedMenuCustomDays[key] ?: "",
                                                onValueChange = { selectedMenuCustomDays[key] = it },
                                                label = { Text("দিনের সংখ্যা", fontSize = 11.sp) },
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                modifier = Modifier.width(150.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (errorMessage.isNotEmpty()) {
                        Text(
                            text = errorMessage,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val name = newUserName.trim()
                                val pin = newUserPin.trim()
                                if (name.isBlank()) {
                                    errorMessage = "দয়া করে ব্যবহারকারীর নাম লিখুন।"
                                    return@Button
                                }
                                if (pin.length !in 4..12 || !pin.all { it.isDigit() }) {
                                    errorMessage = "দয়া করে ৪ থেকে ১২ সংখ্যার পিন কোড দিন।"
                                    return@Button
                                }

                                val permitted = mutableListOf<String>()
                                val expiries = mutableMapOf<String, Long>()
                                menuOptions.forEach { (key, _) ->
                                    val isChecked = selectedMenus[key] ?: false
                                    if (isChecked) {
                                        val opt = selectedMenuDurations[key] ?: "NONE"
                                        if (opt != "NONE") {
                                            val expiry = calculateExpiryTimestamp(opt, selectedMenuCustomDays[key] ?: "")
                                            if (expiry > 0L) {
                                                permitted.add(key)
                                                expiries[key] = expiry
                                            }
                                        }
                                    }
                                }

                                val success = viewModel.addSubUser(name, pin, permitted, expiries)
                                if (success) {
                                    showDialog = false
                                } else {
                                    errorMessage = "ব্যবহারকারী তৈরি করা যায়নি! সম্ভবত এই নামের ইউজার ইতিমধ্যে নিবন্ধিত।"
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("সংরক্ষণ করুন")
                        }
                    }
                }
            }
        }
    }

    if (showEditDialog && editingUser != null) {
        val user = editingUser!!
        Dialog(onDismissRequest = { showEditDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (user.isMaster) "মাস্টার ব্যবহারকারীর পিন সংশোধন" else "ব্যবহারকারী তথ্য সংশোধন",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editUserName,
                        onValueChange = { if (!user.isMaster) editUserName = it },
                        label = { Text("ব্যবহারকারীর নাম") },
                        singleLine = true,
                        enabled = !user.isMaster,
                        leadingIcon = { Icon(Icons.Filled.Person, "নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = editUserPin,
                        onValueChange = { if (it.length <= 12) editUserPin = it },
                        label = { Text("৪-১২ সংখ্যার পিন কোড") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = { Icon(Icons.Filled.Lock, "পিন") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (user.isMaster) {
                        Text(
                            text = "মাস্টার ইউজারের সকল মেনুতে অ্যাক্সেস আছে (ডিফল্ট)।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        Text(
                            text = "অতিরিক্ত মেনু ব্যবহারের অনুমতি দিন:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )

                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            menuOptions.forEach { (key, label) ->
                                val isChecked = editSelectedMenus[key] ?: false
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.03f)
                                            else Color.Transparent,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                val nextVal = !isChecked
                                                editSelectedMenus[key] = nextVal
                                                if (!nextVal) {
                                                    editMenuDurations[key] = "NONE"
                                                }
                                            }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { nextVal ->
                                                editSelectedMenus[key] = nextVal
                                                if (!nextVal) {
                                                    editMenuDurations[key] = "NONE"
                                                }
                                            }
                                        )
                                        Column {
                                            Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                                            val currentExpiry = Long.MAX_VALUE
                                            Text(
                                                text = "বর্তমান অবস্থা: ${getExpiryDisplayString(currentExpiry)}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                            )
                                        }
                                    }

                                    if (isChecked) {
                                        Column(
                                            modifier = Modifier.padding(start = 32.dp, bottom = 4.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "মেয়াদকাল নির্ধারণ করুন:",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )

                                            val currentSel = editMenuDurations[key] ?: "NONE"
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .horizontalScroll(rememberScrollState()),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val editOptions = mutableListOf<Pair<String, String>>()
                                                if (true) {
                                                    editOptions.add(Pair("CURRENT", "বর্তমান মেয়াদ"))
                                                }
                                                editOptions.addAll(listOf(
                                                    Pair("14_DAYS", "১৪ দিন"),
                                                    Pair("6_MONTHS", "৬ মাস"),
                                                    Pair("1_YEAR", "১ বছর"),
                                                    Pair("LIFETIME", "আজীবন"),
                                                    Pair("CUSTOM", "কাস্টম")
                                                ))

                                                editOptions.forEach { (opt, optLabel) ->
                                                    val isOptSel = currentSel == opt
                                                    FilterChip(
                                                        selected = isOptSel,
                                                        onClick = { 
                                                            editMenuDurations[key] = opt 
                                                        },
                                                        label = { Text(optLabel, fontSize = 11.sp) }
                                                    )
                                                }
                                            }

                                            if (currentSel == "CUSTOM") {
                                                OutlinedTextField(
                                                    value = editMenuCustomDays[key] ?: "",
                                                    onValueChange = { editMenuCustomDays[key] = it },
                                                    label = { Text("দিনের সংখ্যা", fontSize = 11.sp) },
                                                    singleLine = true,
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                    modifier = Modifier.width(150.dp),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (editErrorMessage.isNotEmpty()) {
                        Text(
                            text = editErrorMessage,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showEditDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val name = editUserName.trim()
                                val pin = editUserPin.trim()
                                if (name.isBlank()) {
                                    editErrorMessage = "দয়া করে ব্যবহারকারীর নাম লিখুন।"
                                    return@Button
                                }
                                if (pin.length !in 4..12 || !pin.all { it.isDigit() }) {
                                    editErrorMessage = "দয়া করে ৪ থেকে ১২ সংখ্যার পিন কোড দিন।"
                                    return@Button
                                }

                                val success = if (user.isMaster) {
                                    viewModel.updateMasterUser(name, pin)
                                } else {
                                    val permitted = mutableListOf<String>()
                                    val expiries = mutableMapOf<String, Long>()
                                    
                                    menuOptions.forEach { (key, _) ->
                                        val isChecked = editSelectedMenus[key] ?: false
                                        if (isChecked) {
                                            val opt = editMenuDurations[key] ?: "NONE"
                                            if (opt != "NONE") {
                                                val expiry = calculateExpiryTimestamp(
                                                    opt, 
                                                    editMenuCustomDays[key] ?: "", 
                                                    Long.MAX_VALUE
                                                )
                                                if (expiry > 0L) {
                                                    permitted.add(key)
                                                    expiries[key] = expiry
                                                }
                                            }
                                        }
                                    }
                                    viewModel.updateSubUser(user.name, name, pin)
                                }
                                if (success) {
                                    showEditDialog = false
                                } else {
                                    editErrorMessage = "ব্যবহারকারী তথ্য সংশোধন করা যায়নি! সম্ভবত এই নাম ইতিমধ্যে ব্যবহৃত।"
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("হালনাগাদ করুন")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UnlockDialog(
    viewModel: FinancialViewModel,
    screen: Screen,
    onDismiss: () -> Unit
) {
    var keyInput by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.VpnKey,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Text(
                    text = "আনলক করতে Key 🗝️ প্রদান করুন",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "এই মেনুটি ব্যবহার করার অনুমতি আপনার অ্যাকাউন্টে নেই। অনুগ্রহ করে একটি সঠিক আনলক Key প্রদান করুন।",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )

                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { 
                        keyInput = it
                        showError = false 
                    },
                    label = { Text("Key লিখুন") },
                    singleLine = true,
                    isError = showError,
                    leadingIcon = { Icon(Icons.Filled.Lock, "Key") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                if (showError) {
                    Text(
                        text = "ভুল বা অবৈধ Key! সঠিক Key প্রদান করুন।",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            val success = viewModel.unlockScreenWithKey(screen, keyInput)
                            if (success) {
                                viewModel.navigateTo(screen)
                                onDismiss()
                            } else {
                                showError = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("আনলক করুন")
                    }
                }
            }
        }
    }
}

@Composable
fun CloudSyncDialog(
    viewModel: FinancialViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsStateWithLifecycle()
    val isAutoSyncEnabled by viewModel.isAutoSyncEnabled.collectAsStateWithLifecycle()
    val googleAccountEmail by viewModel.googleAccountEmail.collectAsStateWithLifecycle()
    val googleDriveAuthIntent by viewModel.googleDriveAuthIntent.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(0) }
    var showRestoreWarning by remember { mutableStateOf(false) }
    var showGoogleRestoreWarning by remember { mutableStateOf(false) }

    // Google Sign-In setup
    val gso = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope("https://www.googleapis.com/auth/drive.file"))
            .build()
    }
    val googleSignInClient = remember { GoogleSignIn.getClient(context, gso) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val email = account?.email
            if (!email.isNullOrBlank()) {
                viewModel.connectGoogleAccount(email)
            } else {
                Log.e("GoogleDriveSync", "Sign-in succeeded but email is empty")
            }
        } catch (e: Exception) {
            Log.e("GoogleDriveSync", "Google Sign-In failed", e)
        }
    }

    val authLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        viewModel.clearGoogleDriveAuthIntent()
    }

    LaunchedEffect(googleDriveAuthIntent) {
        googleDriveAuthIntent?.let { intent ->
            authLauncher.launch(intent)
        }
    }

    Dialog(onDismissRequest = { if (!isSyncing) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("cloud_sync_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Cloud,
                            contentDescription = "ক্লাউড স্টোরেজ",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "ডাটা সিঙ্ক ও ব্যাকআপ",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSyncing
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "বন্ধ করুন",
                            tint = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("অনলাইন ডাটাবেজ", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("গুগল ড্রাইভ", fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (selectedTab == 0) {
                    // --- ONLINE DATABASE SYNC ---
                    // User profile info card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "ব্যবহারকারী: $userName",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "স্টোরেজ সিস্টেম: অনলাইন পৃথক ডাটাবেজ",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }

                    // Auto sync Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "অটো-সিঙ্ক ব্যাকআপ",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "যেকোনো পরিবর্তনের পর স্বয়ংক্রিয়ভাবে ক্লাউডে সুরক্ষিত হবে",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                        Switch(
                            checked = isAutoSyncEnabled,
                            onCheckedChange = { viewModel.toggleAutoSync(it) },
                            enabled = !isSyncing
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Sync Actions
                    if (showRestoreWarning) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "সতর্কতা!",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = "অনলাইন ডাটাবেজ থেকে রিস্টোর করলে মোবাইলের বর্তমান সমস্ত তথ্য মুছে গিয়ে অনলাইন ব্যাকআপ লোড হবে। আপনি কি নিশ্চিত?",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    TextButton(
                                        onClick = { showRestoreWarning = false },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("বাতিল", color = MaterialTheme.colorScheme.error)
                                    }
                                    Button(
                                        onClick = {
                                            showRestoreWarning = false
                                            viewModel.restoreFromCloud(userName)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1.5f)
                                    ) {
                                        Text("হ্যাঁ, রিস্টোর করুন")
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { viewModel.backupToCloud(userName) },
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CloudUpload,
                                    contentDescription = "ক্লাউডে সেভ করুন"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("ক্লাউডে ব্যাকআপ করুন", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { showRestoreWarning = true },
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CloudDownload,
                                    contentDescription = "ক্লাউড থেকে লোড করুন"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("ক্লাউড থেকে রিস্টোর করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    // --- GOOGLE DRIVE BACKUP ---
                    if (googleAccountEmail == null) {
                        // Google Account not connected
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "গুগল ড্রাইভ ব্যাকআপ",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "গুগল ড্রাইভে সুরক্ষিতভাবে আপনার ডাটা ব্যাকআপ করে রাখুন। কখনো এই অ্যাপ আনইন্সটল হয়ে গেলে পুনরায় ইনস্টল করে ওই ব্যাকআপ থেকে সমস্ত কিছু আবার লাইভ করতে পারবেন।",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                    )
                                }
                            }

                            Button(
                                onClick = { googleSignInLauncher.launch(googleSignInClient.signInIntent) },
                                enabled = !isSyncing,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Login,
                                    contentDescription = "গুগল সাইন-ইন"
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("গুগল ড্রাইভ কানেক্ট করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // Google Account connected
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "কানেক্টেড গুগল ড্রাইভ",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = googleAccountEmail ?: "",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.disconnectGoogleAccount() },
                                        enabled = !isSyncing
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Logout,
                                            contentDescription = "ডিসকানেক্ট",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }

                            if (showGoogleRestoreWarning) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "রিস্টোর সতর্কতা!",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                        Text(
                                            text = "গুগল ড্রাইভের ফাইল থেকে ডাটা রিস্টোর করলে মোবাইলের বর্তমান সমস্ত তথ্য মুছে গিয়ে গুগল ড্রাইভের ব্যাকআপ লোড হবে। আপনি কি নিশ্চিত?",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                        var restorePassword by remember { mutableStateOf("") }
                                        OutlinedTextField(
                                            value = restorePassword,
                                            onValueChange = { restorePassword = it },
                                            label = { Text("রিস্টোর পাসওয়ার্ড") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            TextButton(
                                                onClick = { showGoogleRestoreWarning = false },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("বাতিল", color = MaterialTheme.colorScheme.error)
                                            }
                                            Button(
                                                onClick = {
                                                    showGoogleRestoreWarning = false
                                                    viewModel.restoreFromGoogleDrive(restorePassword)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.weight(1.5f)
                                            ) {
                                                Text("হ্যাঁ, রিস্টোর করুন")
                                            }
                                        }
                                    }
                                }
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    var backupPassword by remember { mutableStateOf("") }
                                    OutlinedTextField(
                                        value = backupPassword,
                                        onValueChange = { backupPassword = it },
                                        label = { Text("ব্যাকআপ পাসওয়ার্ড") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Button(
                                        onClick = { viewModel.backupToGoogleDrive(backupPassword) },
                                        enabled = !isSyncing && backupPassword.isNotEmpty(),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Backup,
                                            contentDescription = "ড্রাইভ ব্যাকআপ"
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("গুগল ড্রাইভে ব্যাকআপ করুন", fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { showGoogleRestoreWarning = true },
                                        enabled = !isSyncing,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.SettingsBackupRestore,
                                            contentDescription = "ড্রাইভ রিস্টোর"
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("গুগল ড্রাইভ থেকে রিস্টোর করুন", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Sync Progress & Status messages
                if (isSyncing || syncStatusMessage != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isSyncing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(32.dp),
                                    strokeWidth = 3.dp
                                )
                            }
                            syncStatusMessage?.let { msg ->
                                val translatedMsg = translateText(msg, LocalContext.current)
                                val isError = msg.contains("ব্যর্থ") || msg.contains("সমস্যা") || msg.contains("ভুল") || translatedMsg.contains("failed", ignoreCase = true) || translatedMsg.contains("error", ignoreCase = true) || translatedMsg.contains("wrong", ignoreCase = true)
                                val isSuccess = msg.contains("সফল") || translatedMsg.contains("success", ignoreCase = true)
                                Text(
                                    text = translatedMsg,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isError) {
                                        MaterialTheme.colorScheme.error
                                    } else if (isSuccess) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
//                           BUSINESS LEDGER MODULE
// =========================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessLedgerScreen(viewModel: FinancialViewModel) {
    val context = LocalContext.current
    val categories by viewModel.businessCategories.collectAsStateWithLifecycle()
    val items by viewModel.businessItems.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableStateOf(0) }

    // Dialog control states
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }

    var showAddItemDialog by remember { mutableStateOf(false) }
    var selectedCategoryIdForNewItem by remember { mutableStateOf<Int?>(null) }
    var newItemName by remember { mutableStateOf("") }
    var newItemPurchasePrice by remember { mutableStateOf("") }
    var newItemSalePrice by remember { mutableStateOf("") }
    var newItemQuantity by remember { mutableStateOf("1") }

    var showSellItemDialog by remember { mutableStateOf(false) }
    var sellingItem by remember { mutableStateOf<BusinessItem?>(null) }
    var customSalePriceInput by remember { mutableStateOf("") }

    // Search and filter states
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<Int?>(null) }
    var statusFilter by remember { mutableStateOf("ALL") } // "ALL", "STOCK", "SOLD"

    // Monthly Report states
    val calendar = Calendar.getInstance()
    var selectedMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) }
    var selectedYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }

    val months = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    val currentMonth = calendar.get(Calendar.MONTH)
    val currentYear = calendar.get(Calendar.YEAR)

    // Current Month sold items & profit
    val currentMonthSales = items.filter { item ->
        if (item.isSold && item.saleDate != null) {
            val cal = Calendar.getInstance().apply { timeInMillis = item.saleDate }
            cal.get(Calendar.MONTH) == currentMonth && cal.get(Calendar.YEAR) == currentYear
        } else {
            false
        }
    }

    val currentMonthSoldQty = currentMonthSales.size
    val currentMonthProfit = currentMonthSales.sumOf { it.profit }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // --- BUSINESS HEADER ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "MAKS FINEX",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = tr("business_title", "Business"),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }

            var isDashboardExpanded by remember { mutableStateOf(true) }

            // Collapsible Dashboard Display Card at the top (Highly Compact & Responsive)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isDashboardExpanded = !isDashboardExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Storefront,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = tr("business_summary", "Business Summary") + " (${months[currentMonth]})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Icon(
                            imageVector = if (isDashboardExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "Toggle",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    if (isDashboardExpanded) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Sold Qty card
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = tr("business_total_sold", "Total Sold"),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Text(
                                        text = "$currentMonthSoldQty",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }

                            // Profit card
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = tr("business_current_profit", "Current Profit"),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Text(
                                        text = formatTaka(currentMonthProfit),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    try {
                                        val file = PdfReportHelper.generateBusinessReportPdf(
                                            context,
                                            userName,
                                            categories,
                                            items
                                        )
                                        PdfReportHelper.sharePdf(context, file)
                                    } catch (e: Exception) {
                                        viewModel.showToast("পিডিএফ তৈরিতে সমস্যা হয়েছে: ${e.message}")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f).height(48.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Text(tr("business_download_pdf", "Download PDF"), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Modern Responsive Segmented Tab Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), shape = RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf(
                    Triple(0, "স্টক ও ক্যাটাগরি", Icons.Filled.Category),
                    Triple(1, "আইটেম ও বিক্রয়", Icons.Filled.Storefront),
                    Triple(2, "মাসিক রিপোর্ট", Icons.Filled.BarChart)
                )
                tabs.forEach { (index, label, icon) ->
                    val isSelected = selectedTabIndex == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary 
                                else Color.Transparent
                            )
                            .clickable { selectedTabIndex = index }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = label,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Tab Contents
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (selectedTabIndex) {
                    0 -> TabCategoriesAndStock(
                        categories = categories,
                        items = items,
                        onAddCategoryClick = { showAddCategoryDialog = true },
                        onAddItemToCategory = {
                            selectedCategoryIdForNewItem = it
                            showAddItemDialog = true
                        },
                        viewModel = viewModel
                    )
                    1 -> TabItemsListAndSales(
                        categories = categories,
                        items = items,
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        selectedCategoryFilter = selectedCategoryFilter,
                        onCategoryFilterChange = { selectedCategoryFilter = it },
                        statusFilter = statusFilter,
                        onStatusFilterChange = { statusFilter = it },
                        onSellClick = {
                            sellingItem = it
                            customSalePriceInput = it.salePrice.toString()
                            showSellItemDialog = true
                        },
                        onDeleteClick = { viewModel.deleteBusinessItem(it) },
                        onAddItemClick = {
                            selectedCategoryIdForNewItem = null
                            showAddItemDialog = true
                        }
                    )
                    2 -> TabMonthlyLedgerReport(
                        categories = categories,
                        items = items,
                        selectedMonth = selectedMonth,
                        onMonthSelect = { selectedMonth = it },
                        selectedYear = selectedYear,
                        onYearSelect = { selectedYear = it },
                        months = months
                    )
                }
            }
        }
    }

    // 1. ADD CATEGORY DIALOG
    if (showAddCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("নতুন ক্যাটাগরি যোগ করুন", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ক্যাটাগরি নাম দিন:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    OutlinedTextField(
                        value = newCategoryName,
                        onValueChange = { newCategoryName = it },
                        placeholder = { Text("যেমন: কসমেটিকস, গ্রোসারি") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCategoryName.isNotBlank()) {
                            viewModel.addBusinessCategory(newCategoryName)
                            newCategoryName = ""
                            showAddCategoryDialog = false
                        }
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("যোগ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // 2. ADD ITEM DIALOG
    if (showAddItemDialog) {
        AlertDialog(
            onDismissRequest = { showAddItemDialog = false },
            title = { Text("নতুন আইটেম যোগ করুন", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    // Category Selection (only shown if not pre-selected)
                    if (selectedCategoryIdForNewItem == null) {
                        var expanded by remember { mutableStateOf(false) }
                        var selectedCat = categories.firstOrNull { it.id == selectedCategoryIdForNewItem }
                        
                        Text("ক্যাটাগরি নির্বাচন করুন:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Box {
                            OutlinedCard(
                                onClick = { expanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = selectedCat?.name ?: "সিলেক্ট করুন...",
                                        fontSize = 13.sp
                                    )
                                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                                }
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat.name) },
                                        onClick = {
                                            selectedCategoryIdForNewItem = cat.id
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        val preSelectedCat = categories.firstOrNull { it.id == selectedCategoryIdForNewItem }
                        Text(
                            text = tr("category_prefix", "Category: ") + (preSelectedCat?.name ?: tr("unknown", "Unknown")),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Item Name
                    Text("আইটেম নাম:", fontSize = 12.sp)
                    OutlinedTextField(
                        value = newItemName,
                        onValueChange = { newItemName = it },
                        placeholder = { Text("যেমন: লাক্স সাবান ১০০গ্রাম") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Purchase Price
                    Text("ক্রয় মূল্য (প্রতিটির):", fontSize = 12.sp)
                    OutlinedTextField(
                        value = newItemPurchasePrice,
                        onValueChange = { newItemPurchasePrice = it },
                        placeholder = { Text("যেমন: ৪৫.৫০") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Sale Price
                    Text("বিক্রয় মূল্য (প্রতিটির):", fontSize = 12.sp)
                    OutlinedTextField(
                        value = newItemSalePrice,
                        onValueChange = { newItemSalePrice = it },
                        placeholder = { Text("যেমন: ৫৫.০০") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Quantity (for bulk add)
                    Text("পরিমাণ (কতটি আইটেম যোগ করবেন?):", fontSize = 12.sp)
                    OutlinedTextField(
                        value = newItemQuantity,
                        onValueChange = { newItemQuantity = it },
                        placeholder = { Text("যেমন: ১, ৫, ১০") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val catId = selectedCategoryIdForNewItem
                        val name = newItemName.trim()
                        val pPrice = newItemPurchasePrice.toDoubleOrNull() ?: 0.0
                        val sPrice = newItemSalePrice.toDoubleOrNull() ?: 0.0
                        val qty = newItemQuantity.toIntOrNull() ?: 1

                        if (catId != null && name.isNotEmpty() && pPrice >= 0 && sPrice >= 0 && qty > 0) {
                            viewModel.addBusinessItems(catId, name, pPrice, sPrice, qty)
                            
                            // Reset state
                            newItemName = ""
                            newItemPurchasePrice = ""
                            newItemSalePrice = ""
                            newItemQuantity = "1"
                            showAddItemDialog = false
                        } else {
                            viewModel.showToast("অনুগ্রহ করে সকল তথ্য সঠিক উপায়ে পূরণ করুন!")
                        }
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("যোগ করুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        newItemName = ""
                        newItemPurchasePrice = ""
                        newItemSalePrice = ""
                        newItemQuantity = "1"
                        showAddItemDialog = false
                    }
                ) {
                    Text("বাতিল")
                }
            }
        )
    }

    // 3. SELL ITEM DIALOG (WITH OVERRIDE SALE PRICE OPTION)
    if (showSellItemDialog && sellingItem != null) {
        val item = sellingItem!!
        AlertDialog(
            onDismissRequest = { showSellItemDialog = false },
            title = { Text("আইটেমটি বিক্রয় নিশ্চিত করুন", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = tr("item_prefix", "Item: ") + item.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = tr("purchase_price_was", "Purchase Price was: ") + formatTaka(item.purchasePrice), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("বিক্রয় মূল্য নির্ধারণ করুন:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customSalePriceInput,
                        onValueChange = { customSalePriceInput = it },
                        placeholder = { Text("যেমন: ৬০.০০") },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val salePrice = customSalePriceInput.toDoubleOrNull()
                        if (salePrice != null && salePrice >= 0) {
                            viewModel.sellBusinessItem(item.id, salePrice)
                            showSellItemDialog = false
                            sellingItem = null
                        } else {
                            viewModel.showToast("অনুগ্রহ করে সঠিক বিক্রয় মূল্য দিন!")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("বিক্রয় সম্পূর্ণ করুন", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showSellItemDialog = false
                    sellingItem = null
                }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun TabCategoriesAndStock(
    categories: List<BusinessCategory>,
    items: List<BusinessItem>,
    onAddCategoryClick: () -> Unit,
    onAddItemToCategory: (Int) -> Unit,
    viewModel: FinancialViewModel
) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (categories.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Category,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "কোনো ব্যবসায়িক ক্যাটাগরি তৈরি করা হয়নি।",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAddCategoryClick,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ক্যাটাগরি তৈরি করুন")
                }
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Prominent Quick Actions Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onAddCategoryClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Filled.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ক্যাটাগরি যোগ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (categories.isNotEmpty()) {
                                onAddItemToCategory(categories.first().id)
                            } else {
                                viewModel.showToast("প্রথমে একটি ক্যাটাগরি যোগ করুন")
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Filled.Inventory, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("নতুন স্টক/আইটেম যোগ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("category_list_prefix", "Category List") + " (${categories.size} " + tr("pcs", "pcs") + ")",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(categories) { category ->
                        val catItems = items.filter { it.categoryId == category.id }
                        val stockCount = catItems.count { !it.isSold }
                        val soldCount = catItems.count { it.isSold }
                        val totalProfit = catItems.filter { it.isSold }.sumOf { it.profit }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = category.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    IconButton(
                                        onClick = { viewModel.deleteBusinessCategory(category.id) },
                                        colors = IconButtonDefaults.iconButtonColors(
                                            contentColor = MaterialTheme.colorScheme.error
                                        ),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = "ক্যাটাগরি ডিলিট", modifier = Modifier.size(20.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Total Stock
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("অবশিষ্ট স্টক", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        Text("$stockCount টি", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (stockCount > 0) EmeraldPrimary else MaterialTheme.colorScheme.error)
                                    }

                                    // Total Sold
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("মোট বিক্রিত", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        Text("$soldCount টি", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    }

                                    // Cumulative Profit
                                    Column(modifier = Modifier.weight(1.2f)) {
                                        Text("অর্জিত লাভ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        Text(formatTaka(totalProfit), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepTeal)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { onAddItemToCategory(category.id) }
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("আইটেম যোগ করুন")
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabItemsListAndSales(
    categories: List<BusinessCategory>,
    items: List<BusinessItem>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedCategoryFilter: Int?,
    onCategoryFilterChange: (Int?) -> Unit,
    statusFilter: String,
    onStatusFilterChange: (String) -> Unit,
    onSellClick: (BusinessItem) -> Unit,
    onDeleteClick: (Int) -> Unit,
    onAddItemClick: () -> Unit
) {
    var showCategoryFilterDropdown by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter and Search Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("আইটেম নাম খুঁজুন...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Filled.Clear, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier.weight(1.8f),
                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
            )

            // Category Filter Dropdown
            Box(modifier = Modifier.weight(1.2f)) {
                Button(
                    onClick = { showCategoryFilterDropdown = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedCategoryFilter != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (selectedCategoryFilter != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text(
                            text = if (selectedCategoryFilter != null) {
                                categories.firstOrNull { it.id == selectedCategoryFilter }?.name ?: "ফিল্টার"
                            } else {
                                "সকল ক্যাটাগরি"
                            },
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                DropdownMenu(
                    expanded = showCategoryFilterDropdown,
                    onDismissRequest = { showCategoryFilterDropdown = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("সকল ক্যাটাগরি") },
                        onClick = {
                            onCategoryFilterChange(null)
                            showCategoryFilterDropdown = false
                        }
                    )
                    categories.forEach { category ->
                        DropdownMenuItem(
                            text = { Text(category.name) },
                            onClick = {
                                onCategoryFilterChange(category.id)
                                showCategoryFilterDropdown = false
                            }
                        )
                    }
                }
            }
        }

        // Status filter tabs: ALL, STOCK, SOLD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                Pair("ALL", "সকল আইটেম"),
                Pair("STOCK", "স্টকে আছে"),
                Pair("SOLD", "বিক্রিত")
            )
            filters.forEach { (key, label) ->
                val isSelected = statusFilter == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .clickable { onStatusFilterChange(key) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Quick add floating or inline trigger
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "আইটেম বিবরণী",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            FilledTonalButton(
                onClick = onAddItemClick,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("আইটেম যোগ করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        val filteredItems = items.filter { item ->
            val matchesSearch = item.name.contains(searchQuery, ignoreCase = true)
            val matchesCategory = selectedCategoryFilter == null || item.categoryId == selectedCategoryFilter
            val matchesStatus = when (statusFilter) {
                "STOCK" -> !item.isSold
                "SOLD" -> item.isSold
                else -> true
            }
            matchesSearch && matchesCategory && matchesStatus
        }

        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Inventory,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "কোনো আইটেম পাওয়া যায়নি।",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredItems) { item ->
                    val categoryName = categories.firstOrNull { it.id == item.categoryId }?.name ?: "অজানা"

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "#${item.id}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(
                                            text = item.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = tr("category_prefix", "Category: ") + tr(categoryName),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(100.dp))
                                        .background(
                                            if (item.isSold) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (item.isSold) "বিক্রিত" else "স্টকে আছে",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.isSold) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Column {
                                        Text("ক্রয় মূল্য", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(formatTaka(item.purchasePrice), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("বিক্রয় মূল্য", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text(formatTaka(item.salePrice), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                    if (item.isSold) {
                                        Column {
                                            Text("অর্জিত লাভ", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                            Text(formatTaka(item.profit), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                        }
                                    }
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!item.isSold) {
                                        Button(
                                            onClick = { onSellClick(item) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = EmeraldPrimary,
                                                contentColor = Color.White
                                            ),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Filled.Storefront, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("বিক্রয়", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }

                                    IconButton(
                                        onClick = { onDeleteClick(item.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Delete,
                                            contentDescription = "আইটেম ডিলিট",
                                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabMonthlyLedgerReport(
    categories: List<BusinessCategory>,
    items: List<BusinessItem>,
    selectedMonth: Int,
    onMonthSelect: (Int) -> Unit,
    selectedYear: Int,
    onYearSelect: (Int) -> Unit,
    months: List<String>
) {
    var showMonthDropdown by remember { mutableStateOf(false) }
    var showYearDropdown by remember { mutableStateOf(false) }

    val years = (2020..2030).toList()

    // Filter items sold in the selected month & year
    val monthlySales = items.filter { item ->
        if (item.isSold && item.saleDate != null) {
            val cal = Calendar.getInstance().apply { timeInMillis = item.saleDate }
            cal.get(Calendar.MONTH) == selectedMonth && cal.get(Calendar.YEAR) == selectedYear
        } else {
            false
        }
    }

    val totalSoldQty = monthlySales.size
    val totalProfit = monthlySales.sumOf { it.profit }
    val totalRevenue = monthlySales.sumOf { it.salePrice }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Date Pickers row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Month Picker
            Box(modifier = Modifier.weight(1f)) {
                OutlinedCard(
                    onClick = { showMonthDropdown = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = months[selectedMonth], fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                    }
                }
                DropdownMenu(
                    expanded = showMonthDropdown,
                    onDismissRequest = { showMonthDropdown = false }
                ) {
                    months.forEachIndexed { index, m ->
                        DropdownMenuItem(
                            text = { Text(m) },
                            onClick = {
                                onMonthSelect(index)
                                showMonthDropdown = false
                            }
                        )
                    }
                }
            }

            // Year Picker
            Box(modifier = Modifier.weight(1f)) {
                OutlinedCard(
                    onClick = { showYearDropdown = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = selectedYear.toString(), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                    }
                }
                DropdownMenu(
                    expanded = showYearDropdown,
                    onDismissRequest = { showYearDropdown = false }
                ) {
                    years.forEach { y ->
                        DropdownMenuItem(
                            text = { Text(y.toString()) },
                            onClick = {
                                onYearSelect(y)
                                showYearDropdown = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mini monthly cards
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = tr(months[selectedMonth]) + " " + selectedYear + " " + tr("report", "Report"),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Sold Qty
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(10.dp)
                    ) {
                        Text("বিক্রিত সংখ্যা", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("$totalSoldQty টি", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    // Total revenue
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(10.dp)
                    ) {
                        Text("মোট বিক্রয় মূল্য", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(formatTaka(totalRevenue), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Total Profit (Prominent bottom card)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("মোট নীট লাভ", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(formatTaka(totalProfit), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = EmeraldPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Category-wise Breakdown table/list
        Text(
            text = "ক্যাটাগরি ভিত্তিক বিক্রয় ও লাভ",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (categories.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("কোনো ক্যাটাগরির তথ্য নেই।", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        } else {
            categories.forEach { category ->
                val catItems = items.filter { it.categoryId == category.id }
                val catMonthlySales = catItems.filter { item ->
                    if (item.isSold && item.saleDate != null) {
                        val cal = Calendar.getInstance().apply { timeInMillis = item.saleDate }
                        cal.get(Calendar.MONTH) == selectedMonth && cal.get(Calendar.YEAR) == selectedYear
                    } else {
                        false
                    }
                }

                val catSoldQty = catMonthlySales.size
                val catProfit = catMonthlySales.sumOf { it.profit }
                val catRevenue = catMonthlySales.sumOf { it.salePrice }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = category.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tr("sold_prefix", "Sold: ") + "$catSoldQty " + tr("pcs", "pcs") + "  |  " + tr("total_sale_prefix", "Total Sale: ") + formatTaka(catRevenue),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "লাভ",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                            Text(
                                text = formatTaka(catProfit),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (catProfit >= 0) EmeraldPrimary else MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
fun SettingsScreen(viewModel: FinancialViewModel) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val appLocale by viewModel.appLocale.collectAsStateWithLifecycle()

    var showSelfEditDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showLanguageSelectionDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = tr("settings_menu", "সেটিং"),
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
        )

        // Group 1: General Settings
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                // Item 1: App Settings (Theme & Language)
                SettingsRowItem(
                    title = tr("app_settings_item", "অ্যাপ সেটিংস"),
                    subtitle = tr("app_settings_desc", "ডার্ক মোড ও ভাষা পরিবর্তন করুন"),
                    icon = Icons.Filled.Settings,
                    onClick = { showSettingsDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Item 2: Profile Edit
                SettingsRowItem(
                    title = tr("edit_profile_item", "প্রোফাইল সংশোধন"),
                    subtitle = tr("edit_profile_desc", "আপনার নাম ও পিন সংশোধন করুন"),
                    icon = Icons.Filled.Person,
                    onClick = { showSelfEditDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Item 3: Backup & Restore
                SettingsRowItem(
                    title = tr("sync_backup_item", "ডাটা ব্যাকআপ ও রিস্টোর"),
                    subtitle = tr("sync_backup_desc", "গুগল ড্রাইভ ব্যাকআপ ও রিস্টোর"),
                    icon = Icons.Filled.Cloud,
                    onClick = { showSyncDialog = true }
                )

                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                // Item Premium
                SettingsRowItem(
                    title = tr("premium_menu", "MAKS FINEX Premium"),
                    subtitle = tr("premium_settings_desc", "বিজ্ঞাপনমুক্ত ও অ্যাডভান্সড ফিচার আনলক করুন"),
                    icon = Icons.Filled.WorkspacePremium,
                    onClick = { viewModel.navigateTo(Screen.PREMIUM) }
                )

                // Item 4: User Management removed
            }
        }

        // Group 2: Account Actions
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                // Item 5: Logout
                SettingsRowItem(
                    title = tr("logout_item", "লগআউট"),
                    subtitle = tr("logout_desc", "অ্যাকাউন্ট থেকে নিরাপদে প্রস্থান করুন"),
                    icon = Icons.Filled.ExitToApp,
                    iconColor = MaterialTheme.colorScheme.error,
                    onClick = { viewModel.logout() }
                )
            }
        }
    }

    // Dialogs definition
    if (showSelfEditDialog && currentUser != null) {
        val user = currentUser!!
        var selfName by remember { mutableStateOf(user.name) }
        var selfPin by remember { mutableStateOf("") }
        var selfError by remember { mutableStateOf("") }
        
        val pleaseEnterUsername = tr("please_enter_username", "Please enter your username.")
        val pleaseEnterPin = tr("please_enter_4_to_12_digit_pin", "Please enter a 4 to 12 digit PIN code.")
        val profileUpdateFailed = tr("profile_update_failed_error", "Profile update failed! Username might be taken.")
        
        Dialog(onDismissRequest = { showSelfEditDialog = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("edit_profile_dialog_title", "আমার প্রোফাইল সংশোধন"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = selfName,
                        onValueChange = { selfName = it },
                        label = { Text(tr("username_label", "ব্যবহারকারীর নাম")) },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Person, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = selfPin,
                        onValueChange = { if (it.length <= 12) selfPin = it },
                        label = { Text(tr("new_pin_label", "নতুন পিন কোড (পরিবর্তন না করতে চাইলে খালি রাখুন)")) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        visualTransformation = PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Filled.Lock, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (selfError.isNotEmpty()) {
                        Text(
                            text = selfError,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showSelfEditDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(tr("cancel", "বাতিল"))
                        }

                        Button(
                            onClick = {
                                val name = selfName.trim()
                                val pin = selfPin.trim()
                                if (name.isBlank()) {
                                    selfError = pleaseEnterUsername
                                } else if (pin.isNotEmpty() && (pin.length !in 4..12 || !pin.all { it.isDigit() })) {
                                    selfError = pleaseEnterPin
                                } else {
                                    val success = viewModel.updateSelfProfile(name, pin)
                                    if (success) {
                                        showSelfEditDialog = false
                                    } else {
                                        selfError = profileUpdateFailed
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text(tr("save", "সংরক্ষণ"))
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        Dialog(onDismissRequest = { showSettingsDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("settings_title", "Settings"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // Dark Mode Setting Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.toggleTheme() }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = tr("theme_setting", "Dark Mode"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tr("theme_setting_desc", "Toggle application dark theme"),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.toggleTheme() }
                        )
                    }

                    // Language Setting Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLanguageSelectionDialog = true }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Language,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = tr("language_setting", "Language"),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tr("language_setting_desc", "Change app language to English or Bangla"),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                        
                        // Active language badge
                        Box(
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(50.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (appLocale == "en") "English" else "বাংলা",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Button(
                        onClick = { showSettingsDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(tr("back", "Back"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showLanguageSelectionDialog) {
        Dialog(onDismissRequest = { showLanguageSelectionDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = tr("select_language", "Select Language"),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    // English Radio Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLocale("en")
                                showLanguageSelectionDialog = false
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr("english_lang", "English"),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        RadioButton(
                            selected = appLocale == "en",
                            onClick = {
                                viewModel.setAppLocale("en")
                                showLanguageSelectionDialog = false
                            }
                        )
                    }

                    // Bangla Radio Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setAppLocale("bn")
                                showLanguageSelectionDialog = false
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = tr("bangla_lang", "বাংলা"),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        RadioButton(
                            selected = appLocale == "bn",
                            onClick = {
                                viewModel.setAppLocale("bn")
                                showLanguageSelectionDialog = false
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showLanguageSelectionDialog = false }) {
                            Text(tr("cancel", "Cancel"))
                        }
                    }
                }
            }
        }
    }

    if (showSyncDialog) {
        CloudSyncDialog(
            viewModel = viewModel,
            onDismiss = { showSyncDialog = false }
        )
    }
}

@Composable
fun SettingsRowItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(iconColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(22.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(20.dp)
        )
    }
}
