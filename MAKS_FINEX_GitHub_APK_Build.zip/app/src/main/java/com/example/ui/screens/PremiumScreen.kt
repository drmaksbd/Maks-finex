package com.example.ui.screens

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.BillingConfig
import com.example.security.EntitlementState
import com.example.viewmodel.FinancialViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumScreen(
    viewModel: FinancialViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val entitlementState by viewModel.entitlementState.collectAsStateWithLifecycle()
    val productsForSale by viewModel.productsForSale.collectAsStateWithLifecycle()
    val billingError by viewModel.billingError.collectAsStateWithLifecycle()
    val isBillingReady by viewModel.isBillingReady.collectAsStateWithLifecycle()

    val isPremium = entitlementState == EntitlementState.PREMIUM
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hero Icon or Graphic
        Box(
            modifier = Modifier
                .size(90.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.secondary
                        )
                    ),
                    shape = RoundedCornerShape(28.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.WorkspacePremium,
                contentDescription = "Premium Icon",
                tint = Color.White,
                modifier = Modifier.size(52.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Title
        Text(
            text = "MAKS FINEX PREMIUM",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center,
            letterSpacing = 1.sp
        )

        Text(
            text = tr("premium_subtitle", "আপনার আর্থিক ব্যবস্থাপনাকে করুন আরও সহজ ও প্রফেশনাল"),
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Current Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isPremium) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                }
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = tr("current_status_label", "আপনার বর্তমান স্ট্যাটাস:"),
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Text(
                        text = if (isPremium) tr("status_premium", "প্রিমিয়াম গ্রাহক (Premium User)") else tr("status_free", "ফ্রি গ্রাহক (Free User)"),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPremium) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = if (isPremium) Icons.Filled.Verified else Icons.Filled.Info,
                    contentDescription = null,
                    tint = if (isPremium) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Premium Features List Title
        Text(
            text = tr("premium_benefits_title", "প্রিমিয়াম সুবিধার তালিকা:"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Feature Items
        PremiumFeatureRow(
            icon = Icons.Filled.Block,
            title = tr("feature_no_ads", "বিজ্ঞাপনমুক্ত চমৎকার অভিজ্ঞতা"),
            desc = tr("feature_no_ads_desc", "কোনো ব্যানার বা বিরক্তিজনক পপ-আপ অ্যাড থাকবে না।")
        )
        PremiumFeatureRow(
            icon = Icons.Filled.CloudSync,
            title = tr("feature_auto_sync", "স্বয়ংক্রিয় ক্লাউড ব্যাকআপ"),
            desc = tr("feature_auto_sync_desc", "প্রতিটি হিসাব সেভ করার সাথে সাথে অটো গুগল ড্রাইভে সিঙ্ক হবে।")
        )
        PremiumFeatureRow(
            icon = Icons.Filled.PictureAsPdf,
            title = tr("feature_reports", "উন্নত PDF ও Excel এক্সপোর্ট"),
            desc = tr("feature_reports_desc", "খতিয়ানের সম্পূর্ণ হিসাব চমৎকার প্রফেশনাল রিপোর্টে এক্সপোর্ট করুন।")
        )
        PremiumFeatureRow(
            icon = Icons.Filled.Layers,
            title = tr("feature_ledgers", "একাধিক ব্যবসায়িক খতিয়ান"),
            desc = tr("feature_ledgers_desc", "একই সাথে একাধিক ব্যবসা বা পারিবারিক ক্যাশবুক ম্যানেজ করুন।")
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Products Section
        Text(
            text = tr("premium_plans_title", "আপনার পছন্দের প্ল্যানটি বেছে নিন:"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (billingError != null) {
            val isUnavailable = billingError?.contains("unavailable", ignoreCase = true) == true
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isUnavailable) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.errorContainer
                ),
                border = if (isUnavailable) BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)) else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Text(
                    text = if (isUnavailable) "Notice: $billingError" else "Billing Notice: $billingError",
                    color = if (isUnavailable) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onErrorContainer,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
        }

        if (productsForSale.isEmpty()) {
            // Google Play Console integration status notice
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shop,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = tr("play_store_waiting_title", "গুগল প্লে স্টোর প্রোডাক্ট লোড হচ্ছে..."),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = tr("play_store_waiting_desc", "গুগল প্লে কনসোলে আপনার প্রোডাক্ট আইডিগুলো কনফিগার করা হলে এখানে স্বয়ংক্রিয়ভাবে প্ল্যানগুলো প্রদর্শিত হবে।\n\nপ্রয়োজনীয় প্রোডাক্ট আইডি খসড়া:\n• ${BillingConfig.PRODUCT_MONTHLY}\n• ${BillingConfig.PRODUCT_YEARLY}\n• ${BillingConfig.PRODUCT_LIFETIME}"),
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Display actual loaded products from Play Store
            productsForSale.forEach { product ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = product.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = product.description,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            Text(
                                text = product.price,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val activity = context as? Activity
                                if (activity != null) {
                                    viewModel.launchPurchaseFlow(activity, product.id) { result ->
                                        Log.d("PremiumScreen", "Purchase launch result: ${result.responseCode}")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = tr("buy_now_btn", "প্ল্যানটি চালু করুন"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Restore Purchases / Billing Troubleshooting
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = {
                    viewModel.refreshPurchases()
                }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SettingsBackupRestore, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tr("restore_purchases_btn", "রিস্টোর পারচেস (Restore)"),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun PremiumFeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}
