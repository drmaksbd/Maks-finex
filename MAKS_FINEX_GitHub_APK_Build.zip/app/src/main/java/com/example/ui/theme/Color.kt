package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette (Clean Blue-Indigo Theme Mapping)
val RoyalBluePrimary = Color(0xFF2563EB)      // Brand Primary (Modern Royal Blue)
val IndigoSecondary = Color(0xFF4F46E5)       // Brand Secondary (Indigo)
val OceanBlue = Color(0xFF0288D1)             // Muted Cyan/Teal Blue
val GoldAccent = Color(0xFFFFB300)            // Amber Gold Accent
val SlateBackground = Color(0xFFF8FAFC)        // Warm off-white
val CardBackgroundLight = Color(0xFFFFFFFF)    // Crisp white card background

// Legacy theme mappings for backward-compatibility with hardcoded references
val EmeraldPrimary = RoyalBluePrimary
val EmeraldSecondary = IndigoSecondary
val DeepTeal = OceanBlue

// Dark Theme Palette
val RoyalBluePrimaryDark = Color(0xFF60A5FA)  // Soft light blue
val IndigoSecondaryDark = Color(0xFF818CF8)   // Soft indigo
val OceanBlueDark = Color(0xFF4FC3F7)
val GoldAccentDark = Color(0xFFFFD54F)
val SlateBackgroundDark = Color(0xFF0F172A)    // Deep slate-900 background
val CardBackgroundDark = Color(0xFF1E293B)     // Sleek slate-800 card surface
val TextSecondaryDark = Color(0xFF94A3B8)

// Legacy dark theme mappings
val EmeraldPrimaryDark = RoyalBluePrimaryDark
val EmeraldSecondaryDark = IndigoSecondaryDark
val DeepTealDark = OceanBlueDark




