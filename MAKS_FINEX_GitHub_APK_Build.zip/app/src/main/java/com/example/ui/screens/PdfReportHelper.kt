package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.data.model.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfReportHelper {

    private fun formatPdfDate(time: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return sdf.format(Date(time))
    }

    private fun formatPdfTaka(amount: Double): String {
        return "৳ ${String.format("%,.2f", amount)}"
    }

    // Custom Document Adapter for direct printing on Android
    class FilePrintDocumentAdapter(private val file: File) : android.print.PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: android.os.CancellationSignal?,
            callback: LayoutResultCallback?,
            extras: android.os.Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onLayoutCancelled()
                return
            }
            val info = android.print.PrintDocumentInfo.Builder(file.name)
                .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(android.print.PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build()
            callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out android.print.PageRange>?,
            destination: android.os.ParcelFileDescriptor?,
            cancellationSignal: android.os.CancellationSignal?,
            callback: WriteResultCallback?
        ) {
            var input: FileInputStream? = null
            var output: FileOutputStream? = null
            try {
                input = FileInputStream(file)
                output = FileOutputStream(destination?.fileDescriptor)
                val buf = ByteArray(1024)
                var bytesRead: Int
                while (input.read(buf).also { bytesRead = it } > 0) {
                    output.write(buf, 0, bytesRead)
                }
                callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback?.onWriteFailed(e.toString())
            } finally {
                input?.close()
                output?.close()
            }
        }
    }

    // Launch direct system printing flow for the generated PDF
    fun printPdf(context: Context, file: File) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val printAdapter = FilePrintDocumentAdapter(file)
        printManager.print("MAKS FINEX Report", printAdapter, null)
    }

    // Open share sheet for the generated PDF
    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "আর্থিক রিপোর্ট শেয়ার করুন"))
    }

    // Main multi-page Canvas drawer helper class
    class PdfCanvasHelper(
        private val context: Context,
        private val document: PdfDocument,
        private val userName: String,
        private val reportTitle: String
    ) {
        var currentPage: PdfDocument.Page? = null
        var canvas: android.graphics.Canvas? = null
        var pageNum = 0
        var yPos = 80f

        val width = 595
        val height = 842

        // Setup Paints
        val titlePaint = Paint().apply {
            textSize = 18f
            isFakeBoldText = true
            color = 0xFF2E7D32.toInt() // Primary Emerald/Green Accent
        }

        val headerPaint = Paint().apply {
            textSize = 12f
            isFakeBoldText = true
            color = 0xFF212121.toInt()
        }

        val subHeaderPaint = Paint().apply {
            textSize = 10f
            color = 0xFF757575.toInt()
        }

        val textPaint = Paint().apply {
            textSize = 10f
            color = 0xFF212121.toInt()
        }

        val textBoldPaint = Paint().apply {
            textSize = 10f
            isFakeBoldText = true
            color = 0xFF212121.toInt()
        }

        val greenPaint = Paint().apply {
            textSize = 10f
            isFakeBoldText = true
            color = 0xFF2E7D32.toInt()
        }

        val redPaint = Paint().apply {
            textSize = 10f
            isFakeBoldText = true
            color = 0xFFC62828.toInt()
        }

        val linePaint = Paint().apply {
            color = 0xFFE0E0E0.toInt()
            strokeWidth = 1f
        }

        val bgPaint = Paint().apply {
            color = 0xFFF5F5F5.toInt()
            style = Paint.Style.FILL
        }

        val sectionHeaderPaint = Paint().apply {
            textSize = 13f
            isFakeBoldText = true
            color = 0xFF1565C0.toInt() // Blue shade for section headers
        }

        init {
            newPage()
        }

        fun newPage() {
            if (currentPage != null) {
                document.finishPage(currentPage)
            }
            pageNum++
            val pageInfo = PdfDocument.PageInfo.Builder(width, height, pageNum).create()
            currentPage = document.startPage(pageInfo)
            canvas = currentPage!!.canvas

            drawHeaderAndFooter()
            yPos = 100f
        }

        private fun drawHeaderAndFooter() {
            val cv = canvas ?: return
            // Header divider line
            cv.drawLine(30f, 40f, 565f, 40f, linePaint)

            // Header labels
            val hTitle = translateText("হিসাব নিকেশ - আর্থিক প্রতিবেদন", context)
            val hUser = translateText("ব্যবহারকারী: ", context) + userName + "  |  " + translateText("বিষয়: ", context) + translateText(reportTitle, context)
            cv.drawText(hTitle, 30f, 32f, titlePaint)
            cv.drawText(hUser, 30f, 55f, subHeaderPaint)

            // Footer divider line
            cv.drawLine(30f, 800f, 565f, 800f, linePaint)
            val pageStr = translateText("পৃষ্ঠা ", context) + pageNum
            cv.drawText(pageStr, 520f, 815f, subHeaderPaint)
            val timeStr = translateText("জেনারেট করার সময়: ", context) + SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
            cv.drawText(timeStr, 30f, 815f, subHeaderPaint)
        }

        fun ensureSpace(needed: Float) {
            if (yPos + needed > 780f) {
                newPage()
            }
        }

        fun drawSectionHeader(title: String) {
            ensureSpace(40f)
            val cv = canvas ?: return
            cv.drawRect(30f, yPos, 565f, yPos + 25f, bgPaint)
            cv.drawText(translateText(title, context), 35f, yPos + 17f, sectionHeaderPaint)
            cv.drawLine(30f, yPos + 25f, 565f, yPos + 25f, linePaint)
            yPos += 35f
        }

        fun drawSimpleCard(label: String, value: String, isGreen: Boolean = false, isRed: Boolean = false) {
            ensureSpace(24f)
            val cv = canvas ?: return
            cv.drawText(translateText(label, context), 35f, yPos + 15f, textPaint)
            val valPaint = when {
                isGreen -> greenPaint
                isRed -> redPaint
                else -> textBoldPaint
            }
            cv.drawText(translateText(value, context), 400f, yPos + 15f, valPaint)
            cv.drawLine(30f, yPos + 22f, 565f, yPos + 22f, linePaint)
            yPos += 22f
        }

        fun drawTableRow(
            cols: List<String>,
            weights: List<Float>,
            isHeader: Boolean = false,
            alignRightCols: Set<Int> = emptySet(),
            isIncome: Boolean = false,
            isExpense: Boolean = false
        ) {
            ensureSpace(24f)
            val cv = canvas ?: return

            val startX = 30f
            val totalWidth = 535f
            val totalWeight = weights.sum()

            if (isHeader) {
                cv.drawRect(startX, yPos, startX + totalWidth, yPos + 22f, bgPaint)
            }

            var currentX = startX
            cols.forEachIndexed { i, rawColText ->
                val colText = translateText(rawColText, context)
                val colWidth = (weights[i] / totalWeight) * totalWidth
                val paintToUse = when {
                    isHeader -> textBoldPaint
                    isIncome && i == cols.size - 1 -> greenPaint
                    isExpense && i == cols.size - 1 -> redPaint
                    else -> textPaint
                }

                val textX = if (alignRightCols.contains(i)) {
                    val textW = paintToUse.measureText(colText)
                    currentX + colWidth - textW - 5f
                } else {
                    currentX + 5f
                }

                // Text clipping to avoid column overflow
                val clippedText = if (paintToUse.measureText(colText) > colWidth - 8f) {
                    var tempText = colText
                    while (tempText.isNotEmpty() && paintToUse.measureText("$tempText...") > colWidth - 8f) {
                        tempText = tempText.dropLast(1)
                    }
                    if (tempText.isNotEmpty()) "$tempText..." else ""
                } else {
                    colText
                }

                cv.drawText(clippedText, textX, yPos + 15f, paintToUse)
                currentX += colWidth
            }

            cv.drawLine(startX, yPos + 22f, startX + totalWidth, yPos + 22f, linePaint)
            yPos += 22f
        }

        fun finish() {
            if (currentPage != null) {
                document.finishPage(currentPage)
                currentPage = null
            }
        }
    }

    // 1. Generate DAILY REPORT
    fun generateDailyReportPdf(context: Context, userName: String, transactions: List<Transaction>): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "দৈনিক লেনদেন রিপোর্ট")

        val todayCal = Calendar.getInstance()
        val todayTx = transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.date }
            cal.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) &&
                    cal.get(Calendar.DAY_OF_YEAR) == todayCal.get(Calendar.DAY_OF_YEAR)
        }

        helper.drawSectionHeader("দৈনিক সারাংশ (আজকের দিন)")
        val inc = todayTx.filter { it.type == "INCOME" }.sumOf { it.amount }
        val exp = todayTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val sav = todayTx.filter { it.type == "SAVINGS" }.sumOf { it.amount }
        val bal = inc - exp - sav

        helper.drawSimpleCard("মোট ইনকাম", formatPdfTaka(inc), isGreen = true)
        helper.drawSimpleCard("মোট খরচ", formatPdfTaka(exp), isRed = true)
        helper.drawSimpleCard("মোট সঞ্চয়", formatPdfTaka(sav))
        helper.drawSimpleCard("অবশিষ্ট ব্যালেন্স (নীট)", formatPdfTaka(bal), isGreen = bal >= 0, isRed = bal < 0)

        helper.yPos += 15f
        helper.drawSectionHeader("আজকের লেনদেনের বিবরণী (${todayTx.size} টি)")

        if (todayTx.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন লেনদেন রেকর্ড পাওয়া যায়নি।")
        } else {
            // Headers
            helper.drawTableRow(
                listOf("তারিখ", "বিবরণ", "ক্যাটাগরি", "ধরণ", "পরিমাণ"),
                listOf(1.2f, 2.3f, 1.5f, 1f, 1.5f),
                isHeader = true,
                alignRightCols = setOf(4)
            )

            todayTx.forEach { tx ->
                val typeStr = when (tx.type) {
                    "INCOME" -> "ইনকাম"
                    "EXPENSE" -> "খরচ"
                    "SAVINGS" -> "সঞ্চয়"
                    else -> tx.type
                }
                helper.drawTableRow(
                    listOf(formatPdfDate(tx.date), tx.description.ifBlank { "বিবরণহীন" }, tx.category, typeStr, formatPdfTaka(tx.amount)),
                    listOf(1.2f, 2.3f, 1.5f, 1f, 1.5f),
                    alignRightCols = setOf(4),
                    isIncome = tx.type == "INCOME",
                    isExpense = tx.type == "EXPENSE"
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "daily_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 2. Generate MONTHLY REPORT
    fun generateMonthlyReportPdf(context: Context, userName: String, transactions: List<Transaction>, monthIndex: Int, year: Int): File {
        val document = PdfDocument()
        val months = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
        val monthName = months[monthIndex]
        val helper = PdfCanvasHelper(context, document, userName, "মাসিক রিপোর্ট - $monthName $year")

        val monthlyTx = transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.date }
            cal.get(Calendar.YEAR) == year && cal.get(Calendar.MONTH) == monthIndex
        }

        helper.drawSectionHeader("মাসিক আর্থিক সারাংশ ($monthName $year)")
        val inc = monthlyTx.filter { it.type == "INCOME" }.sumOf { it.amount }
        val exp = monthlyTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val sav = monthlyTx.filter { it.type == "SAVINGS" }.sumOf { it.amount }
        val bal = inc - exp - sav

        helper.drawSimpleCard("মোট ইনকাম", formatPdfTaka(inc), isGreen = true)
        helper.drawSimpleCard("মোট খরচ", formatPdfTaka(exp), isRed = true)
        helper.drawSimpleCard("মোট সঞ্চয়", formatPdfTaka(sav))
        helper.drawSimpleCard("অবশিষ্ট ব্যালেন্স (নীট)", formatPdfTaka(bal), isGreen = bal >= 0, isRed = bal < 0)

        helper.yPos += 15f
        helper.drawSectionHeader("মাসিক লেনদেন বিবরণী (${monthlyTx.size} টি)")

        if (monthlyTx.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন লেনদেন রেকর্ড পাওয়া যায়নি।")
        } else {
            // Headers
            helper.drawTableRow(
                listOf("তারিখ", "বিবরণ", "ক্যাটাগরি", "ধরণ", "পরিমাণ"),
                listOf(1.2f, 2.3f, 1.5f, 1f, 1.5f),
                isHeader = true,
                alignRightCols = setOf(4)
            )

            monthlyTx.forEach { tx ->
                val typeStr = when (tx.type) {
                    "INCOME" -> "ইনকাম"
                    "EXPENSE" -> "খরচ"
                    "SAVINGS" -> "সঞ্চয়"
                    else -> tx.type
                }
                helper.drawTableRow(
                    listOf(formatPdfDate(tx.date), tx.description.ifBlank { "বিবরণহীন" }, tx.category, typeStr, formatPdfTaka(tx.amount)),
                    listOf(1.2f, 2.3f, 1.5f, 1f, 1.5f),
                    alignRightCols = setOf(4),
                    isIncome = tx.type == "INCOME",
                    isExpense = tx.type == "EXPENSE"
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "monthly_report_${monthIndex}_${year}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 3. Generate YEARLY REPORT
    fun generateYearlyReportPdf(context: Context, userName: String, transactions: List<Transaction>, year: Int): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "বাৎসরিক রিপোর্ট - $year")

        val yearlyTx = transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.date }
            cal.get(Calendar.YEAR) == year
        }

        helper.drawSectionHeader("বাৎসরিক আর্থিক সারাংশ ($year)")
        val inc = yearlyTx.filter { it.type == "INCOME" }.sumOf { it.amount }
        val exp = yearlyTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val sav = yearlyTx.filter { it.type == "SAVINGS" }.sumOf { it.amount }
        val bal = inc - exp - sav

        helper.drawSimpleCard("মোট ইনকাম", formatPdfTaka(inc), isGreen = true)
        helper.drawSimpleCard("মোট খরচ", formatPdfTaka(exp), isRed = true)
        helper.drawSimpleCard("মোট সঞ্চয়", formatPdfTaka(sav))
        helper.drawSimpleCard("অবশিষ্ট ব্যালেন্স (নীট)", formatPdfTaka(bal), isGreen = bal >= 0, isRed = bal < 0)

        // Group by month
        helper.yPos += 15f
        helper.drawSectionHeader("মাসভিত্তিক বাৎসরিক সারাংশ")

        helper.drawTableRow(
            listOf("মাস", "ইনকাম", "খরচ", "সঞ্চয়", "ব্যালেন্স"),
            listOf(1.5f, 1.5f, 1.5f, 1.5f, 1.5f),
            isHeader = true,
            alignRightCols = setOf(1, 2, 3, 4)
        )

        val months = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
        for (m in 0..11) {
            val mTx = yearlyTx.filter {
                val cal = Calendar.getInstance().apply { timeInMillis = it.date }
                cal.get(Calendar.MONTH) == m
            }
            if (mTx.isNotEmpty()) {
                val mInc = mTx.filter { it.type == "INCOME" }.sumOf { it.amount }
                val mExp = mTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                val mSav = mTx.filter { it.type == "SAVINGS" }.sumOf { it.amount }
                val mBal = mInc - mExp - mSav

                helper.drawTableRow(
                    listOf(months[m], formatPdfTaka(mInc), formatPdfTaka(mExp), formatPdfTaka(mSav), formatPdfTaka(mBal)),
                    listOf(1.5f, 1.5f, 1.5f, 1.5f, 1.5f),
                    alignRightCols = setOf(1, 2, 3, 4)
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "yearly_report_${year}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 4. Generate FIXED INVESTMENTS REPORT
    fun generateInvestmentsReportPdf(context: Context, userName: String, investments: List<FixedInvestment>): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "স্থায়ী বিনিয়োগ বিবরণী")

        helper.drawSectionHeader("বিনিয়োগের সংক্ষিপ্ত বিবরণী")
        val totalInv = investments.sumOf { it.amount }
        helper.drawSimpleCard("মোট বিনিয়োগের পরিমাণ", formatPdfTaka(totalInv), isGreen = true)

        helper.yPos += 15f
        helper.drawSectionHeader("স্থায়ী বিনিয়োগের বিস্তারিত তালিকা")

        if (investments.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন বিনিয়োগের তথ্য পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("ধরণ", "প্রতিষ্ঠানের নাম", "মুনাফার হার", "মেয়াদ", "পরিমাণ", "শুরুর তারিখ"),
                listOf(1.2f, 2f, 1f, 1f, 1.5f, 1.3f),
                isHeader = true,
                alignRightCols = setOf(4)
            )

            investments.forEach { inv ->
                val typeBangla = when (inv.type) {
                    "DPS" -> "ডিপিএস (DPS)"
                    "FDR" -> "এফডিআর (FDR)"
                    "Sanchayapatra" -> "সঞ্চয়পত্র"
                    else -> inv.type
                }
                helper.drawTableRow(
                    listOf(
                        typeBangla,
                        inv.institutionName,
                        "${inv.interestRate}%",
                        "${inv.durationMonths} মাস",
                        formatPdfTaka(inv.amount),
                        formatPdfDate(inv.startDate)
                    ),
                    listOf(1.2f, 2f, 1f, 1f, 1.5f, 1.3f),
                    alignRightCols = setOf(4)
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "investments_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 5a. Generate PERSON DEBTS REPORT
    fun generatePersonDebtsReportPdf(context: Context, userName: String, personName: String, personDebts: List<Debt>): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "ঋণ বিবরণী - $personName")

        val lent = personDebts.filter { it.type == "LENT" }
        val repayLent = personDebts.filter { it.type == "REPAY_LENT" }
        val borrowed = personDebts.filter { it.type == "BORROWED" }
        val repayBorrowed = personDebts.filter { it.type == "REPAY_BORROWED" }

        val totalLent = lent.sumOf { it.amount }
        val totalRepayLent = repayLent.sumOf { it.amount }
        val totalBorrowed = borrowed.sumOf { it.amount }
        val totalRepayBorrowed = repayBorrowed.sumOf { it.amount }

        val netLent = totalLent - totalRepayLent
        val netBorrowed = totalBorrowed - totalRepayBorrowed

        helper.drawSectionHeader("$personName - এর হিসাবের সংক্ষিপ্ত রূপ")

        if (totalLent > 0) {
            helper.drawSimpleCard("মোট ঋণ দেওয়া (পাওনা)", formatPdfTaka(totalLent), isGreen = true)
            helper.drawSimpleCard("মোট আদায়কৃত (ফেরত পাওয়া)", formatPdfTaka(totalRepayLent), isGreen = true)
            helper.drawSimpleCard("অবশিষ্ট পাওনা", formatPdfTaka(maxOf(0.0, netLent)), isGreen = netLent > 0)
        }

        if (totalBorrowed > 0) {
            if (totalLent > 0) {
                helper.yPos += 10f
            }
            helper.drawSimpleCard("মোট ঋণ নেওয়া (দেনা)", formatPdfTaka(totalBorrowed), isRed = true)
            helper.drawSimpleCard("মোট পরিশোধকৃত (দেনা শোধ)", formatPdfTaka(totalRepayBorrowed), isRed = true)
            helper.drawSimpleCard("অবশিষ্ট দেনা", formatPdfTaka(maxOf(0.0, netBorrowed)), isRed = netBorrowed > 0)
        }

        val finalNet = netLent - netBorrowed
        helper.yPos += 15f
        if (finalNet > 0) {
            helper.drawSimpleCard("চূড়ান্ত স্থিতি (আপনি পাবেন)", formatPdfTaka(finalNet), isGreen = true)
        } else if (finalNet < 0) {
            helper.drawSimpleCard("চূড়ান্ত স্থিতি (আপনি দেবেন)", formatPdfTaka(-finalNet), isRed = true)
        } else {
            helper.drawSimpleCard("চূড়ান্ত স্থিতি", "পরিশোধিত / সমান", isGreen = true)
        }

        helper.yPos += 15f
        helper.drawSectionHeader("লেনদেনের বিস্তারিত খতিয়ান")

        if (personDebts.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন লেনদেনের রেকর্ড পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("তারিখ", "ধরণ", "পরিমাণ", "বিবরণ"),
                listOf(1.5f, 2f, 1.5f, 3.5f),
                isHeader = true,
                alignRightCols = setOf(2)
            )

            personDebts.sortedBy { it.date }.forEach { debt ->
                val typeBangla = when (debt.type) {
                    "LENT" -> "ঋণ দেওয়া হয়েছে"
                    "REPAY_LENT" -> "ঋণ আদায় হয়েছে"
                    "BORROWED" -> "ঋণ নেওয়া হয়েছে"
                    "REPAY_BORROWED" -> "ঋণ শোধ করা হয়েছে"
                    else -> debt.type
                }

                val isIncome = debt.type == "LENT" || debt.type == "REPAY_BORROWED"
                val isExpense = debt.type == "BORROWED" || debt.type == "REPAY_LENT"

                helper.drawTableRow(
                    listOf(
                        formatPdfDate(debt.date),
                        typeBangla,
                        formatPdfTaka(debt.amount),
                        debt.description
                    ),
                    listOf(1.5f, 2f, 1.5f, 3.5f),
                    alignRightCols = setOf(2),
                    isIncome = isIncome,
                    isExpense = isExpense
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "debt_statement_${personName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf")
        val fos = FileOutputStream(file)
        document.writeTo(fos)
        fos.close()
        document.close()
        return file
    }

    // 5. Generate DEBTS REPORT
    fun generateDebtsReportPdf(context: Context, userName: String, debts: List<Debt>): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "ঋণ ট্র্যাকার রিপোর্ট")

        val lent = debts.filter { it.type == "LENT" }
        val borrowed = debts.filter { it.type == "BORROWED" }

        val totalLent = lent.sumOf { it.amount }
        val totalBorrowed = borrowed.sumOf { it.amount }
        val netDebt = totalLent - totalBorrowed

        helper.drawSectionHeader("ঋণের সংক্ষিপ্ত বিবরণী")
        helper.drawSimpleCard("মোট ঋণ দেওয়া (পাওনা)", formatPdfTaka(totalLent), isGreen = true)
        helper.drawSimpleCard("মোট ঋণ নেওয়া (দেনা)", formatPdfTaka(totalBorrowed), isRed = true)
        helper.drawSimpleCard("নীট ঋণের স্থিতি", formatPdfTaka(netDebt), isGreen = netDebt >= 0, isRed = netDebt < 0)

        helper.yPos += 15f
        helper.drawSectionHeader("ঋণের বিস্তারিত তালিকা")

        if (debts.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন ঋণের রেকর্ড পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("ধরণ", "ব্যক্তির নাম", "পরিমাণ", "তারিখ", "পরিশোধের দিন", "অবস্থা"),
                listOf(1.2f, 2f, 1.5f, 1.3f, 1.3f, 1.2f),
                isHeader = true,
                alignRightCols = setOf(2)
            )

            debts.forEach { debt ->
                val typeBangla = if (debt.type == "LENT") "প্রদত্ত ঋণ" else "গৃহীত ঋণ"
                val statusBangla = if (debt.isSettled) "পরিশোধিত" else "অপরিশোধিত"
                val dueDateStr = if (debt.dueDate > 0) formatPdfDate(debt.dueDate) else "নেই"

                helper.drawTableRow(
                    listOf(
                        typeBangla,
                        debt.personName,
                        formatPdfTaka(debt.amount),
                        formatPdfDate(debt.date),
                        dueDateStr,
                        statusBangla
                    ),
                    listOf(1.2f, 2f, 1.5f, 1.3f, 1.3f, 1.2f),
                    alignRightCols = setOf(2),
                    isIncome = debt.type == "LENT",
                    isExpense = debt.type == "BORROWED" && !debt.isSettled
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "debts_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 6. Generate ASSETS REPORT
    fun generateAssetsReportPdf(context: Context, userName: String, assets: List<Asset>): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "সম্পদ খাতা রিপোর্ট")

        helper.drawSectionHeader("সম্পদের সংক্ষিপ্ত বিবরণী")
        val totalAssets = assets.sumOf { it.value }
        helper.drawSimpleCard("মোট সম্পদের মূল্যমান", formatPdfTaka(totalAssets), isGreen = true)

        helper.yPos += 15f
        helper.drawSectionHeader("সম্পদের বিস্তারিত তালিকা")

        if (assets.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন সম্পদের তথ্য পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("সম্পদের নাম", "ক্যাটাগরি", "মূল্যমান", "তারিখ", "বিবরণ"),
                listOf(2f, 1.5f, 1.5f, 1.3f, 2.2f),
                isHeader = true,
                alignRightCols = setOf(2)
            )

            assets.forEach { asset ->
                val catBangla = when (asset.category) {
                    "Property" -> "জমি/বাড়ি"
                    "Gold" -> "স্বর্ণ/রৌপ্য"
                    "Savings" -> "ব্যাংক জমা"
                    "Business" -> "ব্যবসা"
                    else -> "অন্যান্য"
                }

                helper.drawTableRow(
                    listOf(
                        asset.name,
                        catBangla,
                        formatPdfTaka(asset.value),
                        formatPdfDate(asset.date),
                        asset.description.ifBlank { "নেই" }
                    ),
                    listOf(2f, 1.5f, 1.5f, 1.3f, 2.2f),
                    alignRightCols = setOf(2)
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "assets_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 7. Generate ZAKAT REPORT
    fun generateZakatReportPdf(context: Context, userName: String, zakatRecords: List<ZakatRecord>, activeProfile: ZakatProfile?): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "যাকাত হিসাব রিপোর্ট")

        helper.drawSectionHeader("সরাসরি যাকাত হিসাব (চলতি হিসাব)")
        if (activeProfile == null) {
            helper.drawSimpleCard("তথ্য", "কোন চলমান যাকাত প্রোফাইল তথ্য পাওয়া যায়নি।")
        } else {
            val goldVal = activeProfile.goldWeightBhori * activeProfile.goldPricePerBhori
            val silverVal = activeProfile.silverWeightBhori * activeProfile.silverPricePerBhori
            val totalWealth = goldVal + silverVal + activeProfile.cashInHandBank + activeProfile.businessGoodsValue + activeProfile.otherInvestments
            val netWealth = totalWealth - activeProfile.debtsOwed
            val isEligible = netWealth >= (59500.0) // approx Nisab threshold in Taka (rough silver basis, can vary, we just print the amount)
            val zakatAmt = if (netWealth > 0) netWealth * 0.025 else 0.0

            helper.drawSimpleCard("স্বর্ণের মূল্য", formatPdfTaka(goldVal))
            helper.drawSimpleCard("রৌপ্যের মূল্য", formatPdfTaka(silverVal))
            helper.drawSimpleCard("নগদ ও ব্যাংক জমা", formatPdfTaka(activeProfile.cashInHandBank))
            helper.drawSimpleCard("ব্যবসায়িক পণ্য মূল্য", formatPdfTaka(activeProfile.businessGoodsValue))
            helper.drawSimpleCard("ডিপিএস/এফডিআর/অন্যান্য", formatPdfTaka(activeProfile.otherInvestments))
            helper.drawSimpleCard("ব্যক্তিগত ঋণ/অন্যান্য দেনা", "(-) " + formatPdfTaka(activeProfile.debtsOwed), isRed = true)
            helper.drawSimpleCard("যাকাতযোগ্য নীট সম্পদ", formatPdfTaka(netWealth), isGreen = netWealth >= 0)
            helper.drawSimpleCard("প্রদেয় যাকাত (২.৫%)", formatPdfTaka(zakatAmt), isGreen = zakatAmt > 0)

            // Dynamic itemized lists
            val details = ZakatJsonParser.fromJson(activeProfile.detailsJson)
            
            if (details.goldEntries.isNotEmpty() && details.goldEntries.any { it.quantity > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("স্বর্ণের বিস্তারিত বিবরণী")
                helper.drawTableRow(
                    listOf("ক্যারেট/ধরণ", "পরিমাণ", "ভরি প্রতি মূল্য", "মোট মূল্য"),
                    listOf(1.5f, 1.2f, 1.5f, 1.8f),
                    isHeader = true,
                    alignRightCols = setOf(1, 2, 3)
                )
                details.goldEntries.filter { it.quantity > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.extra.ifBlank { "স্বর্ণ" }, entry.quantity.toString() + " ভরি", formatPdfTaka(entry.pricePerUnit), formatPdfTaka(entry.value)),
                        listOf(1.5f, 1.2f, 1.5f, 1.8f),
                        alignRightCols = setOf(1, 2, 3)
                    )
                }
            }

            if (details.silverEntries.isNotEmpty() && details.silverEntries.any { it.quantity > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("রৌপ্যের বিস্তারিত বিবরণী")
                helper.drawTableRow(
                    listOf("ধরণ", "পরিমাণ", "ভরি প্রতি মূল্য", "মোট মূল্য"),
                    listOf(1.5f, 1.2f, 1.5f, 1.8f),
                    isHeader = true,
                    alignRightCols = setOf(1, 2, 3)
                )
                details.silverEntries.filter { it.quantity > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.extra.ifBlank { "রৌপ্য" }, entry.quantity.toString() + " ভরি", formatPdfTaka(entry.pricePerUnit), formatPdfTaka(entry.value)),
                        listOf(1.5f, 1.2f, 1.5f, 1.8f),
                        alignRightCols = setOf(1, 2, 3)
                    )
                }
            }

            if (details.cashEntries.isNotEmpty() && details.cashEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("নগদ ও ব্যাংক জমার বিবরণী")
                helper.drawTableRow(
                    listOf("উৎস/ব্যাংকের নাম", "জমার পরিমাণ"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.cashEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ব্যাংক জমা" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.businessEntries.isNotEmpty() && details.businessEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("ব্যবসায়িক সম্পদের বিবরণী")
                helper.drawTableRow(
                    listOf("পণ্যের বিবরণ", "বর্তমান বাজারমূল্য"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.businessEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ব্যবসায়িক পণ্য" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.otherEntries.isNotEmpty() && details.otherEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("অন্যান্য ডিপিএস/বিনিয়োগের বিবরণী")
                helper.drawTableRow(
                    listOf("ক্ষেত্র/ডেসক্রিপশন", "বর্তমান মূল্য"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.otherEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ডিপিএস/বিনিয়োগ" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.debtEntries.isNotEmpty() && details.debtEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("ঋণ ও দেনা সমূহের বিবরণী")
                helper.drawTableRow(
                    listOf("ঋণদাতা/বিবরণ", "পরিশোধযোগ্য দেনা"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.debtEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "দেনা" }, "(-) " + formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }
        }

        helper.yPos += 15f
        helper.drawSectionHeader("সংরক্ষিত যাকাত প্রদানের ইতিহাস")

        if (zakatRecords.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "পূর্বে সংরক্ষিত যাকাত প্রদানের কোন রেকর্ড পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("বছর", "ব্যক্তির নাম", "যাকাতযোগ্য সম্পদ", "যাকাত পরিমাণ", "তারিখ"),
                listOf(1f, 2f, 1.8f, 1.5f, 1.3f),
                isHeader = true,
                alignRightCols = setOf(2, 3)
            )

            zakatRecords.forEach { rec ->
                val goldVal = rec.goldWeightBhori * rec.goldPricePerBhori
                val silverVal = rec.silverWeightBhori * rec.silverPricePerBhori
                val totalWealth = goldVal + silverVal + rec.cashInHandBank + rec.businessGoodsValue + rec.otherInvestments
                val netWealth = totalWealth - rec.debtsOwed

                helper.drawTableRow(
                    listOf(
                        rec.year,
                        rec.personName,
                        formatPdfTaka(netWealth),
                        formatPdfTaka(rec.totalZakatAmount),
                        formatPdfDate(rec.date)
                    ),
                    listOf(1f, 2f, 1.8f, 1.5f, 1.3f),
                    alignRightCols = setOf(2, 3)
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "zakat_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 8. Generate COMBINED REPORT (All sections)
    fun generateCombinedReportPdf(
        context: Context,
        userName: String,
        transactions: List<Transaction>,
        selectedMonthIndex: Int,
        selectedYear: Int,
        investments: List<FixedInvestment>,
        debts: List<Debt>,
        assets: List<Asset>,
        zakatRecords: List<ZakatRecord>,
        activeZakatProfile: ZakatProfile?
    ): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "পূর্ণাঙ্গ আর্থিক সারসংক্ষেপ (Combined Report)")

        // --- PAGE 1: INTRODUCTION & TX SUMMARY ---
        helper.drawSectionHeader("১. সামগ্রিক হিসাব বিবরণী (লেনদেন ও বাজেট)")
        val months = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
        val monthName = months[selectedMonthIndex]

        val monthlyTx = transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.date }
            cal.get(Calendar.YEAR) == selectedYear && cal.get(Calendar.MONTH) == selectedMonthIndex
        }

        val inc = monthlyTx.filter { it.type == "INCOME" }.sumOf { it.amount }
        val exp = monthlyTx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val sav = monthlyTx.filter { it.type == "SAVINGS" }.sumOf { it.amount }
        val bal = inc - exp - sav

        helper.drawSimpleCard("প্রতিবেদনের মাস", "$monthName $selectedYear")
        helper.drawSimpleCard("মোট ইনকাম (চলতি মাস)", formatPdfTaka(inc), isGreen = true)
        helper.drawSimpleCard("মোট খরচ (চলতি মাস)", formatPdfTaka(exp), isRed = true)
        helper.drawSimpleCard("মোট সঞ্চয় (চলতি মাস)", formatPdfTaka(sav))
        helper.drawSimpleCard("নীট ব্যালেন্স", formatPdfTaka(bal), isGreen = bal >= 0, isRed = bal < 0)

        // --- PAGE 2: FIXED INVESTMENTS ---
        helper.newPage()
        helper.drawSectionHeader("২. স্থায়ী বিনিয়োগ বিবরণী (DPS / FDR)")
        val totalInv = investments.sumOf { it.amount }
        helper.drawSimpleCard("মোট সঞ্চিত বিনিয়োগের পরিমাণ", formatPdfTaka(totalInv), isGreen = true)

        if (investments.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন বিনিয়োগের তথ্য পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("ধরণ", "প্রতিষ্ঠানের নাম", "মুনাফা হার", "মেয়াদ", "মূল্যমান"),
                listOf(1.2f, 2f, 1f, 1f, 1.5f),
                isHeader = true,
                alignRightCols = setOf(4)
            )
            investments.take(15).forEach { inv ->
                val typeBangla = when (inv.type) {
                    "DPS" -> "ডিপিএস"
                    "FDR" -> "এফডিআর"
                    "Sanchayapatra" -> "সঞ্চয়পত্র"
                    else -> inv.type
                }
                helper.drawTableRow(
                    listOf(typeBangla, inv.institutionName, "${inv.interestRate}%", "${inv.durationMonths} মাস", formatPdfTaka(inv.amount)),
                    listOf(1.2f, 2f, 1f, 1f, 1.5f),
                    alignRightCols = setOf(4)
                )
            }
        }

        // --- PAGE 3: DEBT TRACKER ---
        helper.newPage()
        helper.drawSectionHeader("৩. ঋণ বিবরণী (পাওনা ও দেনা)")
        val lent = debts.filter { it.type == "LENT" }
        val borrowed = debts.filter { it.type == "BORROWED" }
        val totalLent = lent.sumOf { it.amount }
        val totalBorrowed = borrowed.sumOf { it.amount }
        val netDebt = totalLent - totalBorrowed

        helper.drawSimpleCard("প্রদত্ত মোট ঋণ (অন্যের কাছে পাওনা)", formatPdfTaka(totalLent), isGreen = true)
        helper.drawSimpleCard("গৃহীত মোট ঋণ (অন্যের কাছে দেনা)", formatPdfTaka(totalBorrowed), isRed = true)
        helper.drawSimpleCard("নীট পাওনা / দেনার স্থিতি", formatPdfTaka(netDebt), isGreen = netDebt >= 0, isRed = netDebt < 0)

        if (debts.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন ঋণের রেকর্ড পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("ধরণ", "ব্যক্তির নাম", "ঋণ পরিমাণ", "অবস্থা"),
                listOf(1.5f, 2f, 1.5f, 1.2f),
                isHeader = true,
                alignRightCols = setOf(2)
            )
            debts.take(15).forEach { debt ->
                val typeBangla = if (debt.type == "LENT") "প্রদত্ত ঋণ" else "গৃহীত ঋণ"
                val statusBangla = if (debt.isSettled) "পরিশোধিত" else "অপরিশোধিত"
                helper.drawTableRow(
                    listOf(typeBangla, debt.personName, formatPdfTaka(debt.amount), statusBangla),
                    listOf(1.5f, 2f, 1.5f, 1.2f),
                    alignRightCols = setOf(2)
                )
            }
        }

        // --- PAGE 4: ASSET LIST ---
        helper.newPage()
        helper.drawSectionHeader("৪. সম্পদ খাতা (স্থাবর ও অস্থাবর সম্পদ)")
        val totalAssets = assets.sumOf { it.value }
        helper.drawSimpleCard("মোট সম্পদের প্রাক্কলিত মূল্য", formatPdfTaka(totalAssets), isGreen = true)

        if (assets.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোন সম্পদের তথ্য পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("সম্পদের নাম", "ক্যাটাগরি", "মূল্যমান", "তারিখ"),
                listOf(2.5f, 1.8f, 1.5f, 1.3f),
                isHeader = true,
                alignRightCols = setOf(2)
            )
            assets.take(15).forEach { asset ->
                val catBangla = when (asset.category) {
                    "Property" -> "জমি/বাড়ি"
                    "Gold" -> "স্বর্ণ/রৌপ্য"
                    "Savings" -> "ব্যাংক জমা"
                    "Business" -> "ব্যবসা"
                    else -> "অন্যান্য"
                }
                helper.drawTableRow(
                    listOf(asset.name, catBangla, formatPdfTaka(asset.value), formatPdfDate(asset.date)),
                    listOf(2.5f, 1.8f, 1.5f, 1.3f),
                    alignRightCols = setOf(2)
                )
            }
        }

        // --- PAGE 5: ZAKAT ACCOUNTING ---
        helper.newPage()
        helper.drawSectionHeader("৫. যাকাত হিসাব বিবরণী")
        if (activeZakatProfile == null) {
            helper.drawSimpleCard("তথ্য", "কোন চলমান যাকাত প্রোফাইল তথ্য পাওয়া যায়নি।")
        } else {
            val goldVal = activeZakatProfile.goldWeightBhori * activeZakatProfile.goldPricePerBhori
            val silverVal = activeZakatProfile.silverWeightBhori * activeZakatProfile.silverPricePerBhori
            val netWealth = (goldVal + silverVal + activeZakatProfile.cashInHandBank + activeZakatProfile.businessGoodsValue + activeZakatProfile.otherInvestments) - activeZakatProfile.debtsOwed
            val zakatAmt = if (netWealth > 0) netWealth * 0.025 else 0.0

            helper.drawSimpleCard("স্বর্ণের মূল্য", formatPdfTaka(goldVal))
            helper.drawSimpleCard("রৌপ্যের মূল্য", formatPdfTaka(silverVal))
            helper.drawSimpleCard("নগদ ও ব্যাংক জমা", formatPdfTaka(activeZakatProfile.cashInHandBank))
            helper.drawSimpleCard("ব্যবসায়িক পণ্য মূল্য", formatPdfTaka(activeZakatProfile.businessGoodsValue))
            helper.drawSimpleCard("ডিপিএস/এফডিআর/অন্যান্য", formatPdfTaka(activeZakatProfile.otherInvestments))
            helper.drawSimpleCard("ঋণ ও দেনা সমূহ", "(-) " + formatPdfTaka(activeZakatProfile.debtsOwed), isRed = true)
            helper.drawSimpleCard("যাকাতযোগ্য নীট সম্পদ", formatPdfTaka(netWealth), isGreen = netWealth >= 0)
            helper.drawSimpleCard("প্রদেয় যাকাত (২.৫%)", formatPdfTaka(zakatAmt), isGreen = zakatAmt > 0)

            // Dynamic itemized lists in Combined report too
            val details = ZakatJsonParser.fromJson(activeZakatProfile.detailsJson)
            
            if (details.goldEntries.isNotEmpty() && details.goldEntries.any { it.quantity > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("স্বর্ণের বিস্তারিত বিবরণী")
                helper.drawTableRow(
                    listOf("ক্যারেট/ধরণ", "পরিমাণ", "ভরি প্রতি মূল্য", "মোট মূল্য"),
                    listOf(1.5f, 1.2f, 1.5f, 1.8f),
                    isHeader = true,
                    alignRightCols = setOf(1, 2, 3)
                )
                details.goldEntries.filter { it.quantity > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.extra.ifBlank { "স্বর্ণ" }, entry.quantity.toString() + " ভরি", formatPdfTaka(entry.pricePerUnit), formatPdfTaka(entry.value)),
                        listOf(1.5f, 1.2f, 1.5f, 1.8f),
                        alignRightCols = setOf(1, 2, 3)
                    )
                }
            }

            if (details.silverEntries.isNotEmpty() && details.silverEntries.any { it.quantity > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("রৌপ্যের বিস্তারিত বিবরণী")
                helper.drawTableRow(
                    listOf("ধরণ", "পরিমাণ", "ভরি প্রতি মূল্য", "মোট মূল্য"),
                    listOf(1.5f, 1.2f, 1.5f, 1.8f),
                    isHeader = true,
                    alignRightCols = setOf(1, 2, 3)
                )
                details.silverEntries.filter { it.quantity > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.extra.ifBlank { "রৌপ্য" }, entry.quantity.toString() + " ভরি", formatPdfTaka(entry.pricePerUnit), formatPdfTaka(entry.value)),
                        listOf(1.5f, 1.2f, 1.5f, 1.8f),
                        alignRightCols = setOf(1, 2, 3)
                    )
                }
            }

            if (details.cashEntries.isNotEmpty() && details.cashEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("নগদ ও ব্যাংক জমার বিবরণী")
                helper.drawTableRow(
                    listOf("উৎস/ব্যাংকের নাম", "জমার পরিমাণ"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.cashEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ব্যাংক জমা" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.businessEntries.isNotEmpty() && details.businessEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("ব্যবসায়িক সম্পদের বিবরণী")
                helper.drawTableRow(
                    listOf("পণ্যের বিবরণ", "বর্তমান বাজারমূল্য"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.businessEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ব্যবসায়িক পণ্য" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.otherEntries.isNotEmpty() && details.otherEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("অন্যান্য ডিপিএস/বিনিয়োগের বিবরণী")
                helper.drawTableRow(
                    listOf("ক্ষেত্র/ডেসক্রিপশন", "বর্তমান মূল্য"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.otherEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "ডিপিএস/বিনিয়োগ" }, formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }

            if (details.debtEntries.isNotEmpty() && details.debtEntries.any { it.value > 0 }) {
                helper.ensureSpace(60f)
                helper.yPos += 15f
                helper.drawSectionHeader("ঋণ ও দেনা সমূহের বিবরণী")
                helper.drawTableRow(
                    listOf("ঋণদাতা/বিবরণ", "পরিশোধযোগ্য দেনা"),
                    listOf(3f, 2f),
                    isHeader = true,
                    alignRightCols = setOf(1)
                )
                details.debtEntries.filter { it.value > 0 }.forEach { entry ->
                    helper.drawTableRow(
                        listOf(entry.name.ifBlank { "দেনা" }, "(-) " + formatPdfTaka(entry.value)),
                        listOf(3f, 2f),
                        alignRightCols = setOf(1)
                    )
                }
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "combined_financial_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }

    // 8. Generate BUSINESS REPORT
    fun generateBusinessReportPdf(
        context: Context,
        userName: String,
        categories: List<BusinessCategory>,
        items: List<BusinessItem>
    ): File {
        val document = PdfDocument()
        val helper = PdfCanvasHelper(context, document, userName, "ব্যবসায়িক হিসেব নিকেশ রিপোর্ট")

        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        val thisMonthSales = items.filter { item ->
            if (item.isSold && item.saleDate != null) {
                val cal = Calendar.getInstance().apply { timeInMillis = item.saleDate }
                cal.get(Calendar.MONTH) == currentMonth && cal.get(Calendar.YEAR) == currentYear
            } else {
                false
            }
        }

        val totalSoldQty = thisMonthSales.size
        val totalProfit = thisMonthSales.sumOf { it.profit }

        // Top Summary Cards
        helper.drawSectionHeader("চলতি মাসের ব্যবসায়িক সারাংশ (বিক্রয় ও লাভ)")
        helper.drawSimpleCard("চলতি মাসে মোট বিক্রিত আইটেম", "$totalSoldQty টি", isGreen = true)
        helper.drawSimpleCard("চলতি মাসে মোট অর্জিত লাভ", formatPdfTaka(totalProfit), isGreen = totalProfit >= 0, isRed = totalProfit < 0)

        helper.yPos += 15f
        helper.drawSectionHeader("ক্যাটাগরি-ভিত্তিক স্টক ও বিক্রয় বিবরণী")

        // Draw Table headers
        helper.drawTableRow(
            listOf("ক্যাটাগরি", "মোট আইটেম", "অবশিষ্ট স্টক", "চলতি মাসে বিক্রয়", "চলতি মাসে লাভ"),
            listOf(2.2f, 1.2f, 1.2f, 1.5f, 1.5f),
            isHeader = true,
            alignRightCols = setOf(1, 2, 3, 4)
        )

        categories.forEach { category ->
            val catItems = items.filter { it.categoryId == category.id }
            val stockCount = catItems.count { !it.isSold }
            val catThisMonthSales = catItems.filter { item ->
                if (item.isSold && item.saleDate != null) {
                    val cal = Calendar.getInstance().apply { timeInMillis = item.saleDate }
                    cal.get(Calendar.MONTH) == currentMonth && cal.get(Calendar.YEAR) == currentYear
                } else {
                    false
                }
            }
            val catSoldQty = catThisMonthSales.size
            val catProfit = catThisMonthSales.sumOf { it.profit }

            helper.drawTableRow(
                listOf(
                    category.name,
                    "${catItems.size} টি",
                    "${stockCount} টি",
                    "${catSoldQty} টি",
                    formatPdfTaka(catProfit)
                ),
                listOf(2.2f, 1.2f, 1.2f, 1.5f, 1.5f),
                alignRightCols = setOf(1, 2, 3, 4)
            )
        }

        // Draw all active items detail
        helper.yPos += 20f
        helper.drawSectionHeader("আইটেম স্টক ও বিক্রয়ের বিস্তারিত তালিকা")

        if (items.isEmpty()) {
            helper.drawSimpleCard("তথ্য", "কোনো আইটেমের তথ্য পাওয়া যায়নি।")
        } else {
            helper.drawTableRow(
                listOf("সিরিয়াল আইডি", "আইটেম নাম", "ক্যাটাগরি", "ক্রয় মূল্য", "বিক্রয় মূল্য", "লাভ", "অবস্থা"),
                listOf(1f, 1.8f, 1.2f, 1.1f, 1.1f, 1.1f, 1.1f),
                isHeader = true,
                alignRightCols = setOf(3, 4, 5)
            )

            items.sortedBy { it.id }.forEach { item ->
                val categoryName = categories.firstOrNull { it.id == item.categoryId }?.name ?: "অজানা"
                val statusStr = if (item.isSold) "বিক্রিত" else "স্টকে আছে"
                val profitStr = if (item.isSold) formatPdfTaka(item.profit) else "-"

                helper.drawTableRow(
                    listOf(
                        "#${item.id}",
                        item.name,
                        categoryName,
                        formatPdfTaka(item.purchasePrice),
                        formatPdfTaka(item.salePrice),
                        profitStr,
                        statusStr
                    ),
                    listOf(1f, 1.8f, 1.2f, 1.1f, 1.1f, 1.1f, 1.1f),
                    alignRightCols = setOf(3, 4, 5),
                    isIncome = !item.isSold
                )
            }
        }

        helper.finish()
        val file = File(context.cacheDir, "business_ledger_report_${System.currentTimeMillis()}.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        return file
    }
}
