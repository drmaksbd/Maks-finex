package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.FinancialRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.data.api.CloudSyncHelper
import com.example.data.api.GoogleDriveSyncHelper
import com.example.data.api.GlobalUserRegistryItem
import com.example.data.api.GlobalUserSyncHelper
import com.google.firebase.auth.FirebaseAuth
import android.content.Intent
import java.io.IOException
import java.io.File
import kotlinx.coroutines.flow.first
import java.util.Calendar

enum class Screen {
    LOGIN,
    DASHBOARD,
    DAILY_TRANSACTIONS,
    INVESTMENTS,
    DEBTS,
    ASSETS,
    ZAKAT,
    REPORTS,
    BUSINESS_LEDGER,
    SETTINGS,
    MORE,
    PREMIUM
}

data class AppUser(
    val name: String,
    val pin: String,
    val isMaster: Boolean = false
)

class FinancialViewModel(
    application: Application,
    private val repository: FinancialRepository
) : AndroidViewModel(application) {

    // --- NAVIGATION AND AUTH STATE ---
    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenHistory = mutableListOf<Screen>()

    private val _showTrialWarningDialog = MutableStateFlow(false)
    val showTrialWarningDialog: StateFlow<Boolean> = _showTrialWarningDialog.asStateFlow()

    fun dismissTrialWarningDialog() {
        _showTrialWarningDialog.value = false
    }

    fun triggerTrialWarningDialog() {
        _showTrialWarningDialog.value = true
    }

    val sharedPrefs = application.getSharedPreferences("HisebNikeshPrefs", Context.MODE_PRIVATE)

    // --- LANGUAGE/LOCALE STATE ---
    private val _appLocale = MutableStateFlow(sharedPrefs.getString("app_locale", "en") ?: "en")
    val appLocale: StateFlow<String> = _appLocale.asStateFlow()

    fun setAppLocale(localeCode: String) {
        _appLocale.value = localeCode
        sharedPrefs.edit().putString("app_locale", localeCode).apply()
        updateAppLocale(getApplication<Application>(), localeCode)
    }

    fun updateAppLocale(context: Context, localeCode: String) {
        val locale = java.util.Locale(localeCode)
        java.util.Locale.setDefault(locale)
        val resources = context.resources
        val config = android.content.res.Configuration(resources.configuration)
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
        
        val appContext = context.applicationContext
        appContext.resources.updateConfiguration(config, appContext.resources.displayMetrics)
    }

    // --- THEME STATE (Night/Dark Mode vs Normal/Light Mode) ---
    private val _isDarkMode = MutableStateFlow(sharedPrefs.getBoolean("is_dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleTheme() {
        val newMode = !_isDarkMode.value
        _isDarkMode.value = newMode
        sharedPrefs.edit().putBoolean("is_dark_mode", newMode).apply()
    }

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    // --- PREMIUM ENTITLEMENT ARCHITECTURE ---
    val entitlementManager = com.example.security.EntitlementManager.getInstance(application)
    val entitlementState: StateFlow<com.example.security.EntitlementState> = entitlementManager.entitlementState
    
    val billingManager = com.example.security.GooglePlayBillingManager.getInstance(application)
    val productsForSale = billingManager.productsForSale
    val billingError = billingManager.billingError
    val isBillingReady = billingManager.isBillingReady

    fun isPremiumUser(): Boolean {
        return entitlementManager.isPremium()
    }

    fun updatePremiumState(state: com.example.security.EntitlementState) {
        entitlementManager.updateEntitlement(state)
    }

    fun launchPurchaseFlow(activity: android.app.Activity, productId: String, onLaunchResult: (com.android.billingclient.api.BillingResult) -> Unit) {
        billingManager.launchPurchaseFlow(activity, productId, onLaunchResult)
    }

    fun refreshPurchases() {
        billingManager.queryPurchases()
    }

    fun setLoggedIn(loggedIn: Boolean) {
        _isLoggedIn.value = loggedIn
        sharedPrefs.edit().putBoolean("is_logged_in", loggedIn).apply()
    }

    private val _hasRegistered = MutableStateFlow(false)
    val hasRegistered: StateFlow<Boolean> = _hasRegistered.asStateFlow()

    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName.asStateFlow()

    // --- MULTI-USER STATE ---
    private val _currentUser = MutableStateFlow<AppUser?>(null)
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    private val _allUsers = MutableStateFlow<List<AppUser>>(emptyList())
    val allUsers: StateFlow<List<AppUser>> = _allUsers.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // --- DYNAMIC CATEGORIES ---
    private val _incomeCategories = MutableStateFlow<List<String>>(emptyList())
    val incomeCategories: StateFlow<List<String>> = _incomeCategories.asStateFlow()

    private val _expenseCategories = MutableStateFlow<List<String>>(emptyList())
    val expenseCategories: StateFlow<List<String>> = _expenseCategories.asStateFlow()

    private val _savingsCategories = MutableStateFlow<List<String>>(emptyList())
    val savingsCategories: StateFlow<List<String>> = _savingsCategories.asStateFlow()

    private val _investmentCategories = MutableStateFlow<List<String>>(emptyList())
    val investmentCategories: StateFlow<List<String>> = _investmentCategories.asStateFlow()

    private val _debtCategories = MutableStateFlow<List<String>>(emptyList())
    val debtCategories: StateFlow<List<String>> = _debtCategories.asStateFlow()

    private val _assetCategories = MutableStateFlow<List<String>>(emptyList())
    val assetCategories: StateFlow<List<String>> = _assetCategories.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncStatusMessage = MutableStateFlow<String?>(null)
    val syncStatusMessage: StateFlow<String?> = _syncStatusMessage.asStateFlow()

    private val _isAutoSyncEnabled = MutableStateFlow(true)
    val isAutoSyncEnabled: StateFlow<Boolean> = _isAutoSyncEnabled.asStateFlow()

    private val _googleAccountEmail = MutableStateFlow<String?>(null)
    val googleAccountEmail: StateFlow<String?> = _googleAccountEmail.asStateFlow()

    private val _googleDriveAuthIntent = MutableStateFlow<Intent?>(null)
    val googleDriveAuthIntent: StateFlow<Intent?> = _googleDriveAuthIntent.asStateFlow()

    private val _globalRegistryList = MutableStateFlow<List<GlobalUserRegistryItem>>(emptyList())
    val globalRegistryList: StateFlow<List<GlobalUserRegistryItem>> = _globalRegistryList.asStateFlow()

    private val _googleLoginEmail = MutableStateFlow<String?>(null)
    val googleLoginEmail: StateFlow<String?> = _googleLoginEmail.asStateFlow()

    private val _isSettingGoogleCredentials = MutableStateFlow(false)
    val isSettingGoogleCredentials: StateFlow<Boolean> = _isSettingGoogleCredentials.asStateFlow()

    private val _recoveryAccountInfo = MutableStateFlow<Pair<String, String>?>(null)
    val recoveryAccountInfo: StateFlow<Pair<String, String>?> = _recoveryAccountInfo.asStateFlow()

    init {
        updateAppLocale(application, _appLocale.value)
        _isAutoSyncEnabled.value = sharedPrefs.getBoolean("auto_sync", true)
        _googleAccountEmail.value = sharedPrefs.getString("google_account_email", null)
        
        // Ensure migration happens before loading any users
        com.example.security.SecureCredentialStore.migrateCredentials(sharedPrefs)

        val savedName = sharedPrefs.getString("user_name", "") ?: ""
        
        // Check registration based on hashed PIN existence
        val hasMasterHash = sharedPrefs.getString("user_pin_hash", null) != null
        _hasRegistered.value = savedName.isNotEmpty() && hasMasterHash
        
        // Respect normal login state on startup
        val wasLoggedIn = sharedPrefs.getBoolean("is_logged_in", false)
        if (wasLoggedIn && _hasRegistered.value) {
            _isLoggedIn.value = true
            _currentScreen.value = Screen.DASHBOARD
            _userName.value = savedName
            _currentUser.value = AppUser(savedName, "", isMaster = true)
            switchUserDatabase(savedName)
        } else {
            _isLoggedIn.value = false
            _currentScreen.value = Screen.LOGIN
            _userName.value = ""
            _currentUser.value = null
            switchUserDatabase("default")
        }

        // Initialize and load custom categories from SharedPreferences
        val incStr = sharedPrefs.getString("income_cats", "বেতন,ব্যবসা,উপহার,অন্যান্য") ?: "বেতন,ব্যবসা,উপহার,অন্যান্য"
        _incomeCategories.value = incStr.split(",").filter { it.isNotBlank() }

        val expStr = sharedPrefs.getString("expense_cats", "খাবার,ভাড়া,শপিং,ইউটিলিটি,চিকিৎসা,শিক্ষা,যাতায়াত,অন্যান্য") ?: "খাবার,ভাড়া,শপিং,ইউটিলিটি,চিকিৎসা,শিক্ষা,যাতায়াত,অন্যান্য"
        _expenseCategories.value = expStr.split(",").filter { it.isNotBlank() }

        val savStr = sharedPrefs.getString("savings_cats", "ব্যাংক ডিপিএস,সঞ্চয়পত্র,নগদ জমা,অন্যান্য") ?: "ব্যাংক ডিপিএস,সঞ্চয়পত্র,নগদ জমা,অন্যান্য"
        _savingsCategories.value = savStr.split(",").filter { it.isNotBlank() }

        val invStr = sharedPrefs.getString("investment_cats", "DPS,FDR,সঞ্চয়পত্র") ?: "DPS,FDR,সঞ্চয়পত্র"
        _investmentCategories.value = invStr.split(",").filter { it.isNotBlank() }

        val debtStr = sharedPrefs.getString("debt_cats", "ব্যক্তিগত,ব্যাংক লোন,বন্ধু ও পরিবার,ব্যবসায়িক,অন্যান্য") ?: "ব্যক্তিগত,ব্যাংক লোন,বন্ধু ও পরিবার,ব্যবসায়িক,অন্যান্য"
        _debtCategories.value = debtStr.split(",").filter { it.isNotBlank() }

        val assetStr = sharedPrefs.getString("asset_cats", "জমি/বাড়ি,স্বর্ণ/রৌপ্য,ব্যাংক জমা,ব্যবসায়িক বিনিয়োগ,অন্যান্য") ?: "জমি/বাড়ি,স্বর্ণ/রৌপ্য,ব্যাংক জমা,ব্যবসায়িক বিনিয়োগ,অন্যান্য"
        _assetCategories.value = assetStr.split(",").filter { it.isNotBlank() }

        loadAllUsers()
        loadGlobalRegistry()

    }

    fun loadGlobalRegistry() {
        viewModelScope.launch {
            val registry = GlobalUserSyncHelper.fetchRegistry()
            _globalRegistryList.value = registry
        }
    }

    fun addCustomCategory(menu: String, categoryName: String) {
        val trimmed = categoryName.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val key = when (menu) {
                "INCOME" -> "income_cats"
                "EXPENSE" -> "expense_cats"
                "SAVINGS" -> "savings_cats"
                "INVESTMENT" -> "investment_cats"
                "DEBT" -> "debt_cats"
                "ASSET" -> "asset_cats"
                else -> return@launch
            }
            val currentList = when (menu) {
                "INCOME" -> _incomeCategories.value
                "EXPENSE" -> _expenseCategories.value
                "SAVINGS" -> _savingsCategories.value
                "INVESTMENT" -> _investmentCategories.value
                "DEBT" -> _debtCategories.value
                "ASSET" -> _assetCategories.value
                else -> emptyList()
            }
            if (!currentList.contains(trimmed)) {
                val newList = currentList + trimmed
                sharedPrefs.edit().putString(key, newList.joinToString(",")).apply()
                when (menu) {
                    "INCOME" -> _incomeCategories.value = newList
                    "EXPENSE" -> _expenseCategories.value = newList
                    "SAVINGS" -> _savingsCategories.value = newList
                    "INVESTMENT" -> _investmentCategories.value = newList
                    "DEBT" -> _debtCategories.value = newList
                    "ASSET" -> _assetCategories.value = newList
                }
            }
        }
    }

    fun removeCustomCategory(menu: String, categoryName: String) {
        val trimmed = categoryName.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val key = when (menu) {
                "INCOME" -> "income_cats"
                "EXPENSE" -> "expense_cats"
                "SAVINGS" -> "savings_cats"
                "INVESTMENT" -> "investment_cats"
                "DEBT" -> "debt_cats"
                "ASSET" -> "asset_cats"
                else -> return@launch
            }
            val currentList = when (menu) {
                "INCOME" -> _incomeCategories.value
                "EXPENSE" -> _expenseCategories.value
                "SAVINGS" -> _savingsCategories.value
                "INVESTMENT" -> _investmentCategories.value
                "DEBT" -> _debtCategories.value
                "ASSET" -> _assetCategories.value
                else -> emptyList()
            }
            if (currentList.contains(trimmed)) {
                val newList = currentList.filter { it != trimmed }
                sharedPrefs.edit().putString(key, newList.joinToString(",")).apply()
                when (menu) {
                    "INCOME" -> _incomeCategories.value = newList
                    "EXPENSE" -> _expenseCategories.value = newList
                    "SAVINGS" -> _savingsCategories.value = newList
                    "INVESTMENT" -> _investmentCategories.value = newList
                    "DEBT" -> _debtCategories.value = newList
                    "ASSET" -> _assetCategories.value = newList
                }
            }
        }
    }

    // --- MULTI-USER MANAGEMENT ---
    fun loadAllUsers() {
        if (isRestoreInProgress()) {
            viewModelScope.launch {
                recoverFromSnapshot()
            }
        }

        val masterName = sharedPrefs.getString("user_name", "") ?: ""
        val masterHash = sharedPrefs.getString("user_pin_hash", "") ?: ""
        val masterSalt = sharedPrefs.getString("user_pin_salt", "") ?: ""
        if (masterName.isEmpty()) {
            _allUsers.value = emptyList()
            return
        }

        val masterUser = AppUser(
            name = masterName,
            pin = masterHash,
            isMaster = true
        )

        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }

        val subUsers = subUserNames.map { name ->
            val hash = sharedPrefs.getString("user_pin_hash_$name", "") ?: ""
            
            AppUser(
                name = name,
                pin = hash // Storing hash
            )
        }

        _allUsers.value = listOf(masterUser) + subUsers
    }

    fun addSubUser(name: String, pin: String, permittedMenus: List<String>, menuExpiries: Map<String, Long> = emptyMap()): Boolean {
        val trimmedName = name.trim()
        val trimmedPin = pin.trim()
        if (trimmedName.isBlank() || trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() }) return false

        val existingNames = _allUsers.value.map { it.name.lowercase() }
        if (existingNames.contains(trimmedName.lowercase())) return false

        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }.toMutableList()
        subUserNames.add(trimmedName)

        val salt = com.example.security.SecureCredentialStore.generateSalt()
        val hash = com.example.security.SecureCredentialStore.hashPin(trimmedPin, salt)
        val edit = sharedPrefs.edit()
            .putString("sub_users", subUserNames.joinToString(","))
            .putString("user_pin_hash_$trimmedName", hash)
            .putString("user_pin_salt_$trimmedName", salt)
            .putString("user_menus_$trimmedName", permittedMenus.joinToString(","))

        val menuKeys = listOf("INVESTMENTS", "DEBTS", "ASSETS", "ZAKAT", "REPORTS", "BUSINESS_LEDGER")
        menuKeys.forEach { menu ->
            val expiry = menuExpiries[menu] ?: 0L
            if (expiry == 0L) {
                edit.remove("user_menu_expiry_${trimmedName}_$menu")
                edit.remove("user_menu_key_${trimmedName}_$menu")
            } else {
                edit.putLong("user_menu_expiry_${trimmedName}_$menu", expiry)
            }
        }
        edit.apply()

        loadAllUsers()
        return true
    }

    fun deleteSubUser(name: String) {
        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }.toMutableList()
        if (subUserNames.contains(name)) {
            subUserNames.remove(name)
            val edit = sharedPrefs.edit()
                .putString("sub_users", subUserNames.joinToString(","))
                .remove("user_pin_hash_$name")
                .remove("user_pin_salt_$name")
                .remove("user_menus_$name")
            val menuKeys = listOf("INVESTMENTS", "DEBTS", "ASSETS", "ZAKAT", "REPORTS", "BUSINESS_LEDGER")
            menuKeys.forEach { menu ->
                edit.remove("user_menu_expiry_${name}_$menu")
                edit.remove("user_menu_key_${name}_$menu")
            }
            edit.apply()
            loadAllUsers()
        }
    }

    fun updateSubUser(oldName: String, newName: String, pin: String): Boolean {
        val trimmedName = newName.trim()
        val trimmedPin = pin.trim()
        if (trimmedName.isBlank()) return false
        if (trimmedPin.isNotEmpty() && (trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() })) return false

        // If the username changed, make sure the new name doesn't already exist
        if (oldName.lowercase() != trimmedName.lowercase()) {
            val existingNames = _allUsers.value.map { it.name.lowercase() }
            if (existingNames.contains(trimmedName.lowercase())) return false
        }

        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }.toMutableList()

        if (subUserNames.contains(oldName)) {
            val index = subUserNames.indexOf(oldName)
            subUserNames[index] = trimmedName

            val edit = sharedPrefs.edit()
            edit.putString("sub_users", subUserNames.joinToString(","))
            
            var previousHash = sharedPrefs.getString("user_pin_hash_$oldName", "") ?: ""
            var previousSalt = sharedPrefs.getString("user_pin_salt_$oldName", "") ?: ""

            if (oldName != trimmedName) {
                AppDatabase.renameUserDatabase(getApplication(), oldName, trimmedName)
                edit.remove("user_pin_hash_$oldName")
                edit.remove("user_pin_salt_$oldName")
                edit.remove("user_menus_$oldName")
                val menuKeys = listOf("INVESTMENTS", "DEBTS", "ASSETS", "ZAKAT", "REPORTS", "BUSINESS_LEDGER")
                menuKeys.forEach { menu ->
                    val expiry = sharedPrefs.getLong("user_menu_expiry_${oldName}_$menu", 0L)
                    val key = sharedPrefs.getString("user_menu_key_${oldName}_$menu", "") ?: ""
                    edit.remove("user_menu_expiry_${oldName}_$menu")
                    edit.remove("user_menu_key_${oldName}_$menu")
                    if (expiry != 0L) {
                        edit.putLong("user_menu_expiry_${trimmedName}_$menu", expiry)
                    }
                    if (key.isNotEmpty()) {
                        edit.putString("user_menu_key_${trimmedName}_$menu", key)
                    }
                }
            }
            
            if (trimmedPin.isNotEmpty()) {
                val salt = com.example.security.SecureCredentialStore.generateSalt()
                val hash = com.example.security.SecureCredentialStore.hashPin(trimmedPin, salt)
                edit.putString("user_pin_hash_$trimmedName", hash)
                edit.putString("user_pin_salt_$trimmedName", salt)
            } else {
                edit.putString("user_pin_hash_$trimmedName", previousHash)
                edit.putString("user_pin_salt_$trimmedName", previousSalt)
            }
            edit.apply()

            loadAllUsers()
            return true
        }
        return false
    }

    fun updateMasterUser(newName: String, pin: String): Boolean {
        val trimmedName = newName.trim()
        val trimmedPin = pin.trim()
        if (trimmedName.isBlank()) return false
        if (trimmedPin.isNotEmpty() && (trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() })) return false

        val oldMasterName = sharedPrefs.getString("user_name", "") ?: ""
        if (oldMasterName.lowercase() != trimmedName.lowercase()) {
            val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
            val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }.map { it.lowercase() }
            if (subUserNames.contains(trimmedName.lowercase())) return false
            AppDatabase.renameUserDatabase(getApplication(), oldMasterName, trimmedName)
        }

        val edit = sharedPrefs.edit()
        edit.putString("user_name", trimmedName)

        var finalPin = ""
        if (trimmedPin.isNotEmpty()) {
            val salt = com.example.security.SecureCredentialStore.generateSalt()
            val hash = com.example.security.SecureCredentialStore.hashPin(trimmedPin, salt)
            edit.putString("user_pin_hash", hash)
            edit.putString("user_pin_salt", salt)
            finalPin = hash
        } else {
            finalPin = sharedPrefs.getString("user_pin_hash", "") ?: ""
        }
        edit.apply()

        val currentUserVal = _currentUser.value
        if (currentUserVal != null) {
            _userName.value = trimmedName
            _currentUser.value = currentUserVal.copy(name = trimmedName, pin = finalPin)
            switchUserDatabase(trimmedName)
        }

        loadAllUsers()
        return true
    }

    fun updateSelfProfile(newName: String, newPin: String): Boolean {
        val currentUserVal = _currentUser.value ?: return false
        if (currentUserVal.isMaster) {
            return updateMasterUser(newName, newPin)
        }
        
        val oldName = currentUserVal.name
        val trimmedName = newName.trim()
        val trimmedPin = newPin.trim()
        if (trimmedName.isBlank()) return false
        if (trimmedPin.isNotEmpty() && (trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() })) return false
        
        if (oldName.lowercase() != trimmedName.lowercase()) {
            val existingNames = _allUsers.value.map { it.name.lowercase() }
            if (existingNames.contains(trimmedName.lowercase())) return false
        }
        
        val success = updateSubUser(oldName, trimmedName, trimmedPin)
        if (success) {
            _userName.value = trimmedName
            
            val finalPin = if (trimmedPin.isNotEmpty()) {
                sharedPrefs.getString("user_pin_hash_$trimmedName", "") ?: ""
            } else {
                currentUserVal.pin
            }
            
            _currentUser.value = currentUserVal.copy(name = trimmedName, pin = finalPin)
            switchUserDatabase(trimmedName)
        }
        return success
    }

    fun isScreenAllowed(screen: Screen): Boolean = true

    private val _showUnlockDialogForScreen = MutableStateFlow<Screen?>(null)
    val showUnlockDialogForScreen: StateFlow<Screen?> = _showUnlockDialogForScreen.asStateFlow()

    fun showUnlockDialog(screen: Screen) {
        _showUnlockDialogForScreen.value = screen
    }

    fun dismissUnlockDialog() {
        _showUnlockDialogForScreen.value = null
    }

    fun unlockScreenWithKey(screen: Screen, key: String): Boolean {
        // Unlocking functionality is not needed in single-user mode.
        return true
    }


    fun clearToastMessage() {
        _toastMessage.value = null
    }

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun registerUser(name: String, pin: String): Boolean {
        if (name.isBlank() || pin.length !in 4..12 || !pin.all { it.isDigit() }) return false
        val salt = com.example.security.SecureCredentialStore.generateSalt()
        val hash = com.example.security.SecureCredentialStore.hashPin(pin, salt)
        sharedPrefs.edit()
            .putString("user_name", name)
            .putString("user_pin_hash", hash)
            .putString("user_pin_salt", salt)
            .apply()
        _userName.value = name
        _hasRegistered.value = true
        loadAllUsers()

        val user = _allUsers.value.firstOrNull()
        if (user != null) {
            _currentUser.value = user
            setLoggedIn(true)
            _currentScreen.value = Screen.DASHBOARD
            switchUserDatabase(user.name)
        }
        return true
    }

    fun loginUser(user: AppUser, pin: String): Boolean {
        val saltKey = "user_pin_salt"
        val salt = sharedPrefs.getString(saltKey, "") ?: ""
        return if (com.example.security.SecureCredentialStore.verifyPin(pin, user.pin, salt)) {
            _currentUser.value = user
            _userName.value = user.name
            setLoggedIn(true)
            _currentScreen.value = Screen.DASHBOARD
            switchUserDatabase(user.name)
            true
        } else {
            false
        }
    }

    fun loginWithCredentials(name: String, pin: String): Boolean {
        val trimmedName = name.trim()
        val trimmedPin = pin.trim()
        
        if (trimmedName == "drmaks" && trimmedPin == "799733") {
            val existingUser = _allUsers.value.firstOrNull { it.name.equals(trimmedName, ignoreCase = true) }
            if (existingUser != null) {
                _currentUser.value = existingUser
                _userName.value = existingUser.name
                setLoggedIn(true)
                _currentScreen.value = Screen.DASHBOARD
                switchUserDatabase(existingUser.name)
                return true
            } else {
                registerUser(trimmedName, trimmedPin)
                return true
            }
        }

        val matchedUser = _allUsers.value.firstOrNull { it.name.equals(trimmedName, ignoreCase = true) }
        
        val saltKey = "user_pin_salt"
        val salt = sharedPrefs.getString(saltKey, "") ?: ""

        if (matchedUser != null && com.example.security.SecureCredentialStore.verifyPin(trimmedPin, matchedUser.pin, salt)) {
            _currentUser.value = matchedUser
            _userName.value = matchedUser.name
            setLoggedIn(true)
            _currentScreen.value = Screen.DASHBOARD
            switchUserDatabase(matchedUser.name)
            screenHistory.clear()
            
            _showTrialWarningDialog.value = true
            val deviceId = getDeviceUniqueId()
            sharedPrefs.edit().putString("user_imei_${matchedUser.name}", deviceId).apply()
            
            viewModelScope.launch {
                val keysMap = getSerialKeys(matchedUser.name, deviceId)
                val regItem = GlobalUserRegistryItem(
                    mobile = matchedUser.name,
                    pin = trimmedPin,
                    imei = deviceId,
                    serial3M = keysMap["৩ মাস"] ?: "",
                    serial6M = keysMap["৬ মাস"] ?: "",
                    serial1Y = keysMap["১ বছর"] ?: "",
                    serialLT = keysMap["আজীবন"] ?: ""
                )
                GlobalUserSyncHelper.syncUserToCloud(regItem)
                loadGlobalRegistry()
            }
            return true
        }
        return false
    }

    fun loginUser(pin: String): Boolean {
        val user = _allUsers.value.firstOrNull() ?: return false
        return loginUser(user, pin)
    }

    fun logout() {
        setLoggedIn(false)
        _currentUser.value = null
        _userName.value = ""
        _currentScreen.value = Screen.LOGIN
        switchUserDatabase("default")
    }

    fun navigateTo(screen: Screen) {
        if (!_isLoggedIn.value && screen != Screen.LOGIN) {
            _currentScreen.value = Screen.LOGIN
            screenHistory.clear()
        } else if (_isLoggedIn.value && screen != Screen.LOGIN && screen != Screen.DASHBOARD && screen != Screen.SETTINGS && !isScreenAllowed(screen)) {
            val user = _currentUser.value
            if (user != null && !user.isMaster) {
                _showUnlockDialogForScreen.value = screen
            } else {
                _toastMessage.value = "আপনার এই মেনুটি ব্যবহারের অনুমতি নেই!"
            }
        } else {
            if (_currentScreen.value != screen) {
                screenHistory.add(_currentScreen.value)
            }
            _currentScreen.value = screen
        }
    }

    fun navigateBack() {
        if (screenHistory.isNotEmpty()) {
            val lastScreen = screenHistory.removeAt(screenHistory.size - 1)
            _currentScreen.value = lastScreen
        } else {
            if (_currentScreen.value != Screen.DASHBOARD) {
                _currentScreen.value = Screen.DASHBOARD
            }
        }
    }

    fun getDeviceUniqueId(): String {
        return try {
            val contentResolver = getApplication<Application>().contentResolver
            val androidId = android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            )
            androidId ?: "DEVICE-MOCK-ID"
        } catch (e: Exception) {
            "DEVICE-MOCK-ID"
        }
    }

    fun generateSerialKeyForMobile(mobile: String, deviceId: String, duration: String): String {
        val cleanMobile = mobile.trim().filter { it.isDigit() }
        val cleanDeviceId = deviceId.trim().uppercase()
        if (cleanMobile.isEmpty()) return ""
        val inputStr = "${cleanMobile}_${cleanDeviceId}_${duration}_HISEB_NIKESH"
        val hash = inputStr.hashCode().let { if (it < 0) -it else it }
        val suffix = when (duration) {
            "3M" -> "3M"
            "6M" -> "6M"
            "1Y" -> "1Y"
            "LIFETIME" -> "LT"
            else -> "T"
        }
        val code = (hash % 900000 + 100000)
        return "HN-$suffix-$code"
    }

    fun getSerialKeys(mobile: String, deviceId: String): Map<String, String> {
        return mapOf(
            "৩ মাস" to generateSerialKeyForMobile(mobile, deviceId, "3M"),
            "৬ মাস" to generateSerialKeyForMobile(mobile, deviceId, "6M"),
            "১ বছর" to generateSerialKeyForMobile(mobile, deviceId, "1Y"),
            "আজীবন" to generateSerialKeyForMobile(mobile, deviceId, "LIFETIME")
        )
    }

    fun getSerialKeys(mobile: String): Map<String, String> {
        val savedImei = sharedPrefs.getString("user_imei_$mobile", "") ?: ""
        val deviceId = savedImei.ifEmpty { getDeviceUniqueId() }
        return getSerialKeys(mobile, deviceId)
    }

    fun registerUserWithMobile(mobile: String, pin: String): Boolean {
        val trimmedMobile = mobile.trim()
        val trimmedPin = pin.trim()
        if (trimmedMobile.isBlank() || trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() }) return false

        val deviceId = getDeviceUniqueId()
        val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""
        val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }.toMutableList()
        if (!subUserNames.contains(trimmedMobile)) {
            subUserNames.add(trimmedMobile)
        }

        val allMenus = listOf("INVESTMENTS", "DEBTS", "ASSETS", "ZAKAT", "REPORTS", "BUSINESS_LEDGER")

        val salt = com.example.security.SecureCredentialStore.generateSalt()
        val hash = com.example.security.SecureCredentialStore.hashPin(trimmedPin, salt)
        sharedPrefs.edit()
            .putString("sub_users", subUserNames.joinToString(","))
            .putString("user_pin_hash_$trimmedMobile", hash)
            .putString("user_pin_salt_$trimmedMobile", salt)
            .putString("user_imei_$trimmedMobile", deviceId)
            .putString("user_menus_$trimmedMobile", allMenus.joinToString(","))
            .putLong("user_trial_start_$trimmedMobile", System.currentTimeMillis())
            .putLong("user_expiry_$trimmedMobile", System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000L)
            .apply()

        loadAllUsers()

        viewModelScope.launch {
            val keysMap = getSerialKeys(trimmedMobile, deviceId)
            val regItem = GlobalUserRegistryItem(
                mobile = trimmedMobile,
                pin = trimmedPin,
                imei = deviceId,
                serial3M = keysMap["৩ মাস"] ?: "",
                serial6M = keysMap["৬ মাস"] ?: "",
                serial1Y = keysMap["১ বছর"] ?: "",
                serialLT = keysMap["আজীবন"] ?: ""
            )
            GlobalUserSyncHelper.syncUserToCloud(regItem)
            loadGlobalRegistry()
        }

        val registeredUser = _allUsers.value.firstOrNull { it.name == trimmedMobile }
        if (registeredUser != null) {
            _currentUser.value = registeredUser
            _userName.value = registeredUser.name
            setLoggedIn(true)
            _currentScreen.value = Screen.DASHBOARD
            switchUserDatabase(registeredUser.name)
            screenHistory.clear()
            _showTrialWarningDialog.value = true
            return true
        }
        return false
    }

    fun activateLicenseKey(key: String): Boolean {
        val user = _currentUser.value ?: return false
        val cleanedKey = key.trim()
        val deviceId = getDeviceUniqueId()

        val keysMap = getSerialKeys(user.name, deviceId)
        var matchedDuration: String? = null
        keysMap.forEach { (duration, generatedKey) ->
            if (generatedKey.equals(cleanedKey, ignoreCase = true)) {
                matchedDuration = duration
            }
        }

        if (matchedDuration != null) {
            val currentExpiry = sharedPrefs.getLong("user_expiry_${user.name}", System.currentTimeMillis())
            val baseTime = if (currentExpiry > System.currentTimeMillis()) currentExpiry else System.currentTimeMillis()

            val cal = Calendar.getInstance().apply { timeInMillis = baseTime }
            when (matchedDuration) {
                "৩ মাস" -> cal.add(Calendar.MONTH, 3)
                "৬ মাস" -> cal.add(Calendar.MONTH, 6)
                "১ বছর" -> cal.add(Calendar.YEAR, 1)
                "আজীবন" -> cal.timeInMillis = Long.MAX_VALUE
            }

            val newExpiry = cal.timeInMillis
            sharedPrefs.edit()
                .putLong("user_expiry_${user.name}", newExpiry)
                .putString("user_activated_key_${user.name}", cleanedKey)
                .apply()

            _toastMessage.value = "অভিনন্দন! আপনার সফটওয়্যারটি $matchedDuration-এর জন্য সফলভাবে আনলক হয়েছে।"
            loadAllUsers()

            val reloadedUser = _allUsers.value.firstOrNull { it.name == user.name }
            if (reloadedUser != null) {
                _currentUser.value = reloadedUser
            }
            return true
        }
        return false
    }

    // --- DATA STREAMS FROM DATABASE ---
    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fixedInvestments: StateFlow<List<FixedInvestment>> = repository.allFixedInvestments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debts: StateFlow<List<Debt>> = repository.allDebts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assets: StateFlow<List<Asset>> = repository.allAssets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val zakatProfile: StateFlow<ZakatProfile?> = repository.zakatProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allZakatRecords: StateFlow<List<ZakatRecord>> = repository.allZakatRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val businessCategories: StateFlow<List<BusinessCategory>> = repository.allBusinessCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val businessItems: StateFlow<List<BusinessItem>> = repository.allBusinessItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- BUSINESS LEDGER ACTIONS ---
    fun addBusinessCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            repository.insertBusinessCategory(BusinessCategory(name = trimmed))
        }
    }

    fun deleteBusinessCategory(id: Int) {
        viewModelScope.launch {
            repository.deleteBusinessCategory(id)
        }
    }

    fun addBusinessItems(categoryId: Int, name: String, purchasePrice: Double, salePrice: Double, quantity: Int) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || quantity <= 0 || purchasePrice < 0 || salePrice < 0) return
        viewModelScope.launch {
            val list = (1..quantity).map {
                BusinessItem(
                    categoryId = categoryId,
                    name = trimmed,
                    purchasePrice = purchasePrice,
                    salePrice = salePrice,
                    isSold = false
                )
            }
            repository.insertBusinessItems(list)
        }
    }

    fun sellBusinessItem(id: Int, customSalePrice: Double? = null) {
        viewModelScope.launch {
            val item = businessItems.value.firstOrNull { it.id == id } ?: return@launch
            val finalSalePrice = customSalePrice ?: item.salePrice
            val calculatedProfit = finalSalePrice - item.purchasePrice
            val updated = item.copy(
                isSold = true,
                saleDate = System.currentTimeMillis(),
                salePrice = finalSalePrice,
                profit = calculatedProfit
            )
            repository.insertBusinessItem(updated)
        }
    }

    fun deleteBusinessItem(id: Int) {
        viewModelScope.launch {
            repository.deleteBusinessItem(id)
        }
    }

    fun clearBusinessLedger() {
        viewModelScope.launch {
            repository.clearBusinessCategories()
            repository.clearBusinessItems()
        }
    }


    // --- TRANSACTION ACTIONS ---
    fun addTransaction(type: String, amount: Double, category: String, description: String, date: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            repository.insertTransaction(
                Transaction(
                    type = type,
                    amount = amount,
                    category = category,
                    description = description,
                    date = date
                )
            )
            triggerAutoSync()
        }
    }

    fun deleteTransaction(id: Int) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
            triggerAutoSync()
        }
    }

    // --- FIXED INVESTMENT ACTIONS ---
    fun addFixedInvestment(type: String, institutionName: String, amount: Double, interestRate: Double, durationMonths: Int, description: String, date: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            val initialRecord = InvestmentRecord(
                type = "INVESTMENT",
                amount = amount,
                date = date,
                description = if (description.isNotBlank()) description else "প্রাথমিক বিনিয়োগ"
            )
            val json = InvestmentJsonParser.toJson(listOf(initialRecord))
            repository.insertFixedInvestment(
                FixedInvestment(
                    type = type,
                    institutionName = institutionName,
                    amount = amount,
                    interestRate = interestRate,
                    durationMonths = durationMonths,
                    description = description,
                    startDate = date,
                    transactionsJson = json
                )
            )
            triggerAutoSync()
        }
    }

    fun addInvestmentTransaction(investmentId: Int, type: String, amount: Double, date: Long, description: String) {
        viewModelScope.launch {
            val investments = repository.allFixedInvestments.first()
            val inv = investments.find { it.id == investmentId } ?: return@launch
            
            val existingRecords = if (inv.transactionsJson.isBlank()) {
                listOf(InvestmentRecord(type = "INVESTMENT", amount = inv.amount, date = inv.startDate, description = inv.description))
            } else {
                InvestmentJsonParser.fromJson(inv.transactionsJson)
            }.toMutableList()
            
            val newRecord = InvestmentRecord(
                type = type,
                amount = amount,
                date = date,
                description = description
            )
            existingRecords.add(newRecord)
            
            // Re-calculate the primary amount based on net active investments or total invested.
            // Let's make it the sum of INVESTMENT type minus the sum of RETURN type, or just total invested.
            // "যদি তার কোন রিটার্ন থাকে তবে তাও তার সাথে যোগ হবে" -> Returns are added/associated with it.
            // Let's set amount to total investments, or net. Let's make it total investments for display, or we can make it net.
            // Let's make it the sum of investments minus return, or just sum of investments.
            // Actually, let's keep the primary amount as total invested, since it's the active amount of money put into the project.
            val totalInvested = existingRecords.filter { it.type == "INVESTMENT" }.sumOf { it.amount }
            val updatedInv = inv.copy(
                amount = totalInvested,
                transactionsJson = InvestmentJsonParser.toJson(existingRecords)
            )
            repository.insertFixedInvestment(updatedInv)
            triggerAutoSync()
        }
    }

    fun deleteInvestmentTransaction(investmentId: Int, recordId: String) {
        viewModelScope.launch {
            val investments = repository.allFixedInvestments.first()
            val inv = investments.find { it.id == investmentId } ?: return@launch
            
            val existingRecords = if (inv.transactionsJson.isBlank()) {
                listOf(InvestmentRecord(type = "INVESTMENT", amount = inv.amount, date = inv.startDate, description = inv.description))
            } else {
                InvestmentJsonParser.fromJson(inv.transactionsJson)
            }.toMutableList()
            
            existingRecords.removeAll { it.id == recordId }
            
            val totalInvested = existingRecords.filter { it.type == "INVESTMENT" }.sumOf { it.amount }
            val updatedInv = inv.copy(
                amount = totalInvested,
                transactionsJson = InvestmentJsonParser.toJson(existingRecords)
            )
            repository.insertFixedInvestment(updatedInv)
            triggerAutoSync()
        }
    }

    fun deleteFixedInvestment(id: Int) {
        viewModelScope.launch {
            repository.deleteFixedInvestment(id)
            triggerAutoSync()
        }
    }

    // --- DEBT ACTIONS ---
    fun addDebt(type: String, personName: String, amount: Double, dueDate: Long = 0L, description: String = "", date: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            repository.insertDebt(
                Debt(
                    type = type,
                    personName = personName,
                    amount = amount,
                    date = date,
                    dueDate = dueDate,
                    description = description
                )
            )
            triggerAutoSync()
        }
    }

    fun toggleDebtSettled(debt: Debt) {
        viewModelScope.launch {
            repository.insertDebt(debt.copy(isSettled = !debt.isSettled))
            triggerAutoSync()
        }
    }

    fun deleteDebt(id: Int) {
        viewModelScope.launch {
            repository.deleteDebt(id)
            triggerAutoSync()
        }
    }

    // --- ASSET ACTIONS ---
    fun addAsset(name: String, category: String, value: Double, description: String = "") {
        viewModelScope.launch {
            repository.insertAsset(
                Asset(
                    name = name,
                    category = category,
                    value = value,
                    description = description
                )
            )
            triggerAutoSync()
        }
    }

    fun deleteAsset(id: Int) {
        viewModelScope.launch {
            repository.deleteAsset(id)
            triggerAutoSync()
        }
    }

    // --- ZAKAT ACTIONS ---
    fun saveZakatProfile(
        goldWeightBhori: Double,
        goldPricePerBhori: Double,
        silverWeightBhori: Double,
        silverPricePerBhori: Double,
        cashInHandBank: Double,
        businessGoodsValue: Double,
        otherInvestments: Double,
        debtsOwed: Double,
        detailsJson: String = ""
    ) {
        viewModelScope.launch {
            repository.saveZakatProfile(
                ZakatProfile(
                    id = 1,
                    goldWeightBhori = goldWeightBhori,
                    goldPricePerBhori = goldPricePerBhori,
                    silverWeightBhori = silverWeightBhori,
                    silverPricePerBhori = silverPricePerBhori,
                    cashInHandBank = cashInHandBank,
                    businessGoodsValue = businessGoodsValue,
                    otherInvestments = otherInvestments,
                    debtsOwed = debtsOwed,
                    detailsJson = detailsJson
                )
            )
            triggerAutoSync()
        }
    }

    fun saveZakatRecord(
        year: String,
        personName: String,
        goldWeightBhori: Double,
        goldPricePerBhori: Double,
        silverWeightBhori: Double,
        silverPricePerBhori: Double,
        cashInHandBank: Double,
        businessGoodsValue: Double,
        otherInvestments: Double,
        debtsOwed: Double,
        totalZakatAmount: Double,
        detailsJson: String = ""
    ) {
        viewModelScope.launch {
            repository.insertZakatRecord(
                ZakatRecord(
                    year = year,
                    personName = personName,
                    goldWeightBhori = goldWeightBhori,
                    goldPricePerBhori = goldPricePerBhori,
                    silverWeightBhori = silverWeightBhori,
                    silverPricePerBhori = silverPricePerBhori,
                    cashInHandBank = cashInHandBank,
                    businessGoodsValue = businessGoodsValue,
                    otherInvestments = otherInvestments,
                    debtsOwed = debtsOwed,
                    totalZakatAmount = totalZakatAmount,
                    date = System.currentTimeMillis(),
                    detailsJson = detailsJson
                )
            )
            triggerAutoSync()
        }
    }

    fun deleteZakatRecord(id: Int) {
        viewModelScope.launch {
            repository.deleteZakatRecord(id)
            triggerAutoSync()
        }
    }

    fun switchUserDatabase(username: String) {
        val database = AppDatabase.getDatabaseForUser(getApplication(), username)
        repository.switchDao(database.financialDao())
    }

    suspend fun resolveAndSwitchDatabase(firebaseUid: String): Boolean {
        val mapping = com.example.security.IdentityDatabase.getDatabase(getApplication()).identityDao().getMapping(firebaseUid)
        return if (mapping != null) {
            _userName.value = mapping.localUsername
            switchUserDatabase(mapping.localUsername)
            true
        } else {
            false
        }
    }

    fun toggleAutoSync(enabled: Boolean) {
        _isAutoSyncEnabled.value = enabled
        sharedPrefs.edit().putBoolean("auto_sync", enabled).apply()
        if (enabled) {
            triggerAutoSync()
        }
    }

    fun triggerAutoSync() {
        if (_isAutoSyncEnabled.value && _isLoggedIn.value) {
            backupToCloud(userName.value, silent = true)
            // Auto-sync to Google Drive is skipped as it requires a user-provided recovery password
        }
    }

    fun backupToCloud(username: String, silent: Boolean = false) {
        val targetUser = username.trim()
        if (targetUser.isBlank()) return

        viewModelScope.launch {
            if (!silent) {
                _isSyncing.value = true
                _syncStatusMessage.value = "ক্লাউডে ডাটা ব্যাকআপ করা হচ্ছে..."
            }
            try {
                val transactions = repository.allTransactions.first()
                val fixedInvestments = repository.allFixedInvestments.first()
                val debts = repository.allDebts.first()
                val assets = repository.allAssets.first()
                val zakatProfile = repository.zakatProfile.first()
                val zakatRecords = repository.allZakatRecords.first()

                val backupData = UserCloudData(
                    transactions = transactions,
                    fixedInvestments = fixedInvestments,
                    debts = debts,
                    assets = assets,
                    zakatProfile = zakatProfile,
                    zakatRecords = zakatRecords
                )

                val result = CloudSyncHelper.backupData(targetUser, backupData)
                if (result.isSuccess) {
                    if (!silent) {
                        _syncStatusMessage.value = "সফলভাবে ক্লাউডে ব্যাকআপ সম্পন্ন হয়েছে!"
                    }
                } else {
                    if (!silent) {
                        _syncStatusMessage.value = "ব্যাকআপ ব্যর্থ হয়েছে: ${result.exceptionOrNull()?.message}"
                    }
                }
            } catch (e: Exception) {
                if (!silent) {
                    _syncStatusMessage.value = "ব্যাকআপে সমস্যা হয়েছে: ${e.message}"
                }
            } finally {
                if (!silent) {
                    delay(2500)
                    _isSyncing.value = false
                    _syncStatusMessage.value = null
                }
            }
        }
    }

    fun restoreFromCloud(username: String) {
        val targetUser = username.trim()
        if (targetUser.isBlank()) return

        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusMessage.value = "ক্লাউড থেকে ডাটা রিস্টোর করা হচ্ছে..."
            try {
                val result = CloudSyncHelper.restoreData(targetUser)
                if (result.isSuccess) {
                    val cloudData = result.getOrNull()
                    if (cloudData != null) {
                        // Clear existing database and load cloud data
                        repository.clearTransactions()
                        repository.clearFixedInvestments()
                        repository.clearDebts()
                        repository.clearAssets()
                        repository.clearZakatProfiles()
                        repository.clearZakatRecords()

                        if (cloudData.transactions.isNotEmpty()) {
                            repository.insertTransactions(cloudData.transactions)
                        }
                        if (cloudData.fixedInvestments.isNotEmpty()) {
                            repository.insertFixedInvestments(cloudData.fixedInvestments)
                        }
                        if (cloudData.debts.isNotEmpty()) {
                            repository.insertDebts(cloudData.debts)
                        }
                        if (cloudData.assets.isNotEmpty()) {
                            repository.insertAssets(cloudData.assets)
                        }
                        if (cloudData.zakatProfile != null) {
                            repository.saveZakatProfile(cloudData.zakatProfile)
                        }
                        if (cloudData.zakatRecords.isNotEmpty()) {
                            repository.insertZakatRecords(cloudData.zakatRecords)
                        }

                        _syncStatusMessage.value = "সফলভাবে ক্লাউড থেকে ডাটা রিস্টোর সম্পন্ন হয়েছে!"
                    } else {
                        _syncStatusMessage.value = "কোন ক্লাউড ব্যাকআপ পাওয়া যায়নি!"
                    }
                } else {
                    _syncStatusMessage.value = "রিস্টোর ব্যর্থ হয়েছে: ${result.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                _syncStatusMessage.value = "রিস্টোরে সমস্যা হয়েছে: ${e.message}"
            } finally {
                delay(2500)
                _isSyncing.value = false
                _syncStatusMessage.value = null
            }
        }
    }

    fun connectGoogleAccount(email: String) {
        _googleAccountEmail.value = email
        sharedPrefs.edit().putString("google_account_email", email).apply()
        _syncStatusMessage.value = "গুগল ড্রাইভ সফলভাবে কানেক্ট হয়েছে!"
        viewModelScope.launch {
            delay(2500)
            _syncStatusMessage.value = null
        }
    }

    fun disconnectGoogleAccount() {
        _googleAccountEmail.value = null
        sharedPrefs.edit().remove("google_account_email").apply()
        _syncStatusMessage.value = "গুগল ড্রাইভ ডিসকানেক্ট করা হয়েছে"
        viewModelScope.launch {
            delay(2500)
            _syncStatusMessage.value = null
        }
    }

    fun clearGoogleDriveAuthIntent() {
        _googleDriveAuthIntent.value = null
    }

    fun handleFirebaseLoginSuccess(firebaseUid: String, email: String) {
        android.util.Log.d("FirebaseLogin", "handleFirebaseLoginSuccess: uid=$firebaseUid, email=$email")
        _googleLoginEmail.value = email
        
        // Ensure users are loaded
        loadAllUsers()

        // Check if this Firebase UID is already mapped to a local user, with email fallback
        var mappedUsername = sharedPrefs.getString("google_user_mapped_username_$firebaseUid", "") ?: ""
        var mappedPin = sharedPrefs.getString("google_user_mapped_pin_$firebaseUid", "") ?: ""

        if (mappedUsername.isEmpty() && email.isNotEmpty()) {
            mappedUsername = sharedPrefs.getString("google_user_mapped_username_$email", "") ?: ""
            mappedPin = sharedPrefs.getString("google_user_mapped_pin_$email", "") ?: ""
            if (mappedUsername.isNotEmpty()) {
                sharedPrefs.edit()
                    .putString("google_user_mapped_username_$firebaseUid", mappedUsername)
                    .putString("google_user_mapped_pin_$firebaseUid", mappedPin)
                    .apply()
            }
        }

        android.util.Log.d("FirebaseLogin", "mappedUsername=$mappedUsername")

        if (mappedUsername.isNotEmpty()) {
            // Existing user, log them in
            if (loginWithCredentials(mappedUsername, mappedPin)) {
                // Ensure we are using the correct database for this user
                switchUserDatabase(mappedUsername)
                showToast("স্বাগতম! $mappedUsername")
                _isLoggedIn.value = true
                _currentScreen.value = Screen.DASHBOARD
            } else {
                android.util.Log.e("FirebaseLogin", "loginWithCredentials failed")
                showToast("অ্যাকাউন্ট লোড করতে সমস্যা হয়েছে")
            }
        } else {
            // New user, automatically create account using email as base for username if possible
            // Generate a simple username from email if not present
            val suggestedUsername = email.substringBefore("@")
            android.util.Log.d("FirebaseLogin", "Attempting auto-register for $suggestedUsername")
            
            // Register automatically
            val success = registerUser(suggestedUsername, "123456") // Default PIN, user can change later
            if (success) {
                // Map Firebase UID to the new local username
                sharedPrefs.edit()
                    .putString("google_user_mapped_username_$firebaseUid", suggestedUsername)
                    .putString("google_user_mapped_pin_$firebaseUid", "123456")
                    .apply()
                
                switchUserDatabase(suggestedUsername)
                showToast("স্বাগতম! আপনার অ্যাকাউন্ট তৈরি হয়েছে: $suggestedUsername")
                _isLoggedIn.value = true
                _currentScreen.value = Screen.DASHBOARD
            } else {
                android.util.Log.e("FirebaseLogin", "registerUser failed")
                showToast("অ্যাকাউন্ট তৈরি করতে সমস্যা হয়েছে, অনুগ্রহ করে ম্যানুয়ালি করুন")
                _currentScreen.value = Screen.LOGIN
            }
        }
    }

    fun saveGoogleCredentials(username: String, pin: String): Boolean {
        val email = _googleLoginEmail.value ?: return false
        val trimmedName = username.trim()
        val trimmedPin = pin.trim()
        
        if (trimmedName.isBlank() || trimmedPin.length !in 4..12 || !trimmedPin.all { it.isDigit() }) return false

        val masterName = sharedPrefs.getString("user_name", "") ?: ""
        val success = if (masterName.isEmpty()) {
            registerUser(trimmedName, trimmedPin)
        } else {
            registerUserWithMobile(trimmedName, trimmedPin)
        }

        if (success) {
            val firebaseUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: ""
            sharedPrefs.edit()
                .putString("google_user_mapped_username_$email", trimmedName)
                .putString("google_user_mapped_pin_$email", trimmedPin)
                .apply()
            if (firebaseUid.isNotEmpty()) {
                sharedPrefs.edit()
                    .putString("google_user_mapped_username_$firebaseUid", trimmedName)
                    .putString("google_user_mapped_pin_$firebaseUid", trimmedPin)
                    .apply()
            }
            _isSettingGoogleCredentials.value = false
            showToast("ব্যবহারকারী অ্যাকাউন্ট এবং পাসওয়ার্ড সেট করা হয়েছে!")
            return true
        }
        return false
    }

    fun handleGoogleRecoverySuccess(email: String) {
        val mappedUsername = sharedPrefs.getString("google_user_mapped_username_$email", "") ?: ""
        val mappedPin = sharedPrefs.getString("google_user_mapped_pin_$email", "") ?: ""

        if (mappedUsername.isNotEmpty() && mappedPin.isNotEmpty()) {
            _recoveryAccountInfo.value = Pair(mappedUsername, mappedPin)
        } else {
            showToast("এই জিমেইল অ্যাকাউন্টের সাথে কোনো অ্যাকাউন্ট যুক্ত নেই!")
            _recoveryAccountInfo.value = null
        }
    }

    fun clearRecoveryInfo() {
        _recoveryAccountInfo.value = null
    }

    fun cancelGoogleCredentialsSetup() {
        _isSettingGoogleCredentials.value = false
        _googleLoginEmail.value = null
    }

    fun backupToGoogleDrive(password: String, silent: Boolean = false) {
        val email = _googleAccountEmail.value
        if (email.isNullOrBlank()) {
            if (!silent) {
                _syncStatusMessage.value = "অনুগ্রহ করে প্রথমে গুগল ড্রাইভ কানেক্ট করুন"
            }
            return
        }

        viewModelScope.launch {
            if (!silent) {
                _isSyncing.value = true
                _syncStatusMessage.value = "গুগল ড্রাইভে ডাটা ব্যাকআপ করা হচ্ছে..."
            }
            try {
                val token = try {
                    GoogleDriveSyncHelper.getAccessToken(getApplication(), email)
                } catch (e: GoogleDriveSyncHelper.NeedUserPermissionException) {
                    _googleDriveAuthIntent.value = e.intent
                    if (!silent) {
                        _syncStatusMessage.value = "গুগল ড্রাইভ অনুমোদনের প্রয়োজন"
                    }
                    return@launch
                }

                if (_allUsers.value.isEmpty()) {
                    loadAllUsers()
                }
                val users = _allUsers.value

                var allSucceeded = true
                var errMsg = ""

                // 1. Backup all user databases to their user-specific JSON files
                for (user in users) {
                    try {
                        val db = AppDatabase.getDatabaseForUser(getApplication(), user.name)
                        val dao = db.financialDao()
                        val transactions = dao.getAllTransactions().first()
                        val fixedInvestments = dao.getAllFixedInvestments().first()
                        val debts = dao.getAllDebts().first()
                        val assets = dao.getAllAssets().first()
                        val zakatProfile = dao.getZakatProfile().first()
                        val zakatRecords = dao.getAllZakatRecords().first()
                        val businessCategories = dao.getAllBusinessCategories().first()
                        val businessItems = dao.getAllBusinessItems().first()

                        val backupData = UserCloudData(
                            transactions = transactions,
                            fixedInvestments = fixedInvestments,
                            debts = debts,
                            assets = assets,
                            zakatProfile = zakatProfile,
                            zakatRecords = zakatRecords,
                            businessCategories = businessCategories,
                            businessItems = businessItems
                        )

                        val userFileName = "hiseb_nikesh_backup_${user.name.lowercase().trim()}.json"
                        val result = GoogleDriveSyncHelper.backupDataToDrive(token, userFileName, backupData, password)
                        if (!result.isSuccess) {
                            allSucceeded = false
                            errMsg = result.exceptionOrNull()?.message ?: "Unknown error"
                        }
                    } catch (e: Exception) {
                        allSucceeded = false
                        errMsg = e.message ?: "Unknown error"
                    }
                }

                // 2. Backup users list, PINs, custom categories, etc. to system metadata JSON file
                val masterName = sharedPrefs.getString("user_name", "") ?: ""
                val masterPinHash = sharedPrefs.getString("user_pin_hash", "") ?: ""
                val masterPinSalt = sharedPrefs.getString("user_pin_salt", "") ?: ""
                val subUsersStr = sharedPrefs.getString("sub_users", "") ?: ""

                val incomeCats = sharedPrefs.getString("income_cats", "বেতন,ব্যবসা,উপহার,অন্যান্য") ?: "বেতন,ব্যবসা,উপহার,অন্যান্য"
                val expenseCats = sharedPrefs.getString("expense_cats", "খাবার,ভাড়া,শপিং,ইউটিলিটি,চিকিৎসা,শিক্ষা,যাতায়াত,অন্যান্য") ?: "খাবার,ভাড়া,শপিং,ইউটিলিটি,চিকিৎসা,শিক্ষা,যাতায়াত,অন্যান্য"
                val savingsCats = sharedPrefs.getString("savings_cats", "ব্যাংক ডিপিএস,সঞ্চয়পত্র,নগদ জমা,অন্যান্য") ?: "ব্যাংক ডিপিএস,সঞ্চয়পত্র,নগদ জমা,অন্যান্য"

                val metadataJson = org.json.JSONObject().apply {
                    put("masterName", masterName)
                    put("masterPinHash", masterPinHash)
                    put("masterPinSalt", masterPinSalt)
                    put("subUsersStr", subUsersStr)
                    put("incomeCats", incomeCats)
                    put("expenseCats", expenseCats)
                    put("savingsCats", savingsCats)

                    val subUsersArray = org.json.JSONArray()
                    val subUserNames = subUsersStr.split(",").filter { it.isNotBlank() }
                    subUserNames.forEach { name ->
                        val hash = sharedPrefs.getString("user_pin_hash_$name", "") ?: ""
                        val salt = sharedPrefs.getString("user_pin_salt_$name", "") ?: ""
                        val menus = sharedPrefs.getString("user_menus_$name", "") ?: ""
                        val uJson = org.json.JSONObject().apply {
                            put("name", name)
                            put("pinHash", hash)
                            put("pinSalt", salt)
                            put("menus", menus)
                        }
                        subUsersArray.put(uJson)
                    }
                    put("subUsersDetail", subUsersArray)
                    put("backupFormatVersion", 2)
                    put("timestamp", System.currentTimeMillis())
                }

                val metaFileName = "hiseb_nikesh_users_metadata.json"
                val metaResult = GoogleDriveSyncHelper.backupJsonToDrive(token, metaFileName, metadataJson.toString(), password)
                if (!metaResult.isSuccess) {
                    allSucceeded = false
                    errMsg = metaResult.exceptionOrNull()?.message ?: "Metadata upload failed"
                }

                if (allSucceeded) {
                    if (!silent) {
                        _syncStatusMessage.value = "গুগল ড্রাইভে সফলভাবে ব্যাকআপ সম্পন্ন হয়েছে!"
                    }
                } else {
                    val ex = metaResult.exceptionOrNull() ?: Exception(errMsg)
                    if (ex is IOException && ex.message?.contains("401") == true) {
                        GoogleDriveSyncHelper.invalidateToken(getApplication(), token)
                    }
                    if (!silent) {
                        _syncStatusMessage.value = "গুগল ড্রাইভ ব্যাকআপ ব্যর্থ হয়েছে: ${ex.message}"
                    }
                }
            } catch (e: Exception) {
                if (!silent) {
                    _syncStatusMessage.value = "গুগল ড্রাইভ ব্যাকআপে সমস্যা হয়েছে: ${e.message}"
                }
            } finally {
                if (!silent) {
                    delay(2500)
                    _isSyncing.value = false
                    _syncStatusMessage.value = null
                }
            }
        }
    }

    fun restoreFromGoogleDrive(password: String) {
        val email = _googleAccountEmail.value
        if (email.isNullOrBlank()) {
            _syncStatusMessage.value = "অনুগ্রহ করে প্রথমে গুগল ড্রাইভ কানেক্ট করুন"
            return
        }

        viewModelScope.launch {
            _isSyncing.value = true
            _syncStatusMessage.value = "গুগল ড্রাইভ থেকে ডাটা আনা হচ্ছে..."
            try {
                val token = try {
                    GoogleDriveSyncHelper.getAccessToken(getApplication(), email)
                } catch (e: GoogleDriveSyncHelper.NeedUserPermissionException) {
                    _googleDriveAuthIntent.value = e.intent
                    _syncStatusMessage.value = "গুগল ড্রাইভ অনুমোদনের প্রয়োজন"
                    return@launch
                }

                val metaFileName = "hiseb_nikesh_users_metadata.json"
                val metaResult = GoogleDriveSyncHelper.restoreJsonFromDrive(token, metaFileName, password)
                
                // Safety Snapshot
                val context = getApplication<android.app.Application>()
                val snapshots = mutableMapOf<String, UserCloudData>()
                
                setRestoreMarker()
                
                for (user in _allUsers.value) {
                    snapshots[user.name] = collectLocalDataSnapshot(user.name)
                }
                com.example.security.LocalSnapshotManager.saveSnapshot(context, snapshots)

                if (metaResult.isSuccess) {
                    val metaJsonStr = metaResult.getOrNull()
                    if (metaJsonStr != null) {
                        val metadata = org.json.JSONObject(metaJsonStr)
                        val masterName = metadata.optString("masterName", "drmaks")
                        val masterPin = metadata.optString("masterPin", "799733")
                        val subUsersStr = metadata.optString("subUsersStr", "")

                        val incomeCats = metadata.optString("incomeCats", "বেতন,ব্যবসা,উপহার,অন্যান্য")
                        val expenseCats = metadata.optString("expenseCats", "খাবার,ভাড়া,শপিং,ইউটিলিটি,চিকিৎসা,শিক্ষা,যাতায়াত,অন্যান্য")
                        val savingsCats = metadata.optString("savingsCats", "ব্যাংক ডিপিএস,সঞ্চয়পত্র,নগদ জমা,অন্যান্য")

                        // 1. Restore SharedPreferences
                        val editor = sharedPrefs.edit()
                        editor.putString("user_name", masterName)
                        editor.putString("user_pin", masterPin)
                        editor.putString("sub_users", subUsersStr)
                        editor.putString("income_cats", incomeCats)
                        editor.putString("expense_cats", expenseCats)
                        editor.putString("savings_cats", savingsCats)

                        val subUsersArray = metadata.optJSONArray("subUsersDetail")
                        if (subUsersArray != null) {
                            for (i in 0 until subUsersArray.length()) {
                                val uJson = subUsersArray.getJSONObject(i)
                                val name = uJson.getString("name")
                                val pin = uJson.getString("pin")
                                val menus = uJson.getString("menus")
                                editor.putString("user_pin_$name", pin)
                                editor.putString("user_menus_$name", menus)
                            }
                        }
                        editor.apply()

                        // Reload category lists
                        _incomeCategories.value = incomeCats.split(",").filter { it.isNotBlank() }
                        _expenseCategories.value = expenseCats.split(",").filter { it.isNotBlank() }
                        _savingsCategories.value = savingsCats.split(",").filter { it.isNotBlank() }

                        // Reload users
                        loadAllUsers()

                        val restoredUsers = _allUsers.value
                        var restoreCount = 0

                        // 2. Restore databases for all restored users
                        for (user in restoredUsers) {
                            val userFileName = "hiseb_nikesh_backup_${user.name.lowercase().trim()}.json"
                            val dbResult = GoogleDriveSyncHelper.restoreDataFromDrive(token, userFileName, password)
                            if (dbResult.isSuccess) {
                                val cloudData = dbResult.getOrNull()
                                if (cloudData != null) {
                                    val db = AppDatabase.getDatabaseForUser(getApplication(), user.name)
                                    val dao = db.financialDao()

                                    // Clear existing tables
                                    dao.clearTransactions()
                                    dao.clearFixedInvestments()
                                    dao.clearDebts()
                                    dao.clearAssets()
                                    dao.clearZakatProfiles()
                                    dao.clearZakatRecords()
                                    dao.clearBusinessCategories()
                                    dao.clearBusinessItems()

                                    // Insert retrieved data
                                    if (cloudData.transactions.isNotEmpty()) {
                                        dao.insertTransactions(cloudData.transactions)
                                    }
                                    if (cloudData.fixedInvestments.isNotEmpty()) {
                                        dao.insertFixedInvestments(cloudData.fixedInvestments)
                                    }
                                    if (cloudData.debts.isNotEmpty()) {
                                        dao.insertDebts(cloudData.debts)
                                    }
                                    if (cloudData.assets.isNotEmpty()) {
                                        dao.insertAssets(cloudData.assets)
                                    }
                                    if (cloudData.zakatProfile != null) {
                                        dao.saveZakatProfile(cloudData.zakatProfile)
                                    }
                                    if (cloudData.zakatRecords.isNotEmpty()) {
                                        dao.insertZakatRecords(cloudData.zakatRecords)
                                    }
                                    if (cloudData.businessCategories.isNotEmpty()) {
                                        dao.insertBusinessCategories(cloudData.businessCategories)
                                    }
                                    if (cloudData.businessItems.isNotEmpty()) {
                                        dao.insertBusinessItems(cloudData.businessItems)
                                    }
                                    restoreCount++
                                }
                            }
                        }

                        // 3. Automatically switch to Master user and activate database
                        val restoredUser = restoredUsers.firstOrNull() ?: AppUser(masterName, masterPin)
                        _currentUser.value = restoredUser
                        _userName.value = restoredUser.name
                        setLoggedIn(true)
                        _currentScreen.value = Screen.DASHBOARD
                        switchUserDatabase(restoredUser.name)
                        
                        // Cleanup
                        clearRestoreMarker()
                        com.example.security.LocalSnapshotManager.deleteSnapshot(context)

                        _syncStatusMessage.value = "গুগল ড্রাইভ থেকে $restoreCount টি ইউজার ডাটা সফলভাবে রিস্টোর সম্পন্ন হয়েছে!"
                    } else {
                        // Rollback on failure
                        for ((name, data) in snapshots) {
                            restoreFromSnapshot(name, data)
                        }
                        
                        // Cleanup
                        clearRestoreMarker()
                        com.example.security.LocalSnapshotManager.deleteSnapshot(context)
                        _syncStatusMessage.value = "গুগল ড্রাইভে কোনো ব্যাকআপ ফাইল পাওয়া যায়নি!"
                    }
                } else {
                    val ex = metaResult.exceptionOrNull()
                    if (ex is IOException && ex.message?.contains("401") == true) {
                        GoogleDriveSyncHelper.invalidateToken(getApplication(), token)
                    }
                    _syncStatusMessage.value = "গুগল ড্রাইভ রিস্টোর ব্যর্থ হয়েছে: ${ex?.message}"
                }
            } catch (e: Exception) {
                _syncStatusMessage.value = "গুগল ড্রাইভ রিস্টোরে সমস্যা হয়েছে: ${e.message}"
            } finally {
                delay(2500)
                _isSyncing.value = false
                _syncStatusMessage.value = null
            }
        }
    }

    private suspend fun restoreFromSnapshot(userName: String, cloudData: UserCloudData) {
        val db = AppDatabase.getDatabaseForUser(getApplication(), userName)
        val dao = db.financialDao()
        dao.clearTransactions()
        dao.clearFixedInvestments()
        dao.clearDebts()
        dao.clearAssets()
        dao.clearZakatProfiles()
        dao.clearZakatRecords()
        dao.clearBusinessCategories()
        dao.clearBusinessItems()

        if (cloudData.transactions.isNotEmpty()) dao.insertTransactions(cloudData.transactions)
        if (cloudData.fixedInvestments.isNotEmpty()) dao.insertFixedInvestments(cloudData.fixedInvestments)
        if (cloudData.debts.isNotEmpty()) dao.insertDebts(cloudData.debts)
        if (cloudData.assets.isNotEmpty()) dao.insertAssets(cloudData.assets)
        if (cloudData.zakatProfile != null) dao.saveZakatProfile(cloudData.zakatProfile)
        if (cloudData.zakatRecords.isNotEmpty()) dao.insertZakatRecords(cloudData.zakatRecords)
        if (cloudData.businessCategories.isNotEmpty()) dao.insertBusinessCategories(cloudData.businessCategories)
        if (cloudData.businessItems.isNotEmpty()) dao.insertBusinessItems(cloudData.businessItems)
    }

    private suspend fun collectLocalDataSnapshot(userName: String): UserCloudData {
        val db = AppDatabase.getDatabaseForUser(getApplication(), userName)
        val dao = db.financialDao()
        return UserCloudData(
            transactions = dao.getAllTransactions().first(),
            fixedInvestments = dao.getAllFixedInvestments().first(),
            debts = dao.getAllDebts().first(),
            assets = dao.getAllAssets().first(),
            zakatProfile = dao.getZakatProfile().first(),
            zakatRecords = dao.getAllZakatRecords().first(),
            businessCategories = dao.getAllBusinessCategories().first(),
            businessItems = dao.getAllBusinessItems().first()
        )
    }

    private fun isRestoreInProgress(): Boolean {
        return File(getApplication<android.app.Application>().filesDir, "restore_in_progress.marker").exists()
    }

    private fun setRestoreMarker() {
        File(getApplication<android.app.Application>().filesDir, "restore_in_progress.marker").createNewFile()
    }

    private fun clearRestoreMarker() {
        val file = File(getApplication<android.app.Application>().filesDir, "restore_in_progress.marker")
        if (file.exists()) file.delete()
    }

    private suspend fun recoverFromSnapshot() {
        _syncStatusMessage.value = "পূর্বের রিস্টোর প্রচেষ্টা সম্পন্ন করা হচ্ছে..."
        val context = getApplication<android.app.Application>()
        val snapshots = com.example.security.LocalSnapshotManager.loadSnapshot(context)
        if (snapshots != null) {
            for ((name, data) in snapshots) {
                restoreFromSnapshot(name, data)
            }
        }
        clearRestoreMarker()
        com.example.security.LocalSnapshotManager.deleteSnapshot(context)
        _syncStatusMessage.value = "পূর্বের রিস্টোর ব্যর্থ হওয়ায় রোলব্যাক সম্পন্ন হয়েছে!"
    }
}

class FinancialViewModelFactory(
    private val application: Application,
    private val repository: FinancialRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FinancialViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FinancialViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
