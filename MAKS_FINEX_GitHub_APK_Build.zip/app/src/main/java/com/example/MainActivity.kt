package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.AppDatabase
import com.example.data.repository.FinancialRepository
import com.example.ui.screens.AppNavigationShell
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.FinancialViewModel
import com.example.viewmodel.FinancialViewModelFactory

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: FinancialViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Database and Components
        val database = AppDatabase.getDatabase(this)
        val repository = FinancialRepository(database.financialDao())
        
        // Instantiate ViewModel
        val factory = FinancialViewModelFactory(application, repository)
        viewModel = ViewModelProvider(this, factory)[FinancialViewModel::class.java]

        // Initialize AdMob Mobile Ads SDK
        try {
            com.google.android.gms.ads.MobileAds.initialize(this) {}
        } catch (e: Exception) {
            android.util.Log.e("AdMobInit", "Failed to initialize MobileAds SDK", e)
        }

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val appLocale by viewModel.appLocale.collectAsStateWithLifecycle()

            // Update configuration context locale
            viewModel.updateAppLocale(this, appLocale)

            val baseContext = androidx.compose.ui.platform.LocalContext.current
            val localizedContext = remember(baseContext, appLocale) {
                val locale = java.util.Locale(appLocale)
                java.util.Locale.setDefault(locale)
                val config = android.content.res.Configuration(baseContext.resources.configuration)
                config.setLocale(locale)
                config.setLayoutDirection(locale)
                val configurationContext = baseContext.createConfigurationContext(config)
                object : android.content.ContextWrapper(baseContext) {
                    override fun getResources(): android.content.res.Resources {
                        return configurationContext.resources
                    }
                    override fun getAssets(): android.content.res.AssetManager {
                        return configurationContext.assets
                    }
                }
            }

            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.ui.platform.LocalContext provides localizedContext
            ) {
                MyApplicationTheme(darkTheme = isDarkMode) {
                    AppNavigationShell(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
