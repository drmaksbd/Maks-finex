package com.example.data.model

data class UserCloudData(
    val transactions: List<Transaction> = emptyList(),
    val fixedInvestments: List<FixedInvestment> = emptyList(),
    val debts: List<Debt> = emptyList(),
    val assets: List<Asset> = emptyList(),
    val zakatProfile: ZakatProfile? = null,
    val zakatRecords: List<ZakatRecord> = emptyList(),
    val businessCategories: List<BusinessCategory> = emptyList(),
    val businessItems: List<BusinessItem> = emptyList()
)
