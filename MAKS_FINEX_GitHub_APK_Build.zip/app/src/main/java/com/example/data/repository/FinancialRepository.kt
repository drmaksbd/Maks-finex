package com.example.data.repository

import com.example.data.dao.FinancialDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.ExperimentalCoroutinesApi

class FinancialRepository(private val initialDao: FinancialDao) {

    private val activeDao = MutableStateFlow(initialDao)

    fun switchDao(newDao: FinancialDao) {
        activeDao.value = newDao
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allTransactions: Flow<List<Transaction>> = activeDao.flatMapLatest { it.getAllTransactions() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allFixedInvestments: Flow<List<FixedInvestment>> = activeDao.flatMapLatest { it.getAllFixedInvestments() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allDebts: Flow<List<Debt>> = activeDao.flatMapLatest { it.getAllDebts() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allAssets: Flow<List<Asset>> = activeDao.flatMapLatest { it.getAllAssets() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val zakatProfile: Flow<ZakatProfile?> = activeDao.flatMapLatest { it.getZakatProfile() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allZakatRecords: Flow<List<ZakatRecord>> = activeDao.flatMapLatest { it.getAllZakatRecords() }

    suspend fun insertTransaction(transaction: Transaction) = activeDao.value.insertTransaction(transaction)
    suspend fun insertTransactions(transactions: List<Transaction>) = activeDao.value.insertTransactions(transactions)
    suspend fun deleteTransaction(id: Int) = activeDao.value.deleteTransaction(id)
    suspend fun clearTransactions() = activeDao.value.clearTransactions()

    suspend fun insertFixedInvestment(investment: FixedInvestment) = activeDao.value.insertFixedInvestment(investment)
    suspend fun insertFixedInvestments(investments: List<FixedInvestment>) = activeDao.value.insertFixedInvestments(investments)
    suspend fun deleteFixedInvestment(id: Int) = activeDao.value.deleteFixedInvestment(id)
    suspend fun clearFixedInvestments() = activeDao.value.clearFixedInvestments()

    suspend fun insertDebt(debt: Debt) = activeDao.value.insertDebt(debt)
    suspend fun insertDebts(debts: List<Debt>) = activeDao.value.insertDebts(debts)
    suspend fun deleteDebt(id: Int) = activeDao.value.deleteDebt(id)
    suspend fun clearDebts() = activeDao.value.clearDebts()

    suspend fun insertAsset(asset: Asset) = activeDao.value.insertAsset(asset)
    suspend fun insertAssets(assets: List<Asset>) = activeDao.value.insertAssets(assets)
    suspend fun deleteAsset(id: Int) = activeDao.value.deleteAsset(id)
    suspend fun clearAssets() = activeDao.value.clearAssets()

    suspend fun saveZakatProfile(zakatProfile: ZakatProfile) = activeDao.value.saveZakatProfile(zakatProfile)
    suspend fun clearZakatProfiles() = activeDao.value.clearZakatProfiles()

    suspend fun insertZakatRecord(record: ZakatRecord) = activeDao.value.insertZakatRecord(record)
    suspend fun insertZakatRecords(records: List<ZakatRecord>) = activeDao.value.insertZakatRecords(records)
    suspend fun deleteZakatRecord(id: Int) = activeDao.value.deleteZakatRecord(id)
    suspend fun clearZakatRecords() = activeDao.value.clearZakatRecords()

    // --- BUSINESS LEDGER ---
    @OptIn(ExperimentalCoroutinesApi::class)
    val allBusinessCategories: Flow<List<BusinessCategory>> = activeDao.flatMapLatest { it.getAllBusinessCategories() }

    @OptIn(ExperimentalCoroutinesApi::class)
    val allBusinessItems: Flow<List<BusinessItem>> = activeDao.flatMapLatest { it.getAllBusinessItems() }

    suspend fun insertBusinessCategory(category: BusinessCategory) = activeDao.value.insertBusinessCategory(category)
    suspend fun insertBusinessCategories(categories: List<BusinessCategory>) = activeDao.value.insertBusinessCategories(categories)
    suspend fun deleteBusinessCategory(id: Int) = activeDao.value.deleteBusinessCategory(id)
    suspend fun clearBusinessCategories() = activeDao.value.clearBusinessCategories()

    suspend fun insertBusinessItem(item: BusinessItem) = activeDao.value.insertBusinessItem(item)
    suspend fun insertBusinessItems(items: List<BusinessItem>) = activeDao.value.insertBusinessItems(items)
    suspend fun deleteBusinessItem(id: Int) = activeDao.value.deleteBusinessItem(id)
    suspend fun clearBusinessItems() = activeDao.value.clearBusinessItems()
}
