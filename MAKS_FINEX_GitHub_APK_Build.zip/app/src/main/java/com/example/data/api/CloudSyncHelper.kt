package com.example.data.api

import android.util.Log
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

object CloudSyncHelper {
    private const val TAG = "CloudSyncHelper"
    private const val BUCKET_ID = "hiseb_nikesh_bk_yq7psyg2l2"
    private const val BASE_URL = "https://kvdb.io/$BUCKET_ID"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(UserCloudData::class.java)

    suspend fun backupData(username: String, data: UserCloudData): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val json = adapter.toJson(data)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = json.toRequestBody(mediaType)
            
            // Clean username for safe path matching
            val safeUsername = username.lowercase().trim().replace(Regex("[^a-z0-9]"), "_")
            val request = Request.Builder()
                .url("$BASE_URL/$safeUsername")
                .put(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Log.e(TAG, "Backup failed with code: ${response.code}")
                    Result.failure(IOException("অনলাইন সার্ভার ত্রুটি: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Backup exception: ", e)
            Result.failure(e)
        }
    }

    suspend fun restoreData(username: String): Result<UserCloudData?> = withContext(Dispatchers.IO) {
        try {
            val safeUsername = username.lowercase().trim().replace(Regex("[^a-z0-9]"), "_")
            val request = Request.Builder()
                .url("$BASE_URL/$safeUsername")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 404) {
                    // Not found is a valid case (no cloud backup yet)
                    Result.success(null)
                } else if (response.isSuccessful) {
                    val bodyString = response.body?.string()
                    if (bodyString.isNullOrBlank()) {
                        Result.success(null)
                    } else {
                        val cloudData = adapter.fromJson(bodyString)
                        Result.success(cloudData)
                    }
                } else {
                    Log.e(TAG, "Restore failed with code: ${response.code}")
                    Result.failure(IOException("অনলাইন সার্ভার ত্রুটি: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Restore exception: ", e)
            Result.failure(e)
        }
    }
}
