package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class InvestmentRecord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: String, // "INVESTMENT" (বিনিয়োগ), "RETURN" (লাভ/রিটার্ন/ফেরত)
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val description: String = ""
)

object InvestmentJsonParser {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, InvestmentRecord::class.java)
    private val adapter = moshi.adapter<List<InvestmentRecord>>(listType)

    fun toJson(records: List<InvestmentRecord>): String {
        return try {
            adapter.toJson(records)
        } catch (e: Exception) {
            ""
        }
    }

    fun fromJson(json: String?): List<InvestmentRecord> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "INCOME", "EXPENSE", "SAVINGS"
    val amount: Double,
    val category: String, // "Salary", "Food", "Rent", "Shopping", "Entertainment", "Utility", "Business", "Medical", "Education", "Other"
    val date: Long = System.currentTimeMillis(),
    val description: String = ""
)

@Entity(tableName = "fixed_investments")
data class FixedInvestment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "DPS", "FDR", "Sanchayapatra", "Other"
    val institutionName: String,
    val amount: Double,
    val interestRate: Double = 0.0,
    val startDate: Long = System.currentTimeMillis(),
    val durationMonths: Int = 12,
    val description: String = "",
    val transactionsJson: String = ""
)

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "LENT" (ঋণ দেওয়া), "BORROWED" (ঋণ নেওয়া)
    val personName: String,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val dueDate: Long = 0L,
    val isSettled: Boolean = false,
    val description: String = ""
)

@Entity(tableName = "assets")
data class Asset(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "Property" (জমি/বাড়ি), "Gold" (স্বর্ণ/রৌপ্য), "Savings" (ব্যাংক জমা), "Business" (ব্যবসা), "Other" (অন্যান্য)
    val value: Double,
    val date: Long = System.currentTimeMillis(),
    val description: String = ""
)

@Entity(tableName = "zakat_profiles")
data class ZakatProfile(
    @PrimaryKey val id: Int = 1, // Only single current calculation state is saved with id 1
    val goldWeightBhori: Double = 0.0,
    val goldPricePerBhori: Double = 0.0,
    val silverWeightBhori: Double = 0.0,
    val silverPricePerBhori: Double = 0.0,
    val cashInHandBank: Double = 0.0,
    val businessGoodsValue: Double = 0.0,
    val otherInvestments: Double = 0.0,
    val debtsOwed: Double = 0.0,
    val detailsJson: String = ""
)

@Entity(tableName = "zakat_records")
data class ZakatRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val year: String,
    val personName: String,
    val goldWeightBhori: Double = 0.0,
    val goldPricePerBhori: Double = 0.0,
    val silverWeightBhori: Double = 0.0,
    val silverPricePerBhori: Double = 0.0,
    val cashInHandBank: Double = 0.0,
    val businessGoodsValue: Double = 0.0,
    val otherInvestments: Double = 0.0,
    val debtsOwed: Double = 0.0,
    val totalZakatAmount: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val detailsJson: String = ""
)

@Entity(tableName = "business_categories")
data class BusinessCategory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val dateCreated: Long = System.currentTimeMillis()
)

@Entity(tableName = "business_items")
data class BusinessItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryId: Int,
    val name: String,
    val purchasePrice: Double,
    val salePrice: Double,
    val isSold: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis(),
    val saleDate: Long? = null,
    val profit: Double = 0.0
)

