package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.FinancialDao
import com.example.data.model.*

@Database(
    entities = [
        Transaction::class,
        FixedInvestment::class,
        Debt::class,
        Asset::class,
        ZakatProfile::class,
        ZakatRecord::class,
        BusinessCategory::class,
        BusinessItem::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun financialDao(): FinancialDao

    companion object {
        private val instances = java.util.concurrent.ConcurrentHashMap<String, AppDatabase>()

        fun getDatabase(context: Context): AppDatabase {
            return getDatabaseForUser(context, "default")
        }

        fun getDatabaseForUser(context: Context, username: String): AppDatabase {
            val dbName = "hiseb_nikesh_db_${username.lowercase().trim()}"
            return instances.getOrPut(dbName) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    dbName
                ).build()
            }
        }

        fun renameUserDatabase(context: Context, oldUsername: String, newUsername: String) {
            val oldDbName = "hiseb_nikesh_db_${oldUsername.lowercase().trim()}"
            val newDbName = "hiseb_nikesh_db_${newUsername.lowercase().trim()}"
            if (oldDbName == newDbName) return

            // Close existing instances if open
            instances.remove(oldDbName)?.close()
            instances.remove(newDbName)?.close()

            val suffixes = listOf("", "-shm", "-wal")
            for (suffix in suffixes) {
                val oldFile = context.getDatabasePath(oldDbName + suffix)
                if (oldFile.exists()) {
                    val newFile = context.getDatabasePath(newDbName + suffix)
                    oldFile.renameTo(newFile)
                }
            }
        }
    }
}
