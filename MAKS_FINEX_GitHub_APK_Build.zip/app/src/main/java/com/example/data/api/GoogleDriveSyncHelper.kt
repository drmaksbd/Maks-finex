package com.example.data.api

import android.accounts.Account
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.model.UserCloudData
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

object GoogleDriveSyncHelper {
    private const val TAG = "GoogleDriveSyncHelper"
    private const val BACKUP_FILE_NAME = "hiseb_nikesh_backup.json"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(UserCloudData::class.java)

    class NeedUserPermissionException(val intent: Intent) : Exception("Google authorization required")

    // Retrieve OAuth2 access token for the Google account using GoogleAuthUtil
    suspend fun getAccessToken(context: Context, email: String): String = withContext(Dispatchers.IO) {
        val scope = "oauth2:https://www.googleapis.com/auth/drive.file openid email profile"
        try {
            val account = Account(email, "com.google")
            GoogleAuthUtil.getToken(context, account, scope)
        } catch (e: UserRecoverableAuthException) {
            Log.w(TAG, "UserRecoverableAuthException: user permission needed", e)
            throw NeedUserPermissionException(e.intent ?: Intent())
        } catch (e: Exception) {
            Log.e(TAG, "Error getting access token: ", e)
            throw e
        }
    }

    // Invalidates a token (useful if we get a 401 Unauthorized)
    fun invalidateToken(context: Context, token: String) {
        try {
            GoogleAuthUtil.clearToken(context, token)
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing token: ", e)
        }
    }

    // Searches for the backup file on Google Drive and returns its ID or null
    suspend fun findBackupFileId(accessToken: String, fileName: String = BACKUP_FILE_NAME): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.googleapis.com/drive/v3/files?q=name='$fileName'+and+trashed=false"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $accessToken")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val json = JSONObject(bodyString)
                    val filesArray = json.optJSONArray("files")
                    if (filesArray != null && filesArray.length() > 0) {
                        return@withContext filesArray.getJSONObject(0).getString("id")
                    }
                } else {
                    Log.e(TAG, "Search file failed with code: ${response.code}, body: ${response.body?.string()}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception searching backup file: ", e)
        }
        return@withContext null
    }

    // Creates a new empty file with specified fileName on Google Drive and returns its ID
    suspend fun createBackupFile(accessToken: String, fileName: String = BACKUP_FILE_NAME): String? = withContext(Dispatchers.IO) {
        try {
            val metadataJson = JSONObject().apply {
                put("name", fileName)
            }.toString()

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = metadataJson.toRequestBody(mediaType)

            val request = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files")
                .header("Authorization", "Bearer $accessToken")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val json = JSONObject(bodyString)
                    return@withContext json.getString("id")
                } else {
                    Log.e(TAG, "Create file metadata failed with code: ${response.code}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception creating backup file metadata: ", e)
        }
        return@withContext null
    }

    // Uploads/Updates file content on Google Drive for user database backup
    suspend fun backupDataToDrive(accessToken: String, fileName: String, data: UserCloudData, password: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            // 1. Search for existing file
            var fileId = findBackupFileId(accessToken, fileName)

            // 2. If file does not exist, create it
            if (fileId == null) {
                fileId = createBackupFile(accessToken, fileName)
            }

            if (fileId == null) {
                return@withContext Result.failure(IOException("গুগল ড্রাইভে ফাইল তৈরি করা যায়নি।"))
            }

            // 3. Update the content using PATCH media upload
            val contentJson = adapter.toJson(data)
            val encryptedContent = com.example.security.CryptoManager.encrypt(contentJson, password)
            val mediaType = "text/plain; charset=utf-8".toMediaType()
            val body = encryptedContent.toRequestBody(mediaType)

            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files/$fileId?uploadType=media")
                .header("Authorization", "Bearer $accessToken")
                .patch(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Log.e(TAG, "Upload content failed with code: ${response.code}")
                    Result.failure(IOException("গুগল ড্রাইভ আপলোড কোড: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception backing up to Drive: ", e)
            Result.failure(e)
        }
    }

    // Downloads the backup file content from Google Drive and deserializes it
    suspend fun restoreDataFromDrive(accessToken: String, fileName: String, password: String): Result<UserCloudData?> = withContext(Dispatchers.IO) {
        try {
            // 1. Search for backup file
            val fileId = findBackupFileId(accessToken, fileName)
            if (fileId == null) {
                return@withContext Result.success(null) // No backup found
            }

            // 2. Download content using alt=media
            val request = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                .header("Authorization", "Bearer $accessToken")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val encryptedBodyString = response.body?.string()
                    if (encryptedBodyString.isNullOrBlank()) {
                        Result.success(null)
                    } else {
                        try {
                            val decryptedJson = com.example.security.CryptoManager.decrypt(encryptedBodyString, password)
                            val cloudData = adapter.fromJson(decryptedJson)
                            Result.success(cloudData)
                        } catch (e: Exception) {
                            Log.e(TAG, "Decryption or Parsing failed: ", e)
                            Result.failure(IOException("ব্যাকআপ ফাইলটি খুলতে সমস্যা হয়েছে। সম্ভবত পাসওয়ার্ড ভুল বা ফাইলটি ক্ষতিগ্রস্ত।"))
                        }
                    }
                } else {
                    Log.e(TAG, "Download backup content failed with code: ${response.code}")
                    Result.failure(IOException("গুগল ড্রাইভ ডাউনলোড কোড: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception restoring from Drive: ", e)
            Result.failure(e)
        }
    }

    // Backup general JSON string to Google Drive
    suspend fun backupJsonToDrive(accessToken: String, fileName: String, contentJson: String, password: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            var fileId = findBackupFileId(accessToken, fileName)
            if (fileId == null) {
                fileId = createBackupFile(accessToken, fileName)
            }
            if (fileId == null) {
                return@withContext Result.failure(IOException("গুগল ড্রাইভে ফাইল তৈরি করা যায়নি।"))
            }

            val encryptedContent = com.example.security.CryptoManager.encrypt(contentJson, password)
            val mediaType = "text/plain; charset=utf-8".toMediaType()
            val body = encryptedContent.toRequestBody(mediaType)

            val request = Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files/$fileId?uploadType=media")
                .header("Authorization", "Bearer $accessToken")
                .patch(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Log.e(TAG, "Upload JSON content failed with code: ${response.code}")
                    Result.failure(IOException("গুগল ড্রাইভ আপলোড কোড: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception backing up JSON to Drive: ", e)
            Result.failure(e)
        }
    }

    // Restore general JSON string from Google Drive
    suspend fun restoreJsonFromDrive(accessToken: String, fileName: String, password: String): Result<String?> = withContext(Dispatchers.IO) {
        try {
            val fileId = findBackupFileId(accessToken, fileName)
            if (fileId == null) {
                return@withContext Result.success(null)
            }

            val request = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                .header("Authorization", "Bearer $accessToken")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val encryptedBodyString = response.body?.string()
                    if (encryptedBodyString.isNullOrBlank()) {
                        Result.success(null)
                    } else {
                        try {
                            val decryptedJson = com.example.security.CryptoManager.decrypt(encryptedBodyString, password)
                            Result.success(decryptedJson)
                        } catch (e: Exception) {
                            Log.e(TAG, "Decryption JSON failed: ", e)
                            Result.failure(IOException("ব্যাকআপ ফাইলটি খুলতে সমস্যা হয়েছে। সম্ভবত পাসওয়ার্ড ভুল বা ফাইলটি ক্ষতিগ্রস্ত।"))
                        }
                    }
                } else {
                    Log.e(TAG, "Download JSON content failed with code: ${response.code}")
                    Result.failure(IOException("গুগল ড্রাইভ ডাউনলোড কোড: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception restoring JSON from Drive: ", e)
            Result.failure(e)
        }
    }
}
