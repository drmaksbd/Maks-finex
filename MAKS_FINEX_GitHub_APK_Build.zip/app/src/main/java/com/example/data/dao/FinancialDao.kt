package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialDao {

    // --- TRANSACTIONS ---
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<Transaction>)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransaction(id: Int)

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    // --- FIXED INVESTMENTS ---
    @Query("SELECT * FROM fixed_investments ORDER BY startDate DESC")
    fun getAllFixedInvestments(): Flow<List<FixedInvestment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFixedInvestment(investment: FixedInvestment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFixedInvestments(investments: List<FixedInvestment>)

    @Query("DELETE FROM fixed_investments WHERE id = :id")
    suspend fun deleteFixedInvestment(id: Int)

    @Query("DELETE FROM fixed_investments")
    suspend fun clearFixedInvestments()

    // --- DEBTS ---
    @Query("SELECT * FROM debts ORDER BY date DESC")
    fun getAllDebts(): Flow<List<Debt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: Debt)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebts(debts: List<Debt>)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebt(id: Int)

    @Query("DELETE FROM debts")
    suspend fun clearDebts()

    // --- ASSETS ---
    @Query("SELECT * FROM assets ORDER BY date DESC")
    fun getAllAssets(): Flow<List<Asset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: Asset)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(assets: List<Asset>)

    @Query("DELETE FROM assets WHERE id = :id")
    suspend fun deleteAsset(id: Int)

    @Query("DELETE FROM assets")
    suspend fun clearAssets()

    // --- ZAKAT PROFILE ---
    @Query("SELECT * FROM zakat_profiles WHERE id = 1")
    fun getZakatProfile(): Flow<ZakatProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveZakatProfile(zakatProfile: ZakatProfile)

    @Query("DELETE FROM zakat_profiles")
    suspend fun clearZakatProfiles()

    // --- ZAKAT RECORDS (YEAR-WISE) ---
    @Query("SELECT * FROM zakat_records ORDER BY year DESC, date DESC")
    fun getAllZakatRecords(): Flow<List<ZakatRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertZakatRecord(record: ZakatRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertZakatRecords(records: List<ZakatRecord>)

    @Query("DELETE FROM zakat_records WHERE id = :id")
    suspend fun deleteZakatRecord(id: Int)

    @Query("DELETE FROM zakat_records")
    suspend fun clearZakatRecords()

    // --- BUSINESS LEDGER ---
    @Query("SELECT * FROM business_categories ORDER BY dateCreated DESC")
    fun getAllBusinessCategories(): Flow<List<BusinessCategory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusinessCategory(category: BusinessCategory)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusinessCategories(categories: List<BusinessCategory>)

    @Query("DELETE FROM business_categories WHERE id = :id")
    suspend fun deleteBusinessCategory(id: Int)

    @Query("DELETE FROM business_categories")
    suspend fun clearBusinessCategories()

    @Query("SELECT * FROM business_items ORDER BY dateAdded DESC")
    fun getAllBusinessItems(): Flow<List<BusinessItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusinessItem(item: BusinessItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBusinessItems(items: List<BusinessItem>)

    @Query("DELETE FROM business_items WHERE id = :id")
    suspend fun deleteBusinessItem(id: Int)

    @Query("DELETE FROM business_items")
    suspend fun clearBusinessItems()
}
