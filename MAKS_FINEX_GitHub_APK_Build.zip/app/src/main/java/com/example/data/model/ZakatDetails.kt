package com.example.data.model

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class ZakatDetailedEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "", // e.g., "সোনালী ব্যাংক", "২২ ক্যারেট"
    val extra: String = "", // e.g. "22K", "21K", "18K", "24K"
    val quantity: Double = 0.0, // e.g., ভরি
    val pricePerUnit: Double = 0.0, // e.g., প্রতি ভরির মূল্য
    val value: Double = 0.0 // মোট মূল্য
)

data class ZakatDetails(
    val goldEntries: List<ZakatDetailedEntry> = emptyList(),
    val silverEntries: List<ZakatDetailedEntry> = emptyList(),
    val cashEntries: List<ZakatDetailedEntry> = emptyList(),
    val businessEntries: List<ZakatDetailedEntry> = emptyList(),
    val otherEntries: List<ZakatDetailedEntry> = emptyList(),
    val debtEntries: List<ZakatDetailedEntry> = emptyList()
)

object ZakatJsonParser {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter(ZakatDetails::class.java)

    fun toJson(details: ZakatDetails): String {
        return try {
            adapter.toJson(details)
        } catch (e: Exception) {
            ""
        }
    }

    fun fromJson(json: String?): ZakatDetails {
        if (json.isNullOrBlank()) return ZakatDetails()
        return try {
            adapter.fromJson(json) ?: ZakatDetails()
        } catch (e: Exception) {
            ZakatDetails()
        }
    }
}
