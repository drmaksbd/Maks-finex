package com.example.data.api

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.TimeUnit

sealed class PhoneAuthState {
    object Idle : PhoneAuthState()
    object Loading : PhoneAuthState()
    data class CodeSent(val verificationId: String, val resendingToken: PhoneAuthProvider.ForceResendingToken?) : PhoneAuthState()
    object Verified : PhoneAuthState()
    data class Error(val message: String) : PhoneAuthState()
}

object FirebasePhoneAuthHelper {
    private const val TAG = "FirebasePhoneAuth"
    
    private val _authState = MutableStateFlow<PhoneAuthState>(PhoneAuthState.Idle)
    val authState: StateFlow<PhoneAuthState> = _authState

    /**
     * Checks if Firebase Auth can be initialized successfully.
     * If google-services.json is missing or invalid, this will return false.
     */
    fun isFirebaseInitialized(context: android.content.Context): Boolean {
        return try {
            val apps = FirebaseApp.getApps(context)
            if (apps.isNotEmpty()) {
                FirebaseAuth.getInstance()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            // Silently return false when Firebase isn't configured
            false
        }
    }

    /**
     * Resets the authentication state back to Idle.
     */
    fun resetState() {
        _authState.value = PhoneAuthState.Idle
    }

    /**
     * Helper to format Bangladeshi numbers to E.164 format (+880XXXXXXXXX) required by Firebase.
     */
    fun formatToE164(mobile: String): String {
        val clean = mobile.replace("+", "").replace("-", "").replace(" ", "").trim()
        val plainNumber = if (clean.startsWith("880")) {
            clean.substring(3)
        } else if (clean.startsWith("0")) {
            clean.substring(1)
        } else {
            clean
        }
        return "+880$plainNumber"
    }

    /**
     * Starts the phone number verification process using Firebase PhoneAuthProvider.
     */
    fun startPhoneVerification(activity: Activity, mobileNumber: String) {
        if (!isFirebaseInitialized(activity)) {
            _authState.value = PhoneAuthState.Error("Firebase is not initialized. Please add google-services.json to the app directory.")
            return
        }

        val e164Number = formatToE164(mobileNumber)
        _authState.value = PhoneAuthState.Loading
        Log.d(TAG, "Starting Firebase Phone Verification for $e164Number")

        try {
            val auth = FirebaseAuth.getInstance()
            
            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    Log.d(TAG, "onVerificationCompleted: Instant verification success.")
                    // Automatically verify the code
                    signInWithPhoneAuthCredential(auth, credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Log.e(TAG, "onVerificationFailed: ${e.message}", e)
                    val friendlyError = when {
                        e.message?.contains("captcha", ignoreCase = true) == true -> 
                            "রি-ক্যাপচা (reCAPTCHA) যাচাইকরণ ব্যর্থ হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।"
                        e.message?.contains("quota", ignoreCase = true) == true -> 
                            "এসএমএস পাঠানোর কোটা শেষ হয়ে গেছে! অনুগ্রহ করে পরবর্তী সময়ে চেষ্টা করুন।"
                        e.message?.contains("blocked", ignoreCase = true) == true -> 
                            "নিরাপত্তাজনিত কারণে এই মোবাইল নম্বরটি সাময়িকভাবে ব্লক করা হয়েছে।"
                        else -> e.localizedMessage ?: "এসএমএস ওটিপি পাঠাতে ব্যর্থ হয়েছে।"
                    }
                    _authState.value = PhoneAuthState.Error(friendlyError)
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    Log.d(TAG, "onCodeSent: SMS verification code sent to $e164Number")
                    _authState.value = PhoneAuthState.CodeSent(verificationId, token)
                }
            }

            val options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(e164Number)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(callbacks)
                .build()

            PhoneAuthProvider.verifyPhoneNumber(options)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to call verifyPhoneNumber", e)
            _authState.value = PhoneAuthState.Error("ব্যতিক্রমী ত্রুটি: ${e.localizedMessage}")
        }
    }

    /**
     * Verifies the SMS verification code entered by the user.
     */
    fun verifySmsCode(context: android.content.Context, verificationId: String, code: String, onVerificationSuccess: () -> Unit) {
        if (!isFirebaseInitialized(context)) {
            _authState.value = PhoneAuthState.Error("Firebase holds no active initialization context.")
            return
        }

        _authState.value = PhoneAuthState.Loading
        Log.d(TAG, "Verifying code $code for verificationId $verificationId")

        try {
            val auth = FirebaseAuth.getInstance()
            val credential = PhoneAuthProvider.getCredential(verificationId, code)
            
            auth.signInWithCredential(credential)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "Firebase SMS authentication successful!")
                        _authState.value = PhoneAuthState.Verified
                        onVerificationSuccess()
                    } else {
                        Log.e(TAG, "Firebase SMS verification failed: ${task.exception?.message}")
                        _authState.value = PhoneAuthState.Error("ভুল ওটিপি কোড! অনুগ্রহ করে সঠিক কোড দিন।")
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception verifying code", e)
            _authState.value = PhoneAuthState.Error("যাচাইকরণ ব্যর্থ: ${e.localizedMessage}")
        }
    }

    /**
     * Helper to sign in if code auto-retrieval succeeds.
     */
    private fun signInWithPhoneAuthCredential(auth: FirebaseAuth, credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Instant sign-in successful via PhoneAuthCredential.")
                    _authState.value = PhoneAuthState.Verified
                } else {
                    Log.e(TAG, "Instant sign-in failed: ${task.exception?.message}")
                    _authState.value = PhoneAuthState.Error("তাত্ক্ষণিক সাইন-ইন ব্যর্থ হয়েছে: ${task.exception?.localizedMessage}")
                }
            }
    }

    /**
     * Resolves Activity from a Context, unwrapping context wrappers if necessary.
     */
    fun findActivity(context: android.content.Context): android.app.Activity? {
        var ctx = context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is android.app.Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }
}

object GoogleSignInHelper {
    private const val TAG = "GoogleSignIn"
    private val _authState = MutableStateFlow<PhoneAuthState>(PhoneAuthState.Idle)
    val authState: StateFlow<PhoneAuthState> = _authState

    fun getGoogleSignInOptions(context: Context): GoogleSignInOptions {
        // NOTE: The WEB_CLIENT_ID should be the OAuth client ID for this Android app from google-services.json
        // In this architecture, it is configured in the Firebase Console and google-services.json.
        return GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(com.example.R.string.default_web_client_id))
            .requestEmail()
            .build()
    }

    fun handleGoogleSignInResult(
        task: com.google.android.gms.tasks.Task<GoogleSignInAccount>,
        onSuccess: (com.google.firebase.auth.AuthResult) -> Unit,
        onError: (Exception) -> Unit
    ) {
        try {
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener { authTask ->
                    if (authTask.isSuccessful) {
                        onSuccess(authTask.result!!)
                    } else {
                        onError(authTask.exception ?: Exception("Authentication failed"))
                    }
                }
        } catch (e: ApiException) {
            onError(e)
        }
    }
    
    fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }
}

